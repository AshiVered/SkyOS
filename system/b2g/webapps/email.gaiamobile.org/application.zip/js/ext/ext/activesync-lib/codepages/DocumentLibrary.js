(function(e, t) {
    "object" == typeof exports ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : e.ASCPDocumentLibrary = t();
})(this, function() {
    return {
        Tags: {
            LinkId: 4869,
            DisplayName: 4870,
            IsFolder: 4871,
            CreationDate: 4872,
            LastModifiedDate: 4873,
            IsHidden: 4874,
            ContentLength: 4875,
            ContentType: 4876
        }
    };
});