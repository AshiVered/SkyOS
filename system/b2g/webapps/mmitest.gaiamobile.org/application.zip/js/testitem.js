/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

/** Class representing a test item. */
class TestItem {
  debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [testitem.js] = ' + s + '\n');
    }
  }

  /**
   * Create a Test item
   */
  constructor(render) {
    this.debug('constructor');
    this.container = document.querySelector('.test-iframe');
    this.container.innerHTML = '';

    this.container.innerHTML = render();
    let passButton = `<input type="button" class="buttons" id="passButton" value="Pass">`;
    let failButton = `<input type="button" class="buttons" id="failButton" value="Fail">`;
    this.container.innerHTML = this.container.innerHTML + passButton;
    this.container.innerHTML = this.container.innerHTML + failButton;
  }

  init() {
    this.debug('TestItem init');
    this.passButton = this.container.querySelector('#passButton');
    this.failButton = this.container.querySelector('#failButton');

    this.container.focus();

    this.container.addEventListener('keydown', this.handleKeydown.bind(this));
    this.container.addEventListener('mozvisibilitychange', this.visibilityChange.bind(this));
    this.onInit();
  }

  uninit() {
    this.debug('TestItem uninit');
    this.container.removeEventListener('keydown', this.handleKeydown.bind(this));
    this.container.removeEventListener('mozvisibilitychange', this.visibilityChange.bind(this));

    // clearTimeout(this._timer);
    this.onDeinit();
  };

  /**
   * Have something need init in test instance.
   * Need implement by inherit
   */
  onInit() {}

  /**
   * Have something need deinit in test instance.
   * Need implement by inherit
   */
  onDeinit() {}

  /**
   * A common visibility change handler
   */
  visibilityChange(event) {}

  /**
   * Have events need handle in test instance.
   * Need implement by inherit
   */
  onHandleEvent(evt) {
    this.debug('TestItem onHandleEvent');
    return false;
  }

  /**
   * A common keydown event handler of test items.
   * Can implement by inherit
   */
  handleKeydown(evt) {
    this.debug('TestItem handle keydown event: ' + evt.key);
    const p = new Promise((resolve, reject) => {
      let ret = this.onHandleEvent(evt);
      resolve(ret);
    }).then((ret) => {
      if (ret) {
        return;
      }
      if (evt.key) {
        switch (evt.key) {
          case 'SoftRight':
            if (this.failButton.disabled) {
              return;
            }
            this.uninit();

            let failDetail = {
              result: 'fail'
            };
            EventSender.emit('closeTest', failDetail);
            break;
          case 'SoftLeft':
            if (this.passButton.disabled) {
              return;
            }

            this.uninit();
            let passDetail = {
              result: 'pass'
            };
            EventSender.emit('closeTest', passDetail);
            break;
          case 'Up':
          case 'ArrowUp':
            break;
          case 'Down':
          case 'ArrowDown':
            break;
          case 'Backspace':
          case 'EndCall':
            evt.preventDefault();
            break;
        }
      }
    });
  }
}
