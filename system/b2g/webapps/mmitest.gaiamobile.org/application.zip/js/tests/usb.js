/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [usb.js] = ' + s + '\n');
    }
  }

  var UsbTest = new TestItem(render);

  UsbTest.result = {charger: false, usb: false};

  UsbTest.check = function() {
    let allDone = true;

    for (let i in this.result) {
      if (!this.result[i]) {
        allDone = false;
        break;
      }
    }

    if (allDone) {
      this.failButton.disabled = '';
      this.passButton.disabled = '';
    }
  };

  UsbTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    this.displayUsbInfo();
    return false;
  };

  UsbTest.displayUsbInfo = function() {
    if (this.battery.charging) {
      // charging, check usb cable.
      this.cableText.textContent = 'Please check:';
      this.chagerText.textContent = 'Charger: OK';
      this.result.charger = true;

      if (navigator.engmodeExtension) {
        // if get usb status immediately, the status would be DISCONNECTED
        setTimeout(() => {
          let request = navigator.engmodeExtension.getSysInfo('USB_CONNECT');
          request.onsuccess = () => {
            let isUsb = request.result;
            if (isUsb) {
              this.usbText.textContent = 'USB: OK';
              this.result.usb = true;
              this.check();
            }
          };
          request.onerror = () => {
            debug('get USB_CONNECT failed');
          };
        }, 1000);
      }
    } else {
      this.cableText.textContent = 'Please insert cable.';
      this.chagerText.textContent = 'unknown';
      this.usbText.textContent = 'unknown';
    }
  };

  UsbTest.onInit = function() {
    this.battery = navigator.battery;
    this.battery.addEventListener('chargingchange', this);

    this.cableText = this.container.querySelector('#cable');
    this.chagerText = this.container.querySelector('#charger');
    this.usbText = this.container.querySelector('#usb');

    this.passButton.disabled = 'disabled';
    this.failButton.disabled = '';
    this.displayUsbInfo();
  };

  UsbTest.onDeinit = function() {
    this.battery.removeEventListener('chargingchange', this);
  };

  function render() {
    return `
        <div id="title">USB</div>
        <div id="centertext">
          <div id="cable">Please insert USB cable.</div>
          <div id="charger">Charger: unknown</div>
          <div id="usb">USB: unknown</div>
        </div>`;
  }

  exports.Test = UsbTest;
}(window));
