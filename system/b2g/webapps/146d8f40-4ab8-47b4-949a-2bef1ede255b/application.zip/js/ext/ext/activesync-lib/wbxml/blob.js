function Blob(t, e) {
    this._parts = t;
    var n = 0;
    t.forEach(function(t) {
        n += t instanceof Blob ? t.size : t instanceof ArrayBuffer ? t.byteLength : t.length;
    }), this.size = n, this.type = e ? e.type : null;
}

function FileReader() {
    this.error = null, this.readyState = this.EMPTY, this.result = null, this.onabort = null, 
    this.onerror = null, this.onload = null, this.onloadend = null, this.onloadstart = null, 
    this.onprogress = null;
}

exports.Blob = Blob, Blob.prototype = {
    _asArrayBuffer: function() {
        var t = new ArrayBuffer(this.size), e = new Uint8Array(t), n = 0;
        return this._parts.forEach(function(t) {
            var r;
            if (t instanceof Blob) {
                var i = t._asArrayBuffer();
                r = new Uint8Array(i), e.set(r, n), n += r.length;
            } else if ("string" == typeof t) {
                var s = new TextEncoder("utf-8");
                r = s.encode(t), e.set(r, n), n += r.length;
            } else t instanceof ArrayBuffer ? (r = new Uint8Array(t), e.set(r, n), n += r.length) : (e.set(t, n), 
            n += t.length);
        }), t;
    }
}, exports.FileReader = FileReader, FileReader.prototype = {
    EMPTY: 0,
    LOADING: 1,
    DONE: 2,
    readAsArrayBuffer: function(t) {
        process.nextTick(function() {
            var t = {
                target: this
            };
            this.onload && this.onload(t), this.onloadend && this.onloadend(t);
        }.bind(this)), this.result = t._asArrayBuffer();
    },
    readAsBinaryString: function() {
        throw new Error("not implemented");
    },
    readAsDataURL: function() {
        throw new Error("not implemented");
    },
    readAsText: function() {
        throw new Error("not implemented");
    }
};