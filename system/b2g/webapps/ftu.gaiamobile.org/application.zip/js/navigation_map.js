/* global NavigationHelper */
'use strict';

(function(exports) {
  var NavigationMap = {
    currentActivatedLength: 0,
    init: function() {
      window.addEventListener('panelready', this.panelReadyHandler.bind(this));
    },

    setFocus: function (element) {
      if (!element) {
        return;
      }
      let focused = document.querySelectorAll('.focus');
      if (focused.length) {
        focused[0].classList.remove('focus');
      }
      element.setAttribute('tabindex', 1);
      element.classList.add('focus');
      if ('undefined' !== typeof inputHandler) {
        inputHandler.focusChanged(element);
      } else {
        element.focus();
      }
    },

    registerPanelNavigation: function (navInfo) {
      let noSetfocus = navInfo.noSetfocus || navInfo.noFocusWindow;
      let bootFocusElement = NavigationHelper.reset(
          navInfo.navigator,
          navInfo.controls,
          navInfo.defaultFocusIndex,
          navInfo.curViewId,
          noSetfocus
      );
      if (noSetfocus && navInfo.noFocusWindow) {
        this.setFocus(bootFocusElement);
      }
      return bootFocusElement;
    },

    focusChanged: function (element) {
      element.focus();
      // XXX: Code like this, put scroll func into event queue, only
      // run scroll when main process free.
      setTimeout(() => {element.scrollIntoView(true);});
    },

    scrollToElement: function (element, event) {
      NavigationHelper.scrollToElement(element, event, 50, 40);
    },


    panelReadyHandler: function (event) {
      var navInfo = event.detail;
      var panel = navInfo.panel;
      this.focusedElement = this.registerPanelNavigation(navInfo);
      if (this.focusedElement) {
        if (WifiManager.resetFocus) {
          this.focusChanged(this.focusedElement);
        }

        if (panel.CLASS_NAME !== 'BasePanel') {
          panel.ready = true;
        }
      }
    }
  };

  exports.NavigationMap = NavigationMap;
}(window));
