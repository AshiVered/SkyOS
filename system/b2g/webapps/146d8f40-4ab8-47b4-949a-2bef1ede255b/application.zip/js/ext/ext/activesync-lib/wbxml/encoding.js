(function(e) {
    function n(e, n, t) {
        return e >= n && t >= e;
    }
    function t(e, n) {
        return Math.floor(e / n);
    }
    function r(e) {
        var n = 0;
        this.get = function() {
            return n >= e.length ? z : Number(e[n]);
        }, this.offset = function(t) {
            if (n += t, 0 > n) throw new Error("Seeking past start of the buffer");
            if (n > e.length) throw new Error("Seeking past EOF");
        }, this.match = function(t) {
            if (t.length > n + e.length) return !1;
            var r;
            for (r = 0; r < t.length; r += 1) if (Number(e[n + r]) !== t[r]) return !1;
            return !0;
        };
    }
    function i(e) {
        var n = 0;
        this.emit = function() {
            var t, r = z;
            for (t = 0; t < arguments.length; ++t) r = Number(arguments[t]), e[n++] = r;
            return r;
        };
    }
    function o(e) {
        var t = 0, r = function() {
            for (var t = [], r = 0, i = e.length; r < e.length; ) {
                var o = e.charCodeAt(r);
                if (n(o, 55296, 57343)) if (n(o, 56320, 57343)) t.push(65533); else if (r === i - 1) t.push(65533); else {
                    var s = e.charCodeAt(r + 1);
                    if (n(s, 56320, 57343)) {
                        var a = 1023 & o, u = 1023 & s;
                        r += 1, t.push(65536 + (a << 10) + u);
                    } else t.push(65533);
                } else t.push(o);
                r += 1;
            }
            return t;
        }();
        this.offset = function(e) {
            if (t += e, 0 > t) throw new Error("Seeking past start of the buffer");
            if (t > r.length) throw new Error("Seeking past EOF");
        }, this.get = function() {
            return t >= r.length ? N : r[t];
        };
    }
    function s() {
        var e = "";
        this.string = function() {
            return e;
        }, this.emit = function(n) {
            65535 >= n ? e += String.fromCharCode(n) : (n -= 65536, e += String.fromCharCode(55296 + (1023 & n >> 10)), 
            e += String.fromCharCode(56320 + (1023 & n)));
        };
    }
    function a(e, n) {
        if (e) throw new Error("EncodingError");
        return n || 65533;
    }
    function u() {
        throw new Error("EncodingError");
    }
    function f(e) {
        if (e = String(e).trim().toLowerCase(), Object.prototype.hasOwnProperty.call(q, e)) return q[e];
        throw new Error("EncodingError: Unknown encoding: " + e);
    }
    function l(e, n) {
        return (n || [])[e] || null;
    }
    function c(e, n) {
        var t = n.indexOf(e);
        return -1 === t ? null : t;
    }
    function d(e) {
        if (e > 39419 && 189e3 > e || e > 1237575) return null;
        var n, t = 0, r = 0, i = R.gb18030;
        for (n = 0; n < i.length; ++n) {
            var o = i[n];
            if (!(o[0] <= e)) break;
            t = o[0], r = o[1];
        }
        return r + e - t;
    }
    function g(e) {
        var n, t = 0, r = 0, i = R.gb18030;
        for (n = 0; n < i.length; ++n) {
            var o = i[n];
            if (!(o[1] <= e)) break;
            t = o[1], r = o[0];
        }
        return r + e - t;
    }
    function m(e) {
        var t = e.fatal, r = 0, i = 0, o = 0, s = 0;
        this.decode = function(e) {
            var u = e.get();
            if (u === z) return 0 !== i ? (i = 0, a(t)) : N;
            if (e.offset(1), 0 === i) {
                if (n(u, 0, 127)) return u;
                if (n(u, 194, 223)) i = 1, s = 128, r = u - 192; else if (n(u, 224, 239)) i = 2, 
                s = 2048, r = u - 224; else {
                    if (!n(u, 240, 244)) return a(t);
                    i = 3, s = 65536, r = u - 240;
                }
                return r *= Math.pow(64, i), null;
            }
            if (!n(u, 128, 191)) return r = 0, i = 0, o = 0, s = 0, e.offset(-1), a(t);
            if (o += 1, r += (u - 128) * Math.pow(64, i - o), o !== i) return null;
            var f = r, l = s;
            return r = 0, i = 0, o = 0, s = 0, n(f, l, 1114111) && !n(f, 55296, 57343) ? f : a(t);
        };
    }
    function h(e) {
        e.fatal, this.encode = function(e, r) {
            var i = r.get();
            if (i === N) return z;
            if (r.offset(1), n(i, 55296, 57343)) return u(i);
            if (n(i, 0, 127)) return e.emit(i);
            var o, s;
            n(i, 128, 2047) ? (o = 1, s = 192) : n(i, 2048, 65535) ? (o = 2, s = 224) : n(i, 65536, 1114111) && (o = 3, 
            s = 240);
            for (var a = e.emit(t(i, Math.pow(64, o)) + s); o > 0; ) {
                var f = t(i, Math.pow(64, o - 1));
                a = e.emit(128 + f % 64), o -= 1;
            }
            return a;
        };
    }
    function w(e, t) {
        var r = t.fatal;
        this.decode = function(t) {
            var i = t.get();
            if (i === z) return N;
            if (t.offset(1), n(i, 0, 127)) return i;
            var o = e[i - 128];
            return null === o ? a(r) : o;
        };
    }
    function b(e, t) {
        t.fatal, this.encode = function(t, r) {
            var i = r.get();
            if (i === N) return z;
            if (r.offset(1), n(i, 0, 127)) return t.emit(i);
            var o = c(i, e);
            return null === o && u(i), t.emit(o + 128);
        };
    }
    function v(e, t) {
        var r = t.fatal, i = 0, o = 0, s = 0;
        this.decode = function(t) {
            var u = t.get();
            if (u === z && 0 === i && 0 === o && 0 === s) return N;
            u !== z || 0 === i && 0 === o && 0 === s || (i = 0, o = 0, s = 0, a(r)), t.offset(1);
            var f;
            if (0 !== s) return f = null, n(u, 48, 57) && (f = d(10 * (126 * (10 * (i - 129) + (o - 48)) + (s - 129)) + u - 48)), 
            i = 0, o = 0, s = 0, null === f ? (t.offset(-3), a(r)) : f;
            if (0 !== o) return n(u, 129, 254) ? (s = u, null) : (t.offset(-2), i = 0, o = 0, 
            a(r));
            if (0 !== i) {
                if (n(u, 48, 57) && e) return o = u, null;
                var c = i, g = null;
                i = 0;
                var m = 127 > u ? 64 : 65;
                return (n(u, 64, 126) || n(u, 128, 254)) && (g = 190 * (c - 129) + (u - m)), f = null === g ? null : l(g, R.gbk), 
                null === g && t.offset(-1), null === f ? a(r) : f;
            }
            return n(u, 0, 127) ? u : 128 === u ? 8364 : n(u, 129, 254) ? (i = u, null) : a(r);
        };
    }
    function p(e, r) {
        r.fatal, this.encode = function(r, i) {
            var o = i.get();
            if (o === N) return z;
            if (i.offset(1), n(o, 0, 127)) return r.emit(o);
            var s = c(o, R.gbk);
            if (null !== s) {
                var a = t(s, 190) + 129, f = s % 190, l = 63 > f ? 64 : 65;
                return r.emit(a, f + l);
            }
            if (null === s && !e) return u(o);
            s = g(o);
            var d = t(t(t(s, 10), 126), 10);
            s -= 10 * 126 * 10 * d;
            var m = t(t(s, 10), 126);
            s -= 126 * 10 * m;
            var h = t(s, 10), w = s - 10 * h;
            return r.emit(d + 129, m + 48, h + 129, w + 48);
        };
    }
    function _(e) {
        var t = e.fatal, r = !1, i = 0;
        this.decode = function(e) {
            var o = e.get();
            if (o === z && 0 === i) return N;
            if (o === z && 0 !== i) return i = 0, a(t);
            if (e.offset(1), 126 === i) return i = 0, 123 === o ? (r = !0, null) : 125 === o ? (r = !1, 
            null) : 126 === o ? 126 : 10 === o ? null : (e.offset(-1), a(t));
            if (0 !== i) {
                var s = i;
                i = 0;
                var u = null;
                return n(o, 33, 126) && (u = l(190 * (s - 1) + (o + 63), R.gbk)), 10 === o && (r = !1), 
                null === u ? a(t) : u;
            }
            return 126 === o ? (i = 126, null) : r ? n(o, 32, 127) ? (i = o, null) : (10 === o && (r = !1), 
            a(t)) : n(o, 0, 127) ? o : a(t);
        };
    }
    function k(e) {
        e.fatal;
        var r = !1;
        this.encode = function(e, i) {
            var o = i.get();
            if (o === N) return z;
            if (i.offset(1), n(o, 0, 127) && r) return i.offset(-1), r = !1, e.emit(126, 125);
            if (126 === o) return e.emit(126, 126);
            if (n(o, 0, 127)) return e.emit(o);
            if (!r) return i.offset(-1), r = !0, e.emit(126, 123);
            var s = c(o, R.gbk);
            if (null === s) return u(o);
            var a = t(s, 190) + 1, f = s % 190 - 63;
            return n(a, 33, 126) && n(f, 33, 126) ? e.emit(a, f) : u(o);
        };
    }
    function I(e) {
        var t = e.fatal, r = 0, i = null;
        this.decode = function(e) {
            if (null !== i) {
                var o = i;
                return i = null, o;
            }
            var s = e.get();
            if (s === z && 0 === r) return N;
            if (s === z && 0 !== r) return r = 0, a(t);
            if (e.offset(1), 0 !== r) {
                var u = r, f = null;
                r = 0;
                var c = 127 > s ? 64 : 98;
                if ((n(s, 64, 126) || n(s, 161, 254)) && (f = 157 * (u - 129) + (s - c)), 1133 === f) return i = 772, 
                202;
                if (1135 === f) return i = 780, 202;
                if (1164 === f) return i = 772, 234;
                if (1166 === f) return i = 780, 234;
                var d = null === f ? null : l(f, R.big5);
                return null === f && e.offset(-1), null === d ? a(t) : d;
            }
            return n(s, 0, 127) ? s : n(s, 129, 254) ? (r = s, null) : a(t);
        };
    }
    function E(e) {
        e.fatal, this.encode = function(e, r) {
            var i = r.get();
            if (i === N) return z;
            if (r.offset(1), n(i, 0, 127)) return e.emit(i);
            var o = c(i, R.big5);
            if (null === o) return u(i);
            var s = t(o, 157) + 129, a = o % 157, f = 63 > a ? 64 : 98;
            return e.emit(s, a + f);
        };
    }
    function S(e) {
        var t = e.fatal, r = 0, i = 0;
        this.decode = function(e) {
            var o = e.get();
            if (o === z) return 0 === r && 0 === i ? N : (r = 0, i = 0, a(t));
            e.offset(1);
            var s, u;
            return 0 !== i ? (s = i, i = 0, u = null, n(s, 161, 254) && n(o, 161, 254) && (u = l(94 * (s - 161) + o - 161, R.jis0212)), 
            n(o, 161, 254) || e.offset(-1), null === u ? a(t) : u) : 142 === r && n(o, 161, 223) ? (r = 0, 
            65377 + o - 161) : 143 === r && n(o, 161, 254) ? (r = 0, i = o, null) : 0 !== r ? (s = r, 
            r = 0, u = null, n(s, 161, 254) && n(o, 161, 254) && (u = l(94 * (s - 161) + o - 161, R.jis0208)), 
            n(o, 161, 254) || e.offset(-1), null === u ? a(t) : u) : n(o, 0, 127) ? o : 142 === o || 143 === o || n(o, 161, 254) ? (r = o, 
            null) : a(t);
        };
    }
    function j(e) {
        e.fatal, this.encode = function(e, r) {
            var i = r.get();
            if (i === N) return z;
            if (r.offset(1), n(i, 0, 127)) return e.emit(i);
            if (165 === i) return e.emit(92);
            if (8254 === i) return e.emit(126);
            if (n(i, 65377, 65439)) return e.emit(142, i - 65377 + 161);
            var o = c(i, R.jis0208);
            if (null === o) return u(i);
            var s = t(o, 94) + 161, a = o % 94 + 161;
            return e.emit(s, a);
        };
    }
    function y(e) {
        var t = e.fatal, r = {
            ASCII: 0,
            escape_start: 1,
            escape_middle: 2,
            escape_final: 3,
            lead: 4,
            trail: 5,
            Katakana: 6
        }, i = r.ASCII, o = !1, s = 0;
        this.decode = function(e) {
            var u = e.get();
            switch (u !== z && e.offset(1), i) {
              default:
              case r.ASCII:
                return 27 === u ? (i = r.escape_start, null) : n(u, 0, 127) ? u : u === z ? N : a(t);

              case r.escape_start:
                return 36 === u || 40 === u ? (s = u, i = r.escape_middle, null) : (u !== z && e.offset(-1), 
                i = r.ASCII, a(t));

              case r.escape_middle:
                var f = s;
                return s = 0, 36 !== f || 64 !== u && 66 !== u ? 36 === f && 40 === u ? (i = r.escape_final, 
                null) : 40 !== f || 66 !== u && 74 !== u ? 40 === f && 73 === u ? (i = r.Katakana, 
                null) : (u === z ? e.offset(-1) : e.offset(-2), i = r.ASCII, a(t)) : (i = r.ASCII, 
                null) : (o = !1, i = r.lead, null);

              case r.escape_final:
                return 68 === u ? (o = !0, i = r.lead, null) : (u === z ? e.offset(-2) : e.offset(-3), 
                i = r.ASCII, a(t));

              case r.lead:
                return 10 === u ? (i = r.ASCII, a(t, 10)) : 27 === u ? (i = r.escape_start, null) : u === z ? N : (s = u, 
                i = r.trail, null);

              case r.trail:
                if (i = r.lead, u === z) return a(t);
                var c = null, d = 94 * (s - 33) + u - 33;
                return n(s, 33, 126) && n(u, 33, 126) && (c = o === !1 ? l(d, R.jis0208) : l(d, R.jis0212)), 
                null === c ? a(t) : c;

              case r.Katakana:
                return 27 === u ? (i = r.escape_start, null) : n(u, 33, 95) ? 65377 + u - 33 : u === z ? N : a(t);
            }
        };
    }
    function C(e) {
        e.fatal;
        var r = {
            ASCII: 0,
            lead: 1,
            Katakana: 2
        }, i = r.ASCII;
        this.encode = function(e, o) {
            var s = o.get();
            if (s === N) return z;
            if (o.offset(1), (n(s, 0, 127) || 165 === s || 8254 === s) && i !== r.ASCII) return o.offset(-1), 
            i = r.ASCII, e.emit(27, 40, 66);
            if (n(s, 0, 127)) return e.emit(s);
            if (165 === s) return e.emit(92);
            if (8254 === s) return e.emit(126);
            if (n(s, 65377, 65439) && i !== r.Katakana) return o.offset(-1), i = r.Katakana, 
            e.emit(27, 40, 73);
            if (n(s, 65377, 65439)) return e.emit(s - 65377 - 33);
            if (i !== r.lead) return o.offset(-1), i = r.lead, e.emit(27, 36, 66);
            var a = c(s, R.jis0208);
            if (null === a) return u(s);
            var f = t(a, 94) + 33, l = a % 94 + 33;
            return e.emit(f, l);
        };
    }
    function A(e) {
        var t = e.fatal, r = 0;
        this.decode = function(e) {
            var i = e.get();
            if (i === z && 0 === r) return N;
            if (i === z && 0 !== r) return r = 0, a(t);
            if (e.offset(1), 0 !== r) {
                var o = r;
                if (r = 0, n(i, 64, 126) || n(i, 128, 252)) {
                    var s = 127 > i ? 64 : 65, u = 160 > o ? 129 : 193, f = l(188 * (o - u) + i - s, R.jis0208);
                    return null === f ? a(t) : f;
                }
                return e.offset(-1), a(t);
            }
            return n(i, 0, 128) ? i : n(i, 161, 223) ? 65377 + i - 161 : n(i, 129, 159) || n(i, 224, 252) ? (r = i, 
            null) : a(t);
        };
    }
    function x(e) {
        e.fatal, this.encode = function(e, r) {
            var i = r.get();
            if (i === N) return z;
            if (r.offset(1), n(i, 0, 128)) return e.emit(i);
            if (165 === i) return e.emit(92);
            if (8254 === i) return e.emit(126);
            if (n(i, 65377, 65439)) return e.emit(i - 65377 + 161);
            var o = c(i, R.jis0208);
            if (null === o) return u(i);
            var s = t(o, 188), a = 31 > s ? 129 : 193, f = o % 188, l = 63 > f ? 64 : 65;
            return e.emit(s + a, f + l);
        };
    }
    function D(e) {
        var t = e.fatal, r = 0;
        this.decode = function(e) {
            var i = e.get();
            if (i === z && 0 === r) return N;
            if (i === z && 0 !== r) return r = 0, a(t);
            if (e.offset(1), 0 !== r) {
                var o = r, s = null;
                if (r = 0, n(o, 129, 198)) {
                    var u = 178 * (o - 129);
                    n(i, 65, 90) ? s = u + i - 65 : n(i, 97, 122) ? s = u + 26 + i - 97 : n(i, 129, 254) && (s = u + 26 + 26 + i - 129);
                }
                n(o, 199, 253) && n(i, 161, 254) && (s = 12460 + 94 * (o - 199) + (i - 161));
                var f = null === s ? null : l(s, R["euc-kr"]);
                return null === s && e.offset(-1), null === f ? a(t) : f;
            }
            return n(i, 0, 127) ? i : n(i, 129, 253) ? (r = i, null) : a(t);
        };
    }
    function O(e) {
        e.fatal, this.encode = function(e, r) {
            var i = r.get();
            if (i === N) return z;
            if (r.offset(1), n(i, 0, 127)) return e.emit(i);
            var o = c(i, R["euc-kr"]);
            if (null === o) return u(i);
            var s, a;
            if (12460 > o) {
                s = t(o, 178) + 129, a = o % 178;
                var f = 26 > a ? 65 : 52 > a ? 71 : 77;
                return e.emit(s, a + f);
            }
            return o -= 12460, s = t(o, 94) + 199, a = o % 94 + 161, e.emit(s, a);
        };
    }
    function M(e) {
        var t = e.fatal, r = {
            ASCII: 0,
            escape_start: 1,
            escape_middle: 2,
            escape_end: 3,
            lead: 4,
            trail: 5
        }, i = r.ASCII, o = 0;
        this.decode = function(e) {
            var s = e.get();
            switch (s !== z && e.offset(1), i) {
              default:
              case r.ASCII:
                return 14 === s ? (i = r.lead, null) : 15 === s ? null : 27 === s ? (i = r.escape_start, 
                null) : n(s, 0, 127) ? s : s === z ? N : a(t);

              case r.escape_start:
                return 36 === s ? (i = r.escape_middle, null) : (s !== z && e.offset(-1), i = r.ASCII, 
                a(t));

              case r.escape_middle:
                return 41 === s ? (i = r.escape_end, null) : (s === z ? e.offset(-1) : e.offset(-2), 
                i = r.ASCII, a(t));

              case r.escape_end:
                return 67 === s ? (i = r.ASCII, null) : (s === z ? e.offset(-2) : e.offset(-3), 
                i = r.ASCII, a(t));

              case r.lead:
                return 10 === s ? (i = r.ASCII, a(t, 10)) : 14 === s ? null : 15 === s ? (i = r.ASCII, 
                null) : s === z ? N : (o = s, i = r.trail, null);

              case r.trail:
                if (i = r.lead, s === z) return a(t);
                var u = null;
                return n(o, 33, 70) && n(s, 33, 126) ? u = l(178 * (o - 1) + 26 + 26 + s - 1, R["euc-kr"]) : n(o, 71, 126) && n(s, 33, 126) && (u = l(12460 + 94 * (o - 71) + (s - 33), R["euc-kr"])), 
                null !== u ? u : a(t);
            }
        };
    }
    function L(e) {
        e.fatal;
        var r = {
            ASCII: 0,
            lead: 1
        }, i = !1, o = r.ASCII;
        this.encode = function(e, s) {
            var a = s.get();
            if (a === N) return z;
            if (i || (i = !0, e.emit(27, 36, 41, 67)), s.offset(1), n(a, 0, 127) && o !== r.ASCII) return s.offset(-1), 
            o = r.ASCII, e.emit(15);
            if (n(a, 0, 127)) return e.emit(a);
            if (o !== r.lead) return s.offset(-1), o = r.lead, e.emit(14);
            var f = c(a, R["euc-kr"]);
            if (null === f) return u(a);
            var l, d;
            return 12460 > f ? (l = t(f, 178) + 1, d = f % 178 - 26 - 26 + 1, n(l, 33, 70) && n(d, 33, 126) ? e.emit(l, d) : u(a)) : (f -= 12460, 
            l = t(f, 94) + 71, d = f % 94 + 33, n(l, 71, 126) && n(d, 33, 126) ? e.emit(l, d) : u(a));
        };
    }
    function T(e, t) {
        var r = t.fatal, i = null, o = null;
        this.decode = function(t) {
            var s = t.get();
            if (s === z && null === i && null === o) return N;
            if (s === z && (null !== i || null !== o)) return a(r);
            if (t.offset(1), null === i) return i = s, null;
            var u;
            if (u = e ? (i << 8) + s : (s << 8) + i, i = null, null !== o) {
                var f = o;
                return o = null, n(u, 56320, 57343) ? 65536 + 1024 * (f - 55296) + (u - 56320) : (t.offset(-2), 
                a(r));
            }
            return n(u, 55296, 56319) ? (o = u, null) : n(u, 56320, 57343) ? a(r) : u;
        };
    }
    function K(e, r) {
        r.fatal, this.encode = function(r, i) {
            function o(n) {
                var t = n >> 8, i = 255 & n;
                return e ? r.emit(t, i) : r.emit(i, t);
            }
            var s = i.get();
            if (s === N) return z;
            if (i.offset(1), n(s, 55296, 57343) && u(s), 65535 >= s) return o(s);
            var a = t(s - 65536, 1024) + 55296, f = (s - 65536) % 1024 + 56320;
            return o(a), o(f);
        };
    }
    function P(e, n) {
        return n.match([ 255, 254 ]) ? (n.offset(2), "utf-16") : n.match([ 254, 255 ]) ? (n.offset(2), 
        "utf-16be") : n.match([ 239, 187, 191 ]) ? (n.offset(3), "utf-8") : e;
    }
    function B(n, t) {
        return this && this !== e ? (n = n ? String(n) : Z, t = Object(t), this._encoding = f(n), 
        this._streaming = !1, this._encoder = null, this._options = {
            fatal: Boolean(t.fatal)
        }, Object.defineProperty ? Object.defineProperty(this, "encoding", {
            get: function() {
                return this._encoding.name;
            }
        }) : this.encoding = this._encoding.name, this) : new B(n, t);
    }
    function U(n, t) {
        return this && this !== e ? (n = n ? String(n) : Z, t = Object(t), this._encoding = f(n), 
        this._streaming = !1, this._decoder = null, this._options = {
            fatal: Boolean(t.fatal)
        }, Object.defineProperty ? Object.defineProperty(this, "encoding", {
            get: function() {
                return this._encoding.name;
            }
        }) : this.encoding = this._encoding.name, this) : new U(n, t);
    }
    var z = -1, N = -1, W = [ {
        encodings: [ {
            labels: [ "unicode-1-1-utf-8", "utf-8", "utf8" ],
            name: "utf-8"
        } ],
        heading: "The Encoding"
    }, {
        encodings: [ {
            labels: [ "cp864", "ibm864" ],
            name: "ibm864"
        }, {
            labels: [ "cp866", "ibm866" ],
            name: "ibm866"
        }, {
            labels: [ "csisolatin2", "iso-8859-2", "iso-ir-101", "iso8859-2", "iso_8859-2", "l2", "latin2" ],
            name: "iso-8859-2"
        }, {
            labels: [ "csisolatin3", "iso-8859-3", "iso_8859-3", "iso-ir-109", "l3", "latin3" ],
            name: "iso-8859-3"
        }, {
            labels: [ "csisolatin4", "iso-8859-4", "iso_8859-4", "iso-ir-110", "l4", "latin4" ],
            name: "iso-8859-4"
        }, {
            labels: [ "csisolatincyrillic", "cyrillic", "iso-8859-5", "iso_8859-5", "iso-ir-144" ],
            name: "iso-8859-5"
        }, {
            labels: [ "arabic", "csisolatinarabic", "ecma-114", "iso-8859-6", "iso_8859-6", "iso-ir-127" ],
            name: "iso-8859-6"
        }, {
            labels: [ "csisolatingreek", "ecma-118", "elot_928", "greek", "greek8", "iso-8859-7", "iso_8859-7", "iso-ir-126" ],
            name: "iso-8859-7"
        }, {
            labels: [ "csisolatinhebrew", "hebrew", "iso-8859-8", "iso-8859-8-i", "iso-ir-138", "iso_8859-8", "visual" ],
            name: "iso-8859-8"
        }, {
            labels: [ "csisolatin6", "iso-8859-10", "iso-ir-157", "iso8859-10", "l6", "latin6" ],
            name: "iso-8859-10"
        }, {
            labels: [ "iso-8859-13" ],
            name: "iso-8859-13"
        }, {
            labels: [ "iso-8859-14", "iso8859-14" ],
            name: "iso-8859-14"
        }, {
            labels: [ "iso-8859-15", "iso_8859-15" ],
            name: "iso-8859-15"
        }, {
            labels: [ "iso-8859-16" ],
            name: "iso-8859-16"
        }, {
            labels: [ "koi8-r", "koi8_r" ],
            name: "koi8-r"
        }, {
            labels: [ "koi8-u" ],
            name: "koi8-u"
        }, {
            labels: [ "csmacintosh", "mac", "macintosh", "x-mac-roman" ],
            name: "macintosh"
        }, {
            labels: [ "iso-8859-11", "tis-620", "windows-874" ],
            name: "windows-874"
        }, {
            labels: [ "windows-1250", "x-cp1250" ],
            name: "windows-1250"
        }, {
            labels: [ "windows-1251", "x-cp1251" ],
            name: "windows-1251"
        }, {
            labels: [ "ascii", "ansi_x3.4-1968", "csisolatin1", "iso-8859-1", "iso8859-1", "iso_8859-1", "l1", "latin1", "us-ascii", "windows-1252" ],
            name: "windows-1252"
        }, {
            labels: [ "cp1253", "windows-1253" ],
            name: "windows-1253"
        }, {
            labels: [ "csisolatin5", "iso-8859-9", "iso-ir-148", "l5", "latin5", "windows-1254" ],
            name: "windows-1254"
        }, {
            labels: [ "cp1255", "windows-1255" ],
            name: "windows-1255"
        }, {
            labels: [ "cp1256", "windows-1256" ],
            name: "windows-1256"
        }, {
            labels: [ "windows-1257" ],
            name: "windows-1257"
        }, {
            labels: [ "cp1258", "windows-1258" ],
            name: "windows-1258"
        }, {
            labels: [ "x-mac-cyrillic", "x-mac-ukrainian" ],
            name: "x-mac-cyrillic"
        } ],
        heading: "Legacy single-byte encodings"
    }, {
        encodings: [ {
            labels: [ "chinese", "csgb2312", "csiso58gb231280", "gb2312", "gbk", "gb_2312", "gb_2312-80", "iso-ir-58", "x-gbk" ],
            name: "gbk"
        }, {
            labels: [ "gb18030" ],
            name: "gb18030"
        }, {
            labels: [ "hz-gb-2312" ],
            name: "hz-gb-2312"
        } ],
        heading: "Legacy multi-byte Chinese (simplified) encodings"
    }, {
        encodings: [ {
            labels: [ "big5", "big5-hkscs", "cn-big5", "csbig5", "x-x-big5" ],
            name: "big5"
        } ],
        heading: "Legacy multi-byte Chinese (traditional) encodings"
    }, {
        encodings: [ {
            labels: [ "cseucpkdfmtjapanese", "euc-jp", "x-euc-jp" ],
            name: "euc-jp"
        }, {
            labels: [ "csiso2022jp", "iso-2022-jp" ],
            name: "iso-2022-jp"
        }, {
            labels: [ "csshiftjis", "ms_kanji", "shift-jis", "shift_jis", "sjis", "windows-31j", "x-sjis" ],
            name: "shift_jis"
        } ],
        heading: "Legacy multi-byte Japanese encodings"
    }, {
        encodings: [ {
            labels: [ "cseuckr", "csksc56011987", "euc-kr", "iso-ir-149", "korean", "ks_c_5601-1987", "ks_c_5601-1989", "ksc5601", "ksc_5601", "windows-949" ],
            name: "euc-kr"
        }, {
            labels: [ "csiso2022kr", "iso-2022-kr" ],
            name: "iso-2022-kr"
        } ],
        heading: "Legacy multi-byte Korean encodings"
    }, {
        encodings: [ {
            labels: [ "utf-16", "utf-16le" ],
            name: "utf-16"
        }, {
            labels: [ "utf-16be" ],
            name: "utf-16be"
        } ],
        heading: "Legacy utf-16 encodings"
    } ], F = {}, q = {};
    W.forEach(function(e) {
        e.encodings.forEach(function(e) {
            F[e.name] = e, e.labels.forEach(function(n) {
                q[n] = e;
            });
        });
    });
    var R = e["encoding-indexes"] || {};
    F["utf-8"].getEncoder = function(e) {
        return new h(e);
    }, F["utf-8"].getDecoder = function(e) {
        return new m(e);
    }, function() {
        [ "ibm864", "ibm866", "iso-8859-2", "iso-8859-3", "iso-8859-4", "iso-8859-5", "iso-8859-6", "iso-8859-7", "iso-8859-8", "iso-8859-10", "iso-8859-13", "iso-8859-14", "iso-8859-15", "iso-8859-16", "koi8-r", "koi8-u", "macintosh", "windows-874", "windows-1250", "windows-1251", "windows-1252", "windows-1253", "windows-1254", "windows-1255", "windows-1256", "windows-1257", "windows-1258", "x-mac-cyrillic" ].forEach(function(e) {
            var n = F[e], t = R[e];
            n.getDecoder = function(e) {
                return new w(t, e);
            }, n.getEncoder = function(e) {
                return new b(t, e);
            };
        });
    }(), F.gbk.getEncoder = function(e) {
        return new p(!1, e);
    }, F.gbk.getDecoder = function(e) {
        return new v(!1, e);
    }, F.gb18030.getEncoder = function(e) {
        return new p(!0, e);
    }, F.gb18030.getDecoder = function(e) {
        return new v(!0, e);
    }, F["hz-gb-2312"].getEncoder = function(e) {
        return new k(e);
    }, F["hz-gb-2312"].getDecoder = function(e) {
        return new _(e);
    }, F.big5.getEncoder = function(e) {
        return new E(e);
    }, F.big5.getDecoder = function(e) {
        return new I(e);
    }, F["euc-jp"].getEncoder = function(e) {
        return new j(e);
    }, F["euc-jp"].getDecoder = function(e) {
        return new S(e);
    }, F["iso-2022-jp"].getEncoder = function(e) {
        return new C(e);
    }, F["iso-2022-jp"].getDecoder = function(e) {
        return new y(e);
    }, F.shift_jis.getEncoder = function(e) {
        return new x(e);
    }, F.shift_jis.getDecoder = function(e) {
        return new A(e);
    }, F["euc-kr"].getEncoder = function(e) {
        return new O(e);
    }, F["euc-kr"].getDecoder = function(e) {
        return new D(e);
    }, F["iso-2022-kr"].getEncoder = function(e) {
        return new L(e);
    }, F["iso-2022-kr"].getDecoder = function(e) {
        return new M(e);
    }, F["utf-16"].getEncoder = function(e) {
        return new K(!1, e);
    }, F["utf-16"].getDecoder = function(e) {
        return new T(!1, e);
    }, F["utf-16be"].getEncoder = function(e) {
        return new K(!0, e);
    }, F["utf-16be"].getDecoder = function(e) {
        return new T(!0, e);
    };
    var Z = "utf-8";
    B.prototype = {
        encode: function(e, n) {
            e = e ? String(e) : "", n = Object(n), this._streaming || (this._encoder = this._encoding.getEncoder(this._options)), 
            this._streaming = Boolean(n.stream);
            for (var t = [], r = new i(t), s = new o(e); s.get() !== N; ) this._encoder.encode(r, s);
            if (!this._streaming) {
                var a;
                do a = this._encoder.encode(r, s); while (a !== z);
                this._encoder = null;
            }
            return new Uint8Array(t);
        }
    }, U.prototype = {
        decode: function(e, n) {
            if (e && !("buffer" in e && "byteOffset" in e && "byteLength" in e)) throw new TypeError("Expected ArrayBufferView");
            e || (e = new Uint8Array(0)), n = Object(n), this._streaming || (this._decoder = this._encoding.getDecoder(this._options)), 
            this._streaming = Boolean(n.stream);
            var t = new Uint8Array(e.buffer, e.byteOffset, e.byteLength), i = new r(t), o = P(this._encoding.name, i);
            if (f(o) !== this._encoding) throw new Error("BOM mismatch");
            for (var a, u = new s(); i.get() !== z; ) a = this._decoder.decode(i), null !== a && a !== N && u.emit(a);
            if (!this._streaming) {
                do a = this._decoder.decode(i), null !== a && a !== N && u.emit(a); while (a !== N);
                this._decoder = null;
            }
            return u.string();
        }
    }, e.TextEncoder = e.TextEncoder || B, e.TextDecoder = e.TextDecoder || U;
})(this);