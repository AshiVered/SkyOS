/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  var FlashlightTest = new TestItem(render);

  FlashlightTest.onInit = function() {
    // Disable pass button first
    this.passButton.disabled = 'disabled';

    navigator.getFlashlightManager().then((manager) => {
      this.flashlightManager = manager;
      if (!manager.flashlightEnabled) {
        manager.flashlightEnabled = !manager.flashlightEnabled;
      }
      this.passButton.disabled = '';
    }, (e) => {
      this.passButton.disabled = '';
      debug('Couldn\'t get the flashlightManager. error: ' + e.name)
    });
  };

  FlashlightTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    return false;
  };

  FlashlightTest.onDeinit = function() {
    if (this.flashlightManager &&
      this.flashlightManager.flashlightEnabled) {
      this.flashlightManager.flashlightEnabled = false;
      this.flashlightManager = null;
    }
  };

  function render() {
    return `
        <div id ="title">Flashlight</div>
        <div id ="centertext">Is torch lightting?</div>`;
  }
  exports.Test = FlashlightTest;
}(window));
