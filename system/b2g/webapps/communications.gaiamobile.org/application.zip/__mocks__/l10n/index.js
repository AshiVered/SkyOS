window.document.documentElement = {
  dataset: {
    noCompleteBug: true
  }
};
