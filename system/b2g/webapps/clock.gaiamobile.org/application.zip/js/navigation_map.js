
(function(exports){var NavigationMap={'currentActivatedLength':0};exports.NavigationMap=NavigationMap;})(window);