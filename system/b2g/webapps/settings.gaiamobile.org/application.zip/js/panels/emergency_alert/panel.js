/* global SettingsSoftkey */
/**
 * Used to show Emergency alert panel
 */
define(['require','modules/settings_panel','shared/simslot_manager'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');

  return function ctor_emergency_alert_panel() {
    var elements = {};
    var settingElements = ["cmas.extreme.enabled", "cmas.severe.enabled",
      "cmas.amber.enabled", "cmas.monthlytest.enabled"];
    var listElements = document.querySelectorAll('#emergency-alert li');
    var softkeyParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: 'Deselect',
        l10nId: 'deselect',
        priority: 2,
        method: function() {}
      }]
    };
    var params = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: 'Select',
        l10nId: 'select',
        priority: 2
      }]
    };

    function _updateSoftkey() {
      var focusedElement = document.querySelector('#emergency-alert .focus');
      if (focusedElement && focusedElement.classList &&
          focusedElement.classList.contains('none-select')) {
        SettingsSoftkey.hide();
        return;
      }
      if (focusedElement && focusedElement.querySelector('input') &&
          focusedElement.querySelector('input').checked) {
        SettingsSoftkey.init(softkeyParams);
      } else {
        SettingsSoftkey.init(params);
      }
      SettingsSoftkey.show();
    }

    function _initAlertSettingListener() {
      var i = settingElements.length - 1;
      for (i; i >= 0; i--) {
        SettingsListener.observe(settingElements[i], true, _updateSoftkey);
      }
      /* << [BTS-3012]: BDC kanxj 20200306 add for IT alert */
      let alertItMenu = document.getElementById('emergency-alert-it-menu');
      alertItMenu.addEventListener('change', _showToast);
      /* >> [BTS-3012] */
    }

    function _removeAlertSettingListener() {
      var i = settingElements.length - 1;
      for (i; i >= 0; i--) {
        SettingsListener.unobserve(settingElements[i] , _updateSoftkey());
      }
      /* << [BTS-3012]: BDC kanxj 20200306 add for IT alert */
      let alertItMenu = document.getElementById('emergency-alert-it-menu');
      alertItMenu.removeEventListener('change', _showToast);
      /* >> [BTS-3012] */
    }

    /* << [BTS-3012]: BDC kanxj 20200306 add for IT alert */
    function _showToast() {
      showToast('cb-ita-IT-Alert-pop-toast');
    }
    /* >> [BTS-3012] */

    function _keyDownHandler(evt) {
      switch (evt.key) {
        case 'Enter':
          if ('alert-inbox' === evt.target.id) {
            try {
              new MozActivity({
                name: 'alert_inbox'
              });
            } catch (e) {
              console.error('Failed to create an alert_inbox activity: ' + e);
            }
          } else if ('ringtone-preview' === evt.target.id) {
            try {
              new MozActivity({
                name: 'ringtone_preview'
              });
            } catch (e) {
              console.error('Failed to create an alert_inbox activity: ' + e);
            }
          }
          break;
        default:
          break;
      }
    }

    /* << [LIO-1690]: BDC kanxj 20201109 add for The mandatory CMAS channels are not defaultly enabled */
    function initUAEMenu() {
      console.log('Emergency-alert customization operator is UAE');
      var nationalEmergencyAlertUaeMenu = document.getElementById('national-emergency-alert-uae-menu');
      var emergencyAlertUaeMenu = document.getElementById('emergency-alert-uae-menu');
      var warningAlertUaeMenu = document.getElementById('warning-alert-uae-menu');
      var testAlertUaeMenu = document.getElementById('test-alert-uae-menu');
      var exerciseUaeMenu = document.getElementById('exercise-uae-menu');
      nationalEmergencyAlertUaeMenu.removeAttribute('hidden');
      emergencyAlertUaeMenu.removeAttribute('hidden');
      warningAlertUaeMenu.removeAttribute('hidden');
      testAlertUaeMenu.removeAttribute('hidden');
      //exerciseUaeMenu.removeAttribute('hidden');

      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');
      cmasPresidentialMenu.classList.add('hidden');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');

    }

    function initILMenu() {
      console.log('Emergency-alert customization operator is IL');
      var extremeAlertIlMenu = document.getElementById('extreme-alert-il-menu');
      var warningNotificationIlMenu = document.getElementById('warning-notification-il-menu');
      var informationalIlMenu = document.getElementById('informational-il-menu');
      var testAlertIlMenu = document.getElementById('test-alert-il-menu');
      var exerciseIlMenu = document.getElementById('exercise-il-menu');
      var assistanceIlMenu = document.getElementById('assistance-il-menu');
      extremeAlertIlMenu.removeAttribute('hidden');
      warningNotificationIlMenu.removeAttribute('hidden');
      informationalIlMenu.removeAttribute('hidden');
      testAlertIlMenu.removeAttribute('hidden');
      exerciseIlMenu.removeAttribute('hidden');
      assistanceIlMenu.removeAttribute('hidden');

      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');
      cmasPresidentialMenu.classList.add('hidden');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');
    }

    function initLTMenu() {
      console.log('Emergency-alert customization operator is LT');
      var nationalEmergencyAlertLtMenu = document.getElementById('national-emergency-alert-lt-menu');
      var emergencyAlertLtMenu = document.getElementById('emergency-alert-lt-menu');
      var warningAlertLtMenu = document.getElementById('warning-alert-lt-menu');
      var testAlertLtMenu = document.getElementById('test-alert-lt-menu');
      nationalEmergencyAlertLtMenu.removeAttribute('hidden');
      emergencyAlertLtMenu.removeAttribute('hidden');
      warningAlertLtMenu.removeAttribute('hidden');
      testAlertLtMenu.removeAttribute('hidden');

      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');
      cmasPresidentialMenu.classList.add('hidden');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');
    }

    function initNLMenu() {
      console.log('Emergency-alert customization operator is NL');
      var alertNlMenu = document.getElementById('alert-nl-menu');
      alertNlMenu.removeAttribute('hidden');
      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');
      cmasPresidentialMenu.classList.add('hidden');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');
    }

    function initTWMenu() {
      console.log('Emergency-alert customization operator is TW');
      var emergencyAlertTWMenu = document.getElementById('emergency-alert-tw-menu');
      var emergencyMessageTWMenu = document.getElementById('emergency-message-tw-menu');
      emergencyAlertTWMenu.removeAttribute('hidden');
      emergencyMessageTWMenu.removeAttribute('hidden');

      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var ringtonePreviewMenu = document.getElementById('ringtone-preview-menu');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      ringtonePreviewMenu.classList.add('hidden');
    }

    function initROMenu() {
      console.log('Emergency-alert customization operator is RO');
      var presidentialAlertRoMenu = document.getElementById('presidential-alert-ro-menu');
      var extremeRoMenu = document.getElementById('extreme-alert-ro-menu');
      var severeRoMenu = document.getElementById('severe-alert-ro-menu');
      var amberRoMenu = document.getElementById('amber-alert-ro-menu');
      var exerciseRoMenu = document.getElementById('exercise-alert-ro-menu');
      presidentialAlertRoMenu.removeAttribute('hidden');
      extremeRoMenu.removeAttribute('hidden');
      severeRoMenu.removeAttribute('hidden');
      amberRoMenu.removeAttribute('hidden');
      exerciseRoMenu.removeAttribute('hidden');

      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');
      cmasPresidentialMenu.classList.add('hidden');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');
    }

    function initKRMenu() {
      console.log('Emergency-alert customization operator is KR');
      var emergencyAlertTWMenu = document.getElementById('emergency-alert-tw-menu');
      var emergencyMessageTWMenu = document.getElementById('emergency-message-tw-menu');
      emergencyAlertTWMenu.classList.add('hidden');
      emergencyMessageTWMenu.classList.add('hidden');

      var exerciseAlertMenu = document.getElementById('exercise-alert-menu');
      var requiredMonthlyTestMenu = document.getElementById('required-monthly-test-menu');
      exerciseAlertMenu.classList.add('hidden');
      requiredMonthlyTestMenu.classList.add('hidden');
    }

    function initITMenu() {
      console.log('Emergency-alert customization operator is IT');
      var alertItMenu = document.getElementById('emergency-alert-it-menu');
      var testItMenu = document.getElementById('test-alert-it-menu');
      alertItMenu.removeAttribute('hidden');
      testItMenu.removeAttribute('hidden');

      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');

      cmasPresidentialMenu.classList.add('hidden');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');
    }

    function initKSAMenu() {
      console.log('Emergency-alert customization operator KSA ');
      var alertKsaMenu = document.getElementById('emergency-alert-ksa-menu');
      var extremeKsaMenu = document.getElementById('extreme-alert-ksa-menu');
      var warningKsaMenu = document.getElementById('warning-alert-ksa-menu');
      var amberKsaMenu = document.getElementById('amber-alert-ksa-menu');
      var testKsaMenu = document.getElementById('test-alert-ksa-menu');
      var exerciseKsaMenu = document.getElementById('exercise-alert-ksa-menu');
      alertKsaMenu.removeAttribute('hidden');
      extremeKsaMenu.removeAttribute('hidden');
      warningKsaMenu.removeAttribute('hidden');
      amberKsaMenu.removeAttribute('hidden');
      testKsaMenu.removeAttribute('hidden');
      exerciseKsaMenu.removeAttribute('hidden');

      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasExtremeMenu = document.getElementById('cmas-extreme-menu');
      var cmasSevereMenu = document.getElementById('cmas-severe-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');
      var safetyMenu = document.getElementById('cmas-safety-menu');
      var weatestMenu = document.getElementById('cmas-weatest-menu');

      cmasPresidentialMenu.classList.add('hidden');
      cmasExtremeMenu.classList.add('hidden');
      cmasSevereMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');
      safetyMenu.classList.add('hidden');
      weatestMenu.classList.add('hidden');
    }
    /* >> [LIO-1817] */
    /* << [BTS-3450]: BDC kanxj 20210219 UK Cell Broadcast requirement */
    function initUKMenu() {
      console.log('Emergency-alert customization operator UK ');
      var nationalAlertMenu = document.getElementById('national-emergency-alert-UK-menu');
      var testAlertMenu = document.getElementById('test-alert-UK-menu');
      var operatorAlertMenu = document.getElementById('opertor-alert-UK-menu');

      nationalAlertMenu.removeAttribute('hidden');
      testAlertMenu.removeAttribute('hidden');
      operatorAlertMenu.removeAttribute('hidden');

      var cmasPresidentialMenu = document.getElementById('cmas-presidential-menu');
      var cmasAmberMenu = document.getElementById('cmas-amber-menu');
      var monthlytestMenu = document.getElementById('required-monthly-test-menu');
      var exerciseMenu = document.getElementById('exercise-alert-menu');
      var safetyMenu = document.getElementById('cmas-safety-menu');
      var weatestMenu = document.getElementById('cmas-weatest-menu');

      cmasPresidentialMenu.classList.add('hidden');
      cmasAmberMenu.classList.add('hidden');
      monthlytestMenu.classList.add('hidden');
      exerciseMenu.classList.add('hidden');
      safetyMenu.classList.add('hidden');
      weatestMenu.classList.add('hidden');
    }
    /* >> [BTS-3450] */

    function initCustomizationMenu(operator) {
      //For test
      console.log('Emergency-alert initCustomizationMenu operator: ' + operator);
      //operator='KSA';
      if (operator !== 'IL' && operator !== 'UAE') {
        var exerciseAlertMenu = document.getElementById('exercise-alert-menu');
        exerciseAlertMenu.classList.add('hidden');
        exerciseAlertMenu.classList.remove('navigable');
      }
      console.log('Emergency-alert initCustomizationMenu 2 operator: ' + operator);

      if (operator == 'UAE') {
        initUAEMenu();
      } else if (operator == 'IL') {
        initILMenu();
      } else if (operator == 'LT') {
        initLTMenu();
      } else if (operator == 'NL') {
        initNLMenu();
      } else if (operator === 'TW') {
        initTWMenu();
      } else if (operator === 'RO') {
        initROMenu();
      } else if (operator === 'KR') {
        initKRMenu();
      } else if (operator === 'IT') {
        initITMenu();
      } else if (operator === 'KSA') {
        initKSAMenu();
      } else if (operator === 'UK') {
         initUKMenu();
      }
    }
    /* >> [LIO-1690] */


     // Task5758730-chengyanzhang@t2mobile.com-for add exercise alert message-begin
    function _disableSomeMenu() {// bug4000-chengyanzhang@t2mobile.com-modify
      /* << [LIO-1690]: BDC kanxj 20201109 add for The mandatory CMAS channels are not defaultly enabled */
      var SIMSlotManager = require('shared/simslot_manager');
      let isNoSim = SIMSlotManager.noSIMCardOnDevice();
      if (!isNoSim) {
        var slots = SIMSlotManager.getSlots();
        let matchInfo = {
          "clientId": "0"
        };
        if (!slots[0].isAbsent()) {
          matchInfo.clientId = '0';
        } else if (!slots[1].isAbsent()) {
          matchInfo.clientId = '1';
        }
        navigator.customization.getValueForCarrier(matchInfo, 'def.operator.name').then((operator) => {
          console.log('Emergency-alert getValueForCarrier operator: ' + operator);
          if (operator === undefined) {
            return;
          }
          initCustomizationMenu(operator);
        });
      } else {
        navigator.customization.getValue("def.operator.name").then((operator) => {
          console.log('Emergency-alert customization operator: ' + operator);
          if (operator === undefined) {
            return;
          }
          initCustomizationMenu(operator);
        });
      }
      /* >> [LIO-1690] */
     }
    // Task5758730-chengyanzhang@t2mobile.com-for add exercise alert message-end

    function _updateAlertBodyDisplay(panel) {
      var alertBody = panel.querySelector('#receive-alert-body');
      var request = navigator.mozSettings.createLock().get('cmas.settings.show');
      request.onsuccess = () => {
        var val = request.result['cmas.settings.show'];
        if (val === 'undefined') {
          val = true;
        }
        if (alertBody.hidden === val) {
          alertBody.hidden = !val;
          NavigationMap.refresh();
        }
      };
      request.onerror = () => {
        console.error('ERROR: Can not get the receive alert setting.');
      };
    }

    return SettingsPanel({
      onInit: function(panel) {
        elements = [
          document.getElementById('alert-inbox'),
          document.getElementById('ringtone-preview')
        ];
        _updateAlertBodyDisplay(panel);
      },

      onBeforeShow: function() {
        _updateSoftkey();
        _disableSomeMenu();// Task5758730-chengyanzhang@t2mobile.com-for add exercise alert message-add
        elements.forEach((ele) => {
          ele.addEventListener('keydown', _keyDownHandler);
        });
        ListFocusHelper.addEventListener(listElements, _updateSoftkey);
        _initAlertSettingListener();
      },

      onBeforeHide: function() {
        ListFocusHelper.removeEventListener(listElements, _updateSoftkey);
        _removeAlertSettingListener();
        elements.forEach((ele) => {
          ele.removeEventListener('keydown', _keyDownHandler);
        })
      }
    });
  };
});
