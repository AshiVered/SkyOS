/* -*- Mode: js; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

define(['require','modules/bluetooth/bluetooth_adapter_manager','modules/bluetooth/bluetooth_context'],function(require) {
  

  let AdapterManager = require('modules/bluetooth/bluetooth_adapter_manager');
  let BtContext = require('modules/bluetooth/bluetooth_context');

  let _debug = true;
  let debug = function() {};
  if (_debug) {
    debug = function pm_debug(msg) {
      console.log('--> [Bluetooth PairManager]: ' + msg);
    };
  }

  /*
   * PairManager is responsible for:
   *   1. Handling system message 'bluetooth-pairing-request' while there is an
   *      incoming/outgoing pairing request.
   *   2. Handling dom event from BluetoothPairingListener while there is an
   *      incoming/outgoing pairing request.
   *   3. Handling dom event 'ondeviceunpaired' while some remote devices
   *      request for canceling an overdue pairing request. The reason could be
   *      authentication fails, remote device down, and internal error happens.
   */
  let PairManager = {
    /**
     * Default adapter of Bluetooth.
     *
     * @access private
     * @memberOf PairManger
     * @type {Object} BluetoothAdapter
     */
    _defaultAdapter: null,

    /**
     * Device name for the pairing toast
     * @type {String}
     */
    _deviceName: null,

    _displayPasskeyHandle: null,
    _enterPincodeHandle: null,
    _pairingConfirmationHandle: null,
    _pairingConsentHandle: null,
    _abortPairingHandle: null,

    init: function() {
      this._defaultAdapter = AdapterManager.defaultAdapter;
      this._pairingConsentHandle = this._onPairingConsent.bind(this);
      this._enterPincodeHandle = this._onEnterPincode.bind(this);
      this._displayPasskeyHandle = this._onDisplayPasskey.bind(this);
      this._pairingConfirmationHandle = this._onPairingConfirmation.bind(this);
      this._abortPairingHandle = this._onPairingAborted.bind(this);
      // Watch pairing events.
      this._watchOndisplaypasskeyreq();
      this._watchOnenterpincodereq();
      this._watchOnpairingconfirmationreq();
      this._watchOnpairingconsentreq();
      this._watchOnpairingaborted();

      navigator.mozSetMessageHandler('bluetooth-pairing-request',
        this._onRequestPairingFromSystemMessage.bind(this));

      // Observe Bluetooth 'enabled' property from hardware side.
      // Then, close pairing dialog immediately.
      BtContext.observe('enabled', (enabled) => {
        if (!enabled) {
          this.onBluetoothDisabled();
        }
      });

      // Observe 'defaultAdapter' property for reaching default adapter.
      AdapterManager.observe('defaultAdapter',
        this._onDefaultAdapterChanged.bind(this));

    },


    /**
     * 'defaultAdapter' change event handler from adapter manager for
     * updating it immediately.
     *
     * @access private
     * @memberOf PairManager
     * @param {Object} BluetoothAdapter newAdapter
     */
    _onDefaultAdapterChanged: function(newAdapter) {
      // save default adapter
      let oldAdapter = this._defaultAdapter;
      this._defaultAdapter = newAdapter;

      if (oldAdapter) {
        this._unwatchOndisplaypasskeyreq(oldAdapter)
        this._unwatchOnenterpincodereq(oldAdapter);
        this._unwatchOnpairingconfirmationreq(oldAdapter);
        this._unwatchOnpairingconsentreq(oldAdapter);
        this._unwatchOnpairingaborted(oldAdapter);
        this._unwatchDefaultAdapterOndevicepaired(oldAdapter);
      }

      if (newAdapter) {
        this._watchOndisplaypasskeyreq();
        this._watchOnenterpincodereq();
        this._watchOnpairingconfirmationreq();
        this._watchOnpairingconsentreq();
        this._watchOnpairingaborted();
      }
    },

    /**
     * Watch 'ondisplaypasskeyreq' dom event for pairing.
     * A handler to trigger when a remote bluetooth device requests to display
     * passkey on the screen during pairing process.
     *
     * @access private
     * @memberOf PairManager
     */
    _watchOndisplaypasskeyreq: function() {
      if (!this._defaultAdapter || !this._defaultAdapter.pairingReqs) {
        debug('_watchOndisplaypasskeyreq() no adapter or pairingReqs');
        return;
      }

      this._defaultAdapter.pairingReqs.addEventListener('displaypasskeyreq',
        this._displayPasskeyHandle.bind(this));
    },

    _unwatchOndisplaypasskeyreq: function (adapter) {
      adapter.pairingReqs.removeEventListener('displaypasskeyreq',
        this._displayPasskeyHandle.bind(this));
    },

    _onDisplayPasskey: function (evt) {
      debug('_onDisplayPasskey()');
      this._handlePairingRequest({
        method: 'displaypasskey',
        evt: evt
      });
    },

    /**
     * Watch 'onenterpincodereq' dom event for pairing.
     * A handler to trigger when a remote bluetooth device requests user enter
     * PIN code during pairing process.
     *
     * @access private
     * @memberOf PairManager
     */
    _watchOnenterpincodereq: function() {
      if (!this._defaultAdapter || !this._defaultAdapter.pairingReqs) {
        debug('_watchOnenterpincodereq() no adapter or pairingReqs');
        return;
      }

      this._defaultAdapter.pairingReqs.addEventListener('enterpincodereq',
        this._enterPincodeHandle.bind(this));
    },

    _unwatchOnenterpincodereq: function (adapter) {
      adapter.pairingReqs.removeEventListener('enterpincodereq',
        this._enterPincodeHandle.bind(this));
    },

    _onEnterPincode: function (evt) {
      debug('_onEnterPincode()');
      this._handlePairingRequest({
        method: 'enterpincode',
        evt: evt
      });
    },

    /**
     * Watch 'onpairingconfirmationreq' dom event for pairing.
     * A handler to trigger when a remote bluetooth device requests user
     * confirm passkey during pairing process. Applications may prompt passkey
     * to user for confirmation, or confirm the passkey for user proactively.
     *
     * @access private
     * @memberOf PairManager
     */
    _watchOnpairingconfirmationreq: function() {
      if (!this._defaultAdapter || !this._defaultAdapter.pairingReqs) {
        debug('_watchOnpairingconfirmationreq() no adapter or pairingReqs');
        return;
      }

      this._defaultAdapter.pairingReqs.addEventListener(
        'pairingconfirmationreq', this._pairingConfirmationHandle.bind(this));
    },

    _unwatchOnpairingconfirmationreq: function (adapter) {
      adapter.pairingReqs.removeEventListener('pairingconfirmationreq',
        this._pairingConfirmationHandle.bind(this));
    },

    _onPairingConfirmation: function (evt) {
      debug('_onPairingConfirmation: evt = ' + JSON.stringify(evt));
      this._handlePairingRequest({
        method: 'confirmation',
        evt: evt
      });
    },

    /**
     * Watch 'onpairingconsentreq' dom event for pairing.
     * A handler to trigger when a remote bluetooth device requests user
     * confirm pairing during pairing process. Applications may prompt user
     * for confirmation or confirm for user proactively.
     *
     * @access private
     * @memberOf PairManager
     */
    _watchOnpairingconsentreq: function() {
      if (!this._defaultAdapter || !this._defaultAdapter.pairingReqs) {
        debug('_watchOnpairingconsentreq() no adapter or pairingReqs');
        return;
      }

      this._defaultAdapter.pairingReqs.addEventListener('pairingconsentreq',
        this._pairingConsentHandle.bind(this));

      this._defaultAdapter.pairingReqs.on
    },

    _unwatchOnpairingconsentreq: function (adapter) {
      adapter.pairingReqs.addEventListener('pairingconsentreq',
        this._pairingConsentHandle.bind(this));
    },

    _onPairingConsent: function (evt) {
      debug('_onPairingConsent: evt = ' + JSON.stringify(evt));
      this._handlePairingRequest({
        method: 'consent',
        evt: evt
      });
    },

    /**
     * Watch 'onpairingaborted' dom event for pairing aborted.
     * A handler to trigger when pairing fails due to one of
     * following conditions:
     * - authentication fails
     * - remote device down (bluetooth ACL becomes disconnected)
     * - internal error happens
     *
     * @access private
     * @memberOf PairManager
     */
    _watchOnpairingaborted: function() {
      if (!this._defaultAdapter) {
        return;
      }

      this._defaultAdapter.addEventListener('pairingaborted',
        this._abortPairingHandle.bind(this));
    },

    _unwatchOnpairingaborted: function (adapter) {
      adapter.removeEventListener('pairingaborted',
        this._abortPairingHandle.bind(this));
    },

    /**
     * A handler to handle 'onpairingaborted' event while it's coming.
     *
     * @access private
     * @memberOf PairManager
     */
    _onPairingAborted: function(evt) {
      debug('_onPairingAborted(): evt = ' + JSON.stringify(evt));
      // if the attention screen still open, close it
      if (this.childWindow) {
        this.childWindow.Pairview.closeInput();
        this.childWindow.close();
      }

      this.showToast('paired-failed',
        { 'deviceName': this._deviceName });

    },

    /**
     * Watch 'ondevicepaired' event from default adapter for updating paired
     * device immediately.
     *
     * Description of 'ondevicepaired' event:
     * A handler to trigger when a remote device gets paired with local
     * bluetooth adapter.
     *
     * @access private
     * @memberOf pairManager
     * @param {BluetoothAdapter} adapter
     */
    _watchDefaultAdapterOndevicepaired:
      function btc__watchDefaultAdapterOndevicepaired(adapter) {
        adapter.ondevicepaired =
          this._onAdapterDevicepaired.bind(this, adapter);
      },

    /**
     * Unwatch 'ondevicepaired' event from default adapter since adapter is
     * removed.
     *
     * @access private
     * @memberOf pairManager
     * @param {BluetoothAdapter} adapter
     */
    _unwatchDefaultAdapterOndevicepaired:
      function (adapter) {
        adapter.ondevicepaired = null;
      },


    /**
     * 'ondevicepaired' event handler from default adapter for updating paired
     * device in remote/paired devices list.
     *
     * @access private
     * @memberOf pairManager
     * @param {BluetoothAdapter} adapter
     * @param {event} evt
     */
    _onAdapterDevicepaired:
      function (adapter, evt) {
        debug('_onAdapterDevicepaired evt = ' + evt.device.name);
        // have to get device object in this event handler
        // Ex. evt.device --> device

        this.showToast('paired-with-device',
          { 'deviceName': this._deviceName });
      },

    /**
     * Receive the system message event for launch Bluetooth app here.
     *
     * @access private
     * @memberOf PairManager
     */
    _onRequestPairingFromSystemMessage: function() {
      debug('onRequestPairingFromSystemMessage():');
    },

      /**
     * It is used to handle each pairing request from different pairing methods.
     *
     * @memberOf PairManager
     * @access private
     * @param {Object} pairingInfo
     * @param {Object} pairingInfo.method - method of this pairing request
     * @param {Object} pairingInfo.evt - DOM evt of this pairing request
     */
    _handlePairingRequest: function(pairingInfo) {
      debug('_onRequestPairing():' +
            ' pairingInfo.method = ' + pairingInfo.method +
            ' pairingInfo.evt = ' + pairingInfo.evt);

      this.showPairview(pairingInfo);
    },

    showPairview: function(pairingInfo) {
      debug('showPairview()');
      let protocol = window.location.protocol;
      let host = window.location.host;
      let _ = navigator.mozL10n.get;

      this._deviceName = pairingInfo.evt.deviceName ?
        pairingInfo.evt.deviceName : _('unnamed-device') ;

      this.childWindow = window.open(protocol + '//' + host + '/onpair.html',
                  'pair_screen', 'attention');
      this.childWindow.onload = () => {
        this.childWindow.Pairview.init(pairingInfo.method, pairingInfo.evt);
      };
    },

    showToast: function (id, args) {
      let toast = {
        messageL10nId: id,
        messageL10nArgs: args,
        latency: 2000,
        useTransition: true
      };

      debug('show Toast ');
      Toaster.showToast(toast);
    },

    onBluetoothDisabled: function() {
      debug('onBluetoothDisabled():');

      // if the attention screen still open, close it
      if (this.childWindow) {
        this.childWindow.Pairview.closeInput();
        this.childWindow.close();
      }

      // Since Bluetooth is off, close itself.
      window.close();
    }
  };

  return PairManager;
});
