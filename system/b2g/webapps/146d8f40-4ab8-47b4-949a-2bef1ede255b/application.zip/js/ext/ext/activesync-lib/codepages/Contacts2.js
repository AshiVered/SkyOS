(function(e, t) {
    "object" == typeof exports ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : e.ASCPContacts2 = t();
})(this, function() {
    return {
        Tags: {
            CustomerId: 3077,
            GovernmentId: 3078,
            IMAddress: 3079,
            IMAddress2: 3080,
            IMAddress3: 3081,
            ManagerName: 3082,
            CompanyMainPhone: 3083,
            AccountName: 3084,
            NickName: 3085,
            MMS: 3086
        }
    };
});