define([ "require" ], function() {
    function e(e) {
        var n = this;
        return "function" == typeof e && (e = e.call(this)), new Promise(function(r, i) {
            function s(t) {
                var n;
                try {
                    n = e.next(t);
                } catch (r) {
                    return i(r);
                }
                u(n);
            }
            function a(t) {
                var n;
                try {
                    n = e.throw(t);
                } catch (r) {
                    return i(r);
                }
                u(n);
            }
            function u(e) {
                if (e.done) return r(e.value);
                var i = t.call(n, e.value);
                return i && o(i) ? i.then(s, a) : a(new TypeError('You may only yield a function, promise, generator, array, or object, but the following object was passed: "' + String(e.value) + '"'));
            }
            s();
        });
    }
    function t(t) {
        return t ? o(t) ? t : a(t) || s(t) ? e.call(this, t) : "function" == typeof t ? n.call(this, t) : Array.isArray(t) ? r.call(this, t) : u(t) ? i.call(this, t) : t : t;
    }
    function n(e) {
        var t = this;
        return new Promise(function(n, r) {
            e.call(t, function(e, t) {
                return e ? r(e) : (arguments.length > 2 && (t = c.call(arguments, 1)), n(t), void 0);
            });
        });
    }
    function r(e) {
        return Promise.all(e.map(t, this));
    }
    function i(e) {
        function n(e, t) {
            r[t] = void 0, s.push(e.then(function(e) {
                r[t] = e;
            }));
        }
        for (var r = new e.constructor(), i = Object.keys(e), s = [], a = 0; a < i.length; a++) {
            var u = i[a], c = t.call(this, e[u]);
            c && o(c) ? n(c, u) : r[u] = e[u];
        }
        return Promise.all(s).then(function() {
            return r;
        });
    }
    function o(e) {
        return "function" == typeof e.then;
    }
    function s(e) {
        return "function" == typeof e.next && "function" == typeof e.throw;
    }
    function a(e) {
        var t = e.constructor;
        return t ? "GeneratorFunction" === t.name || "GeneratorFunction" === t.displayName ? !0 : s(t.prototype) : !1;
    }
    function u(e) {
        return Object == e.constructor;
    }
    var c = Array.prototype.slice;
    return e["default"] = e.co = e, e.wrap = function(t) {
        function n() {
            return e.call(this, t.apply(this, arguments));
        }
        return n.__generatorFunction__ = t, n;
    }, e;
});