(function(e, t) {
    "object" == typeof exports ? module.exports = t(require("wbxml"), require("activesync/codepages")) : "function" == typeof define && define.amd ? define([ "wbxml", "activesync/codepages" ], t) : e.ActiveSyncProtocol = t(WBXML, ActiveSyncCodepages);
})(this, function(e, t) {
    function n() {}
    function r(e, t, n) {
        function r() {
            var e = this instanceof r ? this : Object.create(r.prototype), t = Error(), i = 1;
            if (e.stack = t.stack.substring(t.stack.indexOf("\n") + 1), e.message = arguments[0] || t.message, 
            n) {
                i += n.length;
                for (var o = 0; o < n.length; o++) e[n[o]] = arguments[o + 1];
            }
            var s = /@(.+):(.+)/.exec(e.stack);
            return e.fileName = arguments[i] || s && s[1] || "", e.lineNumber = arguments[i + 1] || s && s[2] || 0, 
            e;
        }
        return r.prototype = Object.create((t || Error).prototype), r.prototype.name = e, 
        r.prototype.constructor = r, r;
    }
    function i(e) {
        var t = "http://schemas.microsoft.com/exchange/autodiscover/", n = {
            rq: t + "mobilesync/requestschema/2006",
            ad: t + "responseschema/2006",
            ms: t + "mobilesync/responseschema/2006"
        };
        return n[e] || null;
    }
    function o(e) {
        var t = e.split(".").map(function(e) {
            return parseInt(e);
        });
        this.major = t[0], this.minor = t[1];
    }
    function s(e, t, n) {
        var r = "Basic " + btoa(t + ":" + n);
        e.setRequestHeader("Authorization", r);
    }
    function a(e, t, r, i, o) {
        i || (i = n);
        var s = e.substring(e.indexOf("@") + 1);
        u("autodiscover." + s, e, t, r, o, function(n, a) {
            n instanceof m || n instanceof p ? u(s, e, t, r, o, i) : i(n, a);
        });
    }
    function u(e, t, n, r, i, o) {
        var s = "https://" + e + "/autodiscover/autodiscover.xml";
        return c(s, t, n, r, i, o);
    }
    function c(e, t, n, r, o, u) {
        var c = new XMLHttpRequest({
            mozSystem: !0,
            mozAnon: !0
        });
        c.open("POST", e, !0), s(c, t, n), c.setRequestHeader("Content-Type", "text/xml"), 
        c.setRequestHeader("User-Agent", f), c.timeout = r, c.upload.onprogress = c.upload.onload = function() {
            c.timeout = 0;
        }, c.onload = function() {
            if (c.status < 200 || c.status >= 300) return u(new p(c.statusText, c.status));
            var e = Math.random();
            self.postMessage({
                uid: e,
                type: "configparser",
                cmd: "accountactivesync",
                args: [ c.responseText, o ]
            }), self.addEventListener("message", function t(i) {
                var o = i.data;
                if ("configparser" === o.type && "accountactivesync" === o.cmd && o.uid === e) {
                    self.removeEventListener(i.type, t);
                    var s = o.args, c = s[0], l = s[1], d = s[2];
                    l ? u(new m(l), c) : d ? a(d, n, r, u, !0) : u(null, c);
                }
            });
        }, c.ontimeout = c.onerror = function() {
            u(new p("Error getting Autodiscover URL", null));
        };
        var l = '<?xml version="1.0" encoding="utf-8"?>\n<Autodiscover xmlns="' + i("rq") + '">\n' + "  <Request>\n" + "    <EMailAddress>" + t + "</EMailAddress>\n" + "    <AcceptableResponseSchema>" + i("ms") + "</AcceptableResponseSchema>\n" + "  </Request>\n" + "</Autodiscover>";
        c.send(l);
    }
    function l(e, t, n) {
        this._deviceId = e || "v140Device", this._deviceType = n || "KaiOS", this.timeout = 0, 
        this._connected = !1, this._waitingForConnection = !1, this._connectionError = null, 
        this._connectionCallbacks = [], this.baseUrl = null, this._username = null, this._password = null, 
        this.versions = [], this.supportedCommands = [], this.currentVersion = null, this.policyKey = t || 0, 
        this.onmessage = null;
    }
    var d = {}, f = "KaiOS ActiveSync Client", h = r("ActiveSync.AutodiscoverError");
    d.AutodiscoverError = h;
    var m = r("ActiveSync.AutodiscoverDomainError", h);
    d.AutodiscoverDomainError = m;
    var p = r("ActiveSync.HttpError", null, [ "status" ]);
    return d.HttpError = p, d.Version = o, o.prototype = {
        eq: function(e) {
            return e instanceof o || (e = new o(e)), this.major === e.major && this.minor === e.minor;
        },
        ne: function(e) {
            return !this.eq(e);
        },
        gt: function(e) {
            return e instanceof o || (e = new o(e)), this.major > e.major || this.major === e.major && this.minor > e.minor;
        },
        gte: function(e) {
            return e instanceof o || (e = new o(e)), this.major >= e.major || this.major === e.major && this.minor >= e.minor;
        },
        lt: function(e) {
            return !this.gte(e);
        },
        lte: function(e) {
            return !this.gt(e);
        },
        toString: function() {
            return this.major + "." + this.minor;
        }
    }, d.autodiscover = a, d.raw_autodiscover = c, d.Connection = l, l.prototype = {
        _notifyConnected: function(e) {
            e && this.disconnect();
            for (var t in Iterator(this._connectionCallbacks)) {
                var n = t[1];
                n.apply(n, arguments);
            }
            this._connectionCallbacks = [];
        },
        get connected() {
            return this._connected;
        },
        open: function(e, t, n) {
            var r = "/Microsoft-Server-ActiveSync";
            this.baseUrl = e, this.baseUrl.endsWith(r) || (this.baseUrl += r), this._username = t, 
            this._password = n;
        },
        connect: function(n) {
            return this.connected ? (n && n(null), void 0) : (n && this._connectionCallbacks.push(n), 
            this._waitingForConnection || (this._waitingForConnection = !0, this._connectionError = null, 
            this.getOptions(function(n, r) {
                return this._waitingForConnection = !1, this._connectionError = n, n ? (console.error("Error connecting to ActiveSync:", n), 
                this._notifyConnected(n, r)) : (this._connected = !0, this.versions = r.versions, 
                this.supportedCommands = r.commands, this.currentVersion = new o(r.versions.slice(-1)[0]), 
                this.enforcement(function(n, i) {
                    var o = "Error get Security Policy for ActiveSync: ", s = !1;
                    if (n) {
                        if (console.error(o, n), 449 !== n.status) return this._notifyConnected(n, r);
                        s = !0;
                    }
                    var a = new e.EventParser(), u = t.FolderHierarchy.Tags, c = t.Common.Enums, l = t.FolderHierarchy.Enums;
                    a.addEventListener([ u.FolderSync, u.Status ], function(e) {
                        var t = e.children[0].textContent;
                        if (t === l.Status.Success) return this._notifyConnected(null, r);
                        if (t === c.Status.DeviceNotProvisioned || t === c.Status.PolicyRefresh || t === c.Status.InvalidPolicyKey || s) this.getPolicyKey(!1, function(e) {
                            return e ? (console.error(o, e), this._notifyConnected(e, r)) : (this.getPolicyKey(!0, function(e) {
                                return e ? (console.error(o, e), this._notifyConnected(e, r)) : this._notifyConnected(null, r);
                            }.bind(this)), void 0);
                        }.bind(this)); else {
                            if (t !== c.Status.RemoteWipeRequested) return n = "enforcement error, status: " + t, 
                            console.error(o, n), this._notifyConnected(n, r);
                            this.deviceWipe(function(e) {
                                return e ? (console.error(o, e), this._notifyConnected(e, r)) : this._notifyConnected(null, r);
                            }.bind(this));
                        }
                    }.bind(this));
                    try {
                        a.run(i);
                    } catch (d) {
                        console.error(o, d);
                    }
                }.bind(this)), void 0);
            }.bind(this))), void 0);
        },
        disconnect: function() {
            if (this._waitingForConnection) throw new Error("Can't disconnect while waiting for server response");
            this._connected = !1, this.versions = [], this.supportedCommands = [], this.currentVersion = null;
        },
        getDeviceInfo: function(e) {
            var t = Math.random();
            self.postMessage({
                uid: t,
                type: "deviceInfo",
                cmd: "get"
            }), self.addEventListener("message", function n(r) {
                var i = r.data;
                if ("deviceInfo" == i.type && "get" == i.cmd && i.uid == t) {
                    self.removeEventListener(r.type, n);
                    var o = i.args, i = o[0], s = o[1];
                    s ? e(null, s) : e(i);
                }
            });
        },
        provision: function(n, r) {
            var i = t.Provision.Tags, o = t.Settings.Tags, s = new e.Writer("1.3", 1, "UTF-8");
            s.stag(i.Provision);
            var a = !n && this.currentVersion.gte("12.0");
            a ? this.getDeviceInfo(function(e, t) {
                t && r(t), s.stag(o.DeviceInformation).stag(o.Set).tag(o.FriendlyName, e.deviceName).tag(o.Model, e.modelName).tag(o.IMEI, e.imei).tag(o.OS, e.OSName).tag(o.OSLanguage, e.OSLanguage), 
                e.phoneNumber.length > 0 && s.tag(o.PhoneNumber, e.phoneNumber), this.currentVersion.gte("14.0") && s.tag(o.MobileOperator, e.operatorName), 
                s.etag().etag(), s.stag(i.Policies).stag(i.Policy).tag(i.PolicyType, "MS-EAS-Provisioning-WBXML"), 
                s.etag().etag().etag(), this.postCommand(s, r);
            }.bind(this)) : (s.stag(i.Policies).stag(i.Policy).tag(i.PolicyType, "MS-EAS-Provisioning-WBXML"), 
            n && s.tag(i.PolicyKey, this.policyKey).tag(i.Status, 1), s.etag().etag().etag(), 
            this.postCommand(s, r));
        },
        enforcement: function(n) {
            var r = t.FolderHierarchy.Tags, i = new e.Writer("1.3", 1, "UTF-8");
            i.stag(r.FolderSync).tag(r.SyncKey, "0").etag(), this.postCommand(i, n);
        },
        getPolicyKey: function(n, r) {
            this.provision(n, function(i, o) {
                i && r(i);
                var s = new e.EventParser(), a = t.Provision.Tags, u = [ a.Provision, a.Policies, a.Policy ];
                s.addEventListener(u.concat(a.PolicyKey), function(e) {
                    this.policyKey = e.children[0].textContent, r(null);
                }.bind(this)), n || s.addEventListener(u.concat([ a.Data, a.EASProvisionDoc ]), function(e) {
                    this.securitySettings(a, e);
                }.bind(this));
                try {
                    s.run(o);
                } catch (c) {
                    r(c);
                }
            }.bind(this));
        },
        securitySettings: function(e, t) {
            for (var n in Iterator(t.children)) {
                var r = n[1];
                switch (r.children.length ? r.children[0].textContent : null, r.tag) {
                  case e.DevicePasswordEnabled:
                    break;

                  case e.AlphanumericDevicePasswordRequired:
                    break;

                  case e.PasswordRecoveryEnabled:
                    break;

                  case e.RequireStorageCardEncryption:
                    break;

                  case e.AttachmentsEnabled:
                    break;

                  case e.MinDevicePasswordLength:
                    break;

                  case e.MaxInactivityTimeDeviceLock:
                    break;

                  case e.MaxAttachmentSize:
                    break;

                  case e.MaxDevicePasswordFailedAttempts:
                    break;

                  case e.AllowSimpleDevicePassword:
                    break;

                  case e.DevicePasswordExpiration:
                    break;

                  case e.DevicePasswordHistory:                }
            }
        },
        wipeCommand: function(t, n, r) {
            var i = new e.Writer("1.3", 1, "UTF-8");
            i.stag(t.Provision), n && i.stag(t.RemoteWipe).tag(t.Status, 1).etag(), i.etag(), 
            this.postCommand(i, function(n, i) {
                var o = new e.EventParser();
                n && r(n), o.addEventListener([ t.Provision, t.Status ], function(e) {
                    var t = e.children[0].textContent;
                    if ("1" === t) r(null); else {
                        var n = "Remote wipe error, error status: " + t;
                        console.error(n), r(n);
                    }
                });
                try {
                    o.run(i);
                } catch (s) {
                    r(s);
                }
            });
        },
        deviceWipe: function(e) {
            var n = t.Provision.Tags;
            this.wipeCommand(n, !1, function(t) {
                return t ? (e(t), void 0) : (this.wipeCommand(n, !0, function(t) {
                    if (t) return e(t), void 0;
                    e(null);
                    var n = Math.random();
                    self.postMessage({
                        uid: n,
                        type: "deviceInfo",
                        cmd: "reset"
                    });
                }), void 0);
            }.bind(this));
        },
        getOptions: function(e) {
            e || (e = n);
            var t = this, r = new XMLHttpRequest({
                mozSystem: !0,
                mozAnon: !0
            });
            r.open("OPTIONS", this.baseUrl, !0), s(r, this._username, this._password), r.setRequestHeader("User-Agent", f), 
            r.timeout = this.timeout, r.upload.onprogress = r.upload.onload = function() {
                r.timeout = 0;
            }, r.onload = function() {
                if (r.status < 200 || r.status >= 300) return console.error("ActiveSync options request failed with response " + r.status), 
                t.onmessage && t.onmessage("options", "error", r, null, null, null, null), e(new p(r.statusText, r.status)), 
                void 0;
                var n = {
                    versions: r.getResponseHeader("MS-ASProtocolVersions").split(/\s*,\s*/),
                    commands: r.getResponseHeader("MS-ASProtocolCommands").split(/\s*,\s*/)
                };
                t.onmessage && t.onmessage("options", "ok", r, null, null, null, n), e(null, n);
            }, r.ontimeout = r.onerror = function() {
                var n = new Error("Error getting OPTIONS URL");
                console.error(n), t.onmessage && t.onmessage("options", "timeout", r, null, null, null, null), 
                e(n);
            }, r.responseType = "text", r.send();
        },
        supportsCommand: function(e) {
            if (!this.connected) throw new Error("Connection required to get command");
            return "number" == typeof e && (e = t.__tagnames__[e]), -1 !== this.supportedCommands.indexOf(e);
        },
        doCommand: function() {
            console.warn("doCommand is deprecated. Use postCommand instead."), this.postCommand.apply(this, arguments);
        },
        postCommand: function(e, n, r, i, o) {
            var s = "application/vnd.ms-sync.wbxml";
            if ("string" == typeof e || "number" == typeof e) this.postData(e, s, null, n, r, i); else {
                var a = t.__tagnames__[e.rootTag];
                this.postData(a, s, "blob" === e.dataType ? e.blob : e.buffer, n, r, i, o);
            }
        },
        postData: function(n, r, i, o, a, u, c) {
            if ("number" == typeof n && (n = t.__tagnames__[n]), !this.supportsCommand(n)) {
                var l = new Error("This server doesn't support the command " + n);
                return console.error(l), o(l), void 0;
            }
            var d = [ [ "Cmd", n ], [ "User", this._username ], [ "DeviceId", this._deviceId ], [ "DeviceType", this._deviceType ] ];
            if (a) {
                for (var h in Iterator(d)) {
                    var m = h[1];
                    if (m[0] in a) throw new TypeError("reserved URL parameter found");
                }
                for (var g in Iterator(a)) d.push(g);
            }
            var v = d.map(function(e) {
                return encodeURIComponent(e[0]) + "=" + encodeURIComponent(e[1]);
            }).join("&"), y = new XMLHttpRequest({
                mozSystem: !0,
                mozAnon: !0
            });
            if (y.open("POST", this.baseUrl + "?" + v, !0), s(y, this._username, this._password), 
            y.setRequestHeader("MS-ASProtocolVersion", this.currentVersion), y.setRequestHeader("Content-Type", r), 
            y.setRequestHeader("User-Agent", f), y.setRequestHeader("X-MS-PolicyKey", this.policyKey), 
            u) for (var h in Iterator(u)) {
                var _ = h[0], w = h[1];
                y.setRequestHeader(_, w);
            }
            y.timeout = this.timeout, y.upload.onprogress = y.upload.onload = function() {
                y.timeout = 0;
            }, y.onprogress = function(e) {
                c && c(e.loaded, e.total);
            };
            var b = this, S = arguments;
            y.onload = function() {
                if (451 === y.status) return b.baseUrl = y.getResponseHeader("X-MS-Location"), b.onmessage && b.onmessage(n, "redirect", y, d, u, i, null), 
                b.postData.apply(b, S), void 0;
                if (y.status < 200 || y.status >= 300) return console.error("ActiveSync command " + n + " failed with " + "response " + y.status), 
                b.onmessage && b.onmessage(n, "error", y, d, u, i, null), o(new p(y.statusText, y.status)), 
                void 0;
                var r = null;
                y.response.byteLength > 0 && (r = new e.Reader(new Uint8Array(y.response), t)), 
                b.onmessage && b.onmessage(n, "ok", y, d, u, i, r), o(null, r);
            }, y.ontimeout = y.onerror = function(e) {
                var t = new Error("Command URL " + e.type + " for command " + n + " at baseUrl " + this.baseUrl);
                console.error(t), b.onmessage && b.onmessage(n, e.type, y, d, u, i, null), o(t);
            }.bind(this), y.responseType = "arraybuffer", y.send(i);
        }
    }, d;
});