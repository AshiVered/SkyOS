/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [native_manager.js] = ' + s + '\n');
    }
  }

  function NativeManager(deviceType) {
    this.type = deviceType;

    let filePath = 'js/native/native_interface_' + this.type + '.js';
    LazyLoader.load(filePath, () => {
      this.interface = new NI();
      this.interface.init();
    });
  }

  NativeManager.prototype = {
    init: function() {
      window.addEventListener('nativeRequest', this.handleNativeRequest.bind(this));
    },

    handleNativeRequest: function(event) {
      debug('Receive native request: ' + event.type);
      if (event.type === 'nativeRequest') {
        let message = event.detail.message;
        switch (message) {
          case 'startGps':
            this.interface.startGps();
            break;
          case 'stopGps':
            this.interface.stopGps();
            break;
          case 'setPhaseCheck':
            if (this.type === 'sprd') {
              this.interface.setPhaseCheck(event.detail.attachment);
            }
            break;
          case 'initPhasecheckLockInfo':
            if (this.type === 'sprd') {
              this.interface.initPhasecheckLockInfo();
            }
            break;
          case 'micLoop':
            this.interface.micLoop();
            break;
          case 'resetMicLoop':
            this.interface.resetMicLoop();
            break;
          case 'headsetMicLoop':
            this.interface.headsetMicLoop();
            break;
          case 'resetHeadsetMicLoop':
            this.interface.resetHeadsetMicLoop();
            break;
          case 'getBatteryInfo':
            this.interface.getBatteryInfo();
            break;
          default:
            break;
        }
      }
    }
  };

  exports.NativeManager = NativeManager;
}(window));
