/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
/* global TestItem */
'use strict';

(function(exports) {
  var LcdTest = new TestItem(render);

  LcdTest.timeoutCallback = function() {
    this.passButton.disabled = '';
    this.failButton.disabled = '';
    this.passButton.style.visibility = 'visible';
    this.failButton.style.visibility = 'visible';
  };

  LcdTest.showStep = function() {
    for (let i = 0, len = this.stepEls.length; i < len; i ++) {
      if (parseInt(this.stepEls[i].dataset.value) === this.step) {
        this.stepEls[i].classList.remove('hidden');
      } else {
        this.stepEls[i].classList.add('hidden');
      }
    }

    this.step++;

    if (this.step < 6) {
      this._stepTimer = window.setTimeout(() => {
        this.showStep();
      }, LCD_EVERY_STEP_DURING_TIME);
    }
  };

  LcdTest.onInit = function() {
    this.step = 1;
    this.stepEls = this.container.querySelectorAll('.step');

    this.passButton.style.visibility = 'hidden';
    this.failButton.style.visibility = 'hidden';
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';
    this.showStep();

    this._timer = window.setTimeout(this.timeoutCallback.bind(this), 500);
  };

  LcdTest.onDeinit = function() {
    clearTimeout(this._timer);
    clearTimeout(this._stepTimer);
  };

  function render() {
    return `
        <div data-value="1" class="step hidden" style="width:100%; height:100%; background-color:#ffffff"></div>
        <div data-value="2" class="step hidden" style="width:100%; height:100%; background-color:#000000"></div>
        <div data-value="3" class="step hidden" style="width:100%; height:100%;">
          <div style="width:100%; height:6%; background-color:#000000"></div>
          <div style="width:100%; height:6%; background-color:#101010"></div>
          <div style="width:100%; height:6%; background-color:#202020"></div>
          <div style="width:100%; height:6%; background-color:#303030"></div>
          <div style="width:100%; height:6%; background-color:#404040"></div>
          <div style="width:100%; height:6%; background-color:#505050"></div>
          <div style="width:100%; height:6%; background-color:#606060"></div>
          <div style="width:100%; height:6%; background-color:#707070"></div>
          <div style="width:100%; height:6%; background-color:#808080"></div>
          <div style="width:100%; height:6%; background-color:#909090"></div>
          <div style="width:100%; height:6%; background-color:#a0a0a0"></div>
          <div style="width:100%; height:6%; background-color:#b0b0b0"></div>
          <div style="width:100%; height:6%; background-color:#c0c0c0"></div>
          <div style="width:100%; height:6%; background-color:#d0d0d0"></div>
          <div style="width:100%; height:6%; background-color:#e0e0e0"></div>
          <div style="width:100%; height:10%; background-color:#f0f0f0"></div></div>
        <div data-value="4" class="step hidden" style="width:100%; height:100%;background-color:#707070"></div> 
        <div data-value="5" class="step hidden" style="width:100%; height:100%;">
          <div id="red" style="width:100%; height:33%; background-color:#ff0000;"></div>
          <div id="green" style="width:100%; height:33%; background-color:#00ff00;"></div>
          <div id="blue" style="width:100%; height:34%; background-color:#0000ff;"></div></div>`;
  }

  exports.Test = LcdTest;
}(window));
