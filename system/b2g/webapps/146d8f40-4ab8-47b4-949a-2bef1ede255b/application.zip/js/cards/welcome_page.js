/**
 * welcome page
 */

define(['require','exports','module','cards','html_cache','./base','template!./welcome_page.html'],function(require, exports, module) {

let cards = require('cards'),
    htmlCache = require('html_cache');

return [
  require('./base')(require('template!./welcome_page.html')),
  {
    createdCallback: function() {
      window.softkeyHTML = null;
      htmlCache.cloneAndSave(module.id, this);
    },

    onCardVisible: function() {
      let menuOptions = [{
        name: 'Next',
        l10nId: 'next',
        priority: 3,
        method: () => {
          this.onNext();
        }
      }];

      NavigationMap.setSoftKeyBar(menuOptions);

      let cardsNode = document.getElementsByTagName('cards-welcome-page')[0];
      cardsNode.setAttribute('role', 'heading');
      cardsNode.setAttribute('aria-labelledby', 'welcome-header');
      this.msgNode.focus();
    },

    onNext: function() {
      cards.pushCard('setup_account_info', 'animate');
    },

    die: function() {
    }
  }
];
});
