(function(e) {
    function t(e) {
        throw RangeError(R[e]);
    }
    function n(e, t) {
        for (var n = e.length; n--; ) e[n] = t(e[n]);
        return e;
    }
    function r(e, t) {
        return n(e.split(x), t).join(".");
    }
    function i(e) {
        for (var t, n, r = [], i = 0, o = e.length; o > i; ) t = e.charCodeAt(i++), t >= 55296 && 56319 >= t && o > i ? (n = e.charCodeAt(i++), 
        56320 == (64512 & n) ? r.push(((1023 & t) << 10) + (1023 & n) + 65536) : (r.push(t), 
        i--)) : r.push(t);
        return r;
    }
    function o(e) {
        return n(e, function(e) {
            var t = "";
            return e > 65535 && (e -= 65536, t += k(55296 | 1023 & e >>> 10), e = 56320 | 1023 & e), 
            t += k(e);
        }).join("");
    }
    function s(e) {
        return 10 > e - 48 ? e - 22 : 26 > e - 65 ? e - 65 : 26 > e - 97 ? e - 97 : _;
    }
    function a(e, t) {
        return e + 22 + 75 * (26 > e) - ((0 != t) << 5);
    }
    function u(e, t, n) {
        var r = 0;
        for (e = n ? P(e / A) : e >> 1, e += P(e / t); e > D * w >> 1; r += _) e = P(e / D);
        return P(r + (D + 1) * e / (e + S));
    }
    function c(e) {
        var n, r, i, a, c, l, d, f, h, p, m = [], g = e.length, y = 0, S = T, A = C;
        for (r = e.lastIndexOf(E), 0 > r && (r = 0), i = 0; r > i; ++i) e.charCodeAt(i) >= 128 && t("not-basic"), 
        m.push(e.charCodeAt(i));
        for (a = r > 0 ? r + 1 : 0; g > a; ) {
            for (c = y, l = 1, d = _; a >= g && t("invalid-input"), f = s(e.charCodeAt(a++)), 
            (f >= _ || f > P((v - y) / l)) && t("overflow"), y += f * l, h = A >= d ? b : d >= A + w ? w : d - A, 
            !(h > f); d += _) p = _ - h, l > P(v / p) && t("overflow"), l *= p;
            n = m.length + 1, A = u(y - c, n, 0 == c), P(y / n) > v - S && t("overflow"), S += P(y / n), 
            y %= n, m.splice(y++, 0, S);
        }
        return o(m);
    }
    function l(e) {
        var n, r, o, s, c, l, d, f, h, p, m, g, y, S, A, I = [];
        for (e = i(e), g = e.length, n = T, r = 0, c = C, l = 0; g > l; ++l) m = e[l], 128 > m && I.push(k(m));
        for (o = s = I.length, s && I.push(E); g > o; ) {
            for (d = v, l = 0; g > l; ++l) m = e[l], m >= n && d > m && (d = m);
            for (y = o + 1, d - n > P((v - r) / y) && t("overflow"), r += (d - n) * y, n = d, 
            l = 0; g > l; ++l) if (m = e[l], n > m && ++r > v && t("overflow"), m == n) {
                for (f = r, h = _; p = c >= h ? b : h >= c + w ? w : h - c, !(p > f); h += _) A = f - p, 
                S = _ - p, I.push(k(a(p + A % S, 0))), f = P(A / S);
                I.push(k(a(f, 0))), c = u(r, y, o == s), r = 0, ++o;
            }
            ++r, ++n;
        }
        return I.join("");
    }
    function d(e) {
        return r(e, function(e) {
            return I.test(e) ? c(e.slice(4).toLowerCase()) : e;
        });
    }
    function f(e) {
        return r(e, function(e) {
            return M.test(e) ? "xn--" + l(e) : e;
        });
    }
    var h = "object" == typeof exports && exports, p = "object" == typeof module && module && module.exports == h && module, m = "object" == typeof global && global;
    (m.global === m || m.window === m) && (e = m);
    var g, y, v = 2147483647, _ = 36, b = 1, w = 26, S = 38, A = 700, C = 72, T = 128, E = "-", I = /^xn--/, M = /[^ -~]/, x = /\x2E|\u3002|\uFF0E|\uFF61/g, R = {
        overflow: "Overflow: input needs wider integers to process",
        "not-basic": "Illegal input >= 0x80 (not a basic code point)",
        "invalid-input": "Invalid input"
    }, D = _ - b, P = Math.floor, k = String.fromCharCode;
    if (g = {
        version: "1.2.4",
        ucs2: {
            decode: i,
            encode: o
        },
        decode: c,
        encode: l,
        toASCII: f,
        toUnicode: d
    }, "function" == typeof define && "object" == typeof define.amd && define.amd) define("punycode", [], function() {
        return g;
    }); else if (h && !h.nodeType) if (p) p.exports = g; else for (y in g) g.hasOwnProperty(y) && (h[y] = g[y]); else e.punycode = g;
})(this);