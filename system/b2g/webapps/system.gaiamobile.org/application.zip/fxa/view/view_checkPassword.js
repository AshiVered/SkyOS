'use strict';

var View = {
  length: 1,
  start: FxaModuleStates.CHECK_PASSWORD
};
