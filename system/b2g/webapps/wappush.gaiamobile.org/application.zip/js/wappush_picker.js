
(function(exports){'use strict';let Picker=function(){this.inProgress=false;};Picker.prototype.defaultError=function(event){console.warn('occur error: '+event.target.error.message+'\n');};Picker.prototype.click=function(dataset){if(!dataset.action||this.inProgress){return;}
this.inProgress=true;let type=dataset.action.replace('-link','');this[type](dataset[type],this.reset,this.reset);};Picker.prototype.reset=function(){this.inProgress=false;};Picker.prototype.url=function(url,onsuccess,onerror){if(window.MozActivity){let activity=new MozActivity({name:'view',data:{type:'url',url:url}});if(typeof onsuccess==='function'){activity.onsuccess=onsuccess;}
if(typeof onerror!=='function'){onerror=this.defaultError;}
activity.onerror=onerror;}};exports.Picker=new Picker();}(window));