/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [native_interface_sprd.js] = ' + s + '\n');
    }
  }

  let geolocation = navigator.geolocation;
  let geolocationSettingEnabled;
  navigator.mozSettings.createLock().get('geolocation.enabled').then((result) => {
    geolocationSettingEnabled = result['geolocation.enabled'];
  });

  function enableGeolocationSatellite(enable) {
    var satelliteEnabled = enable.toString();
    navigator.engmodeExtension.setPropertyLE("mmitestgps.satellite.enabled", satelliteEnabled);
  }

  function NIS() {
    debug('new sprd interface');
  }

  NIS.prototype = {
    startGps: function _startGps() {
      enableGeolocationSatellite(true);
      navigator.mozSettings.createLock().get('geolocation.enabled').then((result) => {
        var options = {
          enableHighAccuracy: true,
          timeout: 3600000,
          maximumAge: 0
        };
        this.geolocationEnabled = result['geolocation.enabled'];
        if (!this.geolocationEnabled) {
          this.enableGeolocation(true).then(() => {
            this.geolocationEnabled = true;
            if (geolocation){
              geolocation.getCurrentPosition(() => {}, error, options);
            }
          });
          return;
        }
        if (geolocation){
          geolocation.getCurrentPosition(() => {
            debug('Search satellite success !');
          }, () => {
            debug('Search satellite failed !');
          }, options);
        }
      });
    },

    stopGps: function _stopGps() {
      if (geolocationSettingEnabled === false) {
        navigator.mozSettings.createLock().set({'geolocation.enabled' : false});
      } else {
        navigator.mozSettings.createLock().set({'geolocation.enabled' : true});
      }
      enableGeolocationSatellite(false);
    },

    enableGeolocation: function(enable) {
      return new Promise(function(resolve) {
        var req = navigator.mozSettings.createLock().set({'geolocation.enabled': enable});
        req.onsuccess = function() {
          resolve();
        };
      }.bind(this));
    },

    micLoop: function() {
      RemoteHelper.sendATCommand(AUDIO_MIC_AT_CMD);
    },

    resetMicLoop: function() {
      RemoteHelper.sendATCommand(AUDIO_RESET_AT_CMD);
    },

    // Accessories API
    headsetMicLoop: function() {
      RemoteHelper.sendATCommand(HEADSET_MIC_CMD);
    },

    resetHeadsetMicLoop: function() {
      RemoteHelper.sendATCommand(HEADSET_RESET_CMD);
    },

    getBatteryInfo: function() {
      let info = {};
      info.temp = this._getTempInfo();
      info.content = this._getContentInfo();
      info.voltage = this._getVoltageInfo();
      info.present = this._getPresentInfo();

      EventSender.emit('nativeResponse', {message: 'getBatteryInfo', response: info});
    },

    _getTempInfo: function() {
      RemoteHelper.readFile('/sys/class/power_supply/battery/temp', (response) => {
        return (parseInt(response) / 10);
      });
    },

    _getContentInfo: function() {
      RemoteHelper.readFile('/sys/class/power_supply/battery/capacity', (response) => {
        return parseInt(response);
      });
    },

    _getVoltageInfo: function() {
      RemoteHelper.readFile('/sys/class/power_supply/battery/voltage_now', (response) => {
        return (parseInt(response) / 1000000).toFixed(2);
      });
    },

    _getPresentInfo: function() {
      RemoteHelper.readFile('/sys/class/power_supply/battery/present', (response) => {
        return parseInt(response);
      });
    },
  };
  exports.NI = NIS;
}(window));