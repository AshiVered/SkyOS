/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';
/**
 * Description: Define special values which ODM can customize.
 * Naming Rule: {{test item}}_{{function description}}_{{sub description}}
 */


/***********************
 *      Vibrate        *
 ***********************/

/**
 *Vibrate example: VIBRATE_DURATION  VIBRATE_REST  VIBRATE_TIMES
 *
 *                        1500             0              0           always vibrate unless pass/fail pressed
 *                        1500           1000             5           total vibrate 5 times every 2500ms, each duration
 *                                                                    1500ms.
 * /

/**
 * Vibrate duration time
 * value type: number(ms)
 * note: Once vibrate duration time.
 */
const VIBRATE_DURATION = 1500;

/**
 * Vibrate rest time
 * value type: number(ms)
 * note: Time between two vibrate operate, mean rest.
 */
const VIBRATE_REST = 0;

/**
 * Vibrate times
 * value type: 1 <= number
 * note: Total times vibrate;
 *       Only when we want vibrate always unless user press pass/fail, it can be 0.
 */
const VIBRATE_TIMES = 0;


/***********************
 *      LCD            *
 ***********************/

/**
 * LCD every test step during time
 * value type: number(ms)
 */
const LCD_EVERY_STEP_DURING_TIME = 2000;

/***********************
 *      TRACE          *
 ***********************/

/* SPRD Special */
const TRACE_BT_MAC_ADDRESS = '/data/misc/bluedroid/btmac.txt';
const TRACE_WIFI_MAC_ADDRESS = '/data/misc/wifi/wifimac.txt';
const TRACE_CALIBRATE_INFO_GSMCMD = 'AT+SGMR=0,0,3,0';
const TRACE_CALIBRATE_INFO_LTECMD = 'AT+SGMR=0,0,3,3';


/***********************
 *      AUDIO          *
 ***********************/
const AUDIO_MIC_AT_CMD = 'AT+SPVLOOP=1,1,8,2,3,0';
const AUDIO_RESET_AT_CMD = 'AT+SPVLOOP=0,1,8,2,3,0';

/***********************
 *      ACCESSORIES    *
 ***********************/
const HEADSET_MIC_CMD = 'AT+SPVLOOP=1,2,8,2,3,0';
const HEADSET_RESET_CMD = 'AT+SPVLOOP=0,2,8,2,3,0';
