/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [auto_view.js] = ' + s + '\n');
    }
  }

  var AutoView = {
    hash: '#auto-view',

    testList: [],
    index: 0,
    // state: start, next, end.
    state: 'start',

    init: function(config) {
      this.view = document.getElementById('auto-view');
      this.startButton = this.view.querySelector('#autoStartButton');
      this.backButton = this.view.querySelector('#autoEndButton');
      this.retestButton = this.view.querySelector('#retestButton');
      this.centerText = this.view.querySelector('.centertext');
      this.autoContainer = this.view.querySelector('#auto-container');

      this.autoContainer.addEventListener('keydown', this.handleKeydown.bind(this));
      window.addEventListener('panelready', (e) => {
        if (e.detail.current === '#auto-view') {
          this.update();
        }
      });

      this.loadConfig(config);
    },

    loadConfig: function ut_loadConfig(obj) {
      this.config = obj[DEVICETYPE];

      this.testList = [];
      let testItems = this.config.testItems;
      for (let i = 0, len = testItems.length; i < len; i++) {
        if ('true' === testItems[i].autoTest[0].testFlag) {
          this.testList.push(testItems[i].htmlName);
        }
      }
    },

    update: function() {
      this.updateButtons();
      this.autoContainer.focus();
    },

    updateButtons: function() {
      this.startButton.classList.add('hidden');
      this.backButton.classList.add('hidden');
      this.retestButton.classList.add('hidden');

      switch (this.state) {
        case 'start':
          this.startButton.textContent = 'Start';
          this.backButton.textContent = 'Back';
          this.onStart();

          this.startButton.classList.remove('hidden');
          this.backButton.classList.remove('hidden');
          break;
        case 'next':
          this.startButton.textContent = 'Next';
          this.backButton.textContent = 'Back';
          this.retestButton.textContent = 'Retest';
          this.onFailed();

          this.startButton.classList.remove('hidden');
          this.backButton.classList.remove('hidden');
          this.retestButton.classList.remove('hidden');
          break;
        case 'end':
          this.startButton.textContent = 'Restart';
          this.backButton.textContent = 'End';
          this.onEnd();

          this.startButton.classList.remove('hidden');
          this.backButton.classList.remove('hidden');
          break;

        default:
          break;
      }
    },

    start: function() {
      if (this.index >= this.testList.length) {
        this.state = 'end';
        this.updateButtons();
        return;
      }

      let name = this.testList[this.index];
      EventSender.emit('openTest', {
        testName: name,
        testMode: 'auto'
      });
    },

    next: function() {
      this.index += 1;
      if (this.index < this.testList.length) {
        this.start();
      } else {
        this.state = 'end';
        viewManager.currentPanel = '#auto-view';
      }
    },

    restart: function() {
      this.index = 0;
      this.start();
    },

    end: function() {
      viewManager.currentPanel = '#main-view';
    },

    onStart: function() {
      this.centerText.innerHTML = 'KaiOS auto test tool';
    },

    onFailed: function () {
      this.centerText.innerHTML =
        this.getItemName(this.testList[this.index]) +
            ' test failed <br> Press Next or Retest';
    },

    onEnd: function() {
      this.centerText.innerHTML =
        'Auto test end <br> Press Restart or Back to home';
    },

    // according to file name, get the item name.
    getItemName: function AutoTest_getItemName(fileName) {
      let itemInfo = fileName;
      let items = this.config.testItems;

      for (let i = 0, len = items.length; i < len; i++) {
        if (items[i].htmlName === fileName) {
          itemInfo = items[i].itemInfo;
          return itemInfo;
        }
      }

      return itemInfo;
    },

    handleKeydown: function AutoTest_handleKeydown(evt){
      debug('handle keydown in auto view' + evt.key);
      evt.preventDefault();
      switch(evt.key){
        case 'SoftRight':
          this.end();
          break;
        case 'SoftLeft':
          if (this.state === 'end') {
            this.restart();
            return;
          }
          if (this.state === 'next') {
            this.index += 1;
          }
          this.start();
          break;
        case 'ArrowUp':
          this.start();
          break;
        case 'ArrowDown':
          break;

        default:
          break;
      }
    }
  };

  exports.AutoView = AutoView;
}(window));
