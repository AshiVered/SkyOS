/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [traceability.js] = ' + s + '\n');
    }
  }

  function $(id) {
    return document.getElementById(id);
  }

  var TraceTest = new TestItem(render);

  TraceTest.onInit = function() {
    if (!window.remoteHelper) {
      $('content').innerHTML = 'Device not support';
      return;
    }

    this.getIMEIs();
    this.getBtWifiAddress();
    this.getPhaseCheckInfo();
    this.getCalibrateInfo();
  };

  TraceTest.getCalibrateInfo = function() {
    RemoteHelper.sendATCommand(TRACE_CALIBRATE_INFO_GSMCMD, (info) => {
      $('trace-rf-gsm').innerHTML = '<br/>' + '======== RF GSM ========' + '<br/>' +
        this.formatInfo(info);
    });

    RemoteHelper.sendATCommand(TRACE_CALIBRATE_INFO_LTECMD, (info) => {
      $('trace-rf-lte').innerHTML = '======== RF LTE ========' + '<br/>' +
        this.formatInfo(info);
    });
  };

  TraceTest.getPhaseCheckInfo = function() {
    RemoteHelper.showbinfile((info) => {
      $('trace-data').innerHTML = this.formatInfo(info);
    }, () => {
      $('trace-data').innerHTML = 'Can\'t get Treaceability info.';
    });
  };

  TraceTest.getBtWifiAddress = function() {
    RemoteHelper.readFile(TRACE_BT_MAC_ADDRESS, (address) => {
      $('trace-bt').innerHTML = 'BT ADD: ' + this.formatInfo(address);
    });

    RemoteHelper.readFile(TRACE_WIFI_MAC_ADDRESS, (address) => {
      $('trace-wifi').innerHTML = 'WIFI ADD: ' + this.formatInfo(address);
    });
  };

  TraceTest.getIMEIs = function() {
    var promises = [];
    for (var i = 0; i < navigator.mozMobileConnections.length; i++) {
      promises.push(navigator.mozMobileConnections[i].getDeviceIdentities());
    }

    Promise.all(promises).then((imeis) => {
      if (imeis.length === 2) {
        $('trace-imei').innerHTML =
          'IMEI1: ' + imeis[0].imei + '<br/>' +
          'IMEI2: ' + imeis[1].imei + '<br/>';
      } else {
        $('trace-imei').innerHTML =
          'IMEI: ' + imeis[0].imei + '<br/>';
      }
    }, () => {});
  };

  TraceTest.formatInfo = function(response) {
    response = response.replace(/OK/g, '');
    var array = response.split('\n');
    var s = '';
    array.forEach(function(str) {
      s += str + '<br/>';
    });

    return s;
  };

  function render() {
    return `
        <div id="title">TRACEABILITY</div>
        <div id="content">
          <div id="trace-info" tabindex="1">
            <div id="trace-imei"></div>
            <div id="trace-bt"></div>
            <div id="trace-wifi"></div>
            <div id="trace-data"></div>
            <div id="trace-rf-gsm"></div>
            <div id="trace-rf-lte"></div>
          </div>
        </div>`;
  }

  exports.Test = TraceTest;
}(window));
