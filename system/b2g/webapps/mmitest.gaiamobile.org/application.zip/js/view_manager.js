/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function ViewManager() {}
  ViewManager.prototype = {
    _currentPanel: '#main-view',

    get currentPanel() {
      return this._currentPanel;
    },

    set currentPanel(hash) {
      if (!hash.startsWith('#')) {
        hash = '#' + hash;
      }

      if (hash === this._currentPanel) {
        document.querySelector(this._currentPanel).classList.remove('hidden');
        return;
      }

      let oldPanel = document.querySelector(this._currentPanel);
      let newPanel = document.querySelector(hash);

      if (oldPanel && newPanel) {
        this._currentPanel = hash;
        this._transit(oldPanel, newPanel);
      }
    },

    _transit: function transit(oldPanel, newPanel) {
      // switch hidden class
      oldPanel.classList.add('hidden');
      newPanel.classList.remove('hidden');

      setTimeout(function nextTick() {
        let event = new CustomEvent('panelready', {
          detail: {
            previous: '#' + oldPanel.id,
            current: '#' + newPanel.id
          }
        });
        window.dispatchEvent(event);
      });
    },

    start: function() {
      setTimeout(() => {
        EventSender.emit('panelready', {
          previous: '#main-view',
          current: '#main-view'
        });
      });
    }
  };

  exports.ViewManager = ViewManager;
}(window));
