/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */

'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [native_interface_sprd.js] = ' + s + '\n');
    }
  }
  function NIQ() {
    debug('new qcom device interface');
  }

  NIQ.prototype = {
    init: function() {
      // start gps  to speed up test result
      debug('Start GPS when qcom interface init');
      this.startGps();
    },

    // GPS API
    startGps: function _startGps() {
      if (navigator.engmodeExtension) {
        debug('start search GPS background');
        navigator.engmodeExtension.startGpsTest();
      }
    },

    stopGps: function _stopGps() {
      if (navigator.engmodeExtension) {
        debug('stop background search GPS');
        navigator.engmodeExtension.stopGpsTest();
      }
    },

    // Audio elements API
    micLoop: function() {
      if (navigator && navigator.engmodeExtension) {
        navigator.engmodeExtension.startAudioLoopTest('mic');
      }
    },

    resetMicLoop: function() {
      if (navigator && navigator.engmodeExtension) {
        // stop audio first
        navigator.engmodeExtension.stopAudioLoopTest();
        setTimeout(() => {
          // then stop mic
          navigator.engmodeExtension.startAudioLoopTest('stop-mic');
        }, 1000);
      }
    },

    // Accessories API
    headsetMicLoop: function() {
      navigator.engmodeExtension.startAudioLoopTest('headset-mic');
    },

    resetHeadsetMicLoop: function() {
      navigator.engmodeExtension.stopAudioLoopTest();
      setTimeout(() => {
        navigator.engmodeExtension.startAudioLoopTest('stop-headset-mic');
      }, 500);
    },

    getBatteryInfo: function() {
      let info = {};
      if (navigator.engmodeExtension) {
        let request = navigator.engmodeExtension.getSysInfo('BATTERY_TEMP');
        request.onsuccess = () => {
          info.temp = request.result / 10;
          info.content = navigator.engmodeExtension.fileReadLE('batterycapacity');
          info.voltage = (navigator.engmodeExtension.fileReadLE('batteryvoltage_now') / 1000000).toFixed(2);
          info.present = navigator.engmodeExtension.fileReadLE('battery_present');

          EventSender.emit('nativeResponse', {message: 'getBatteryInfo', response: info});
        };
      }
    }
  };
  exports.NI = NIQ;
}(window));