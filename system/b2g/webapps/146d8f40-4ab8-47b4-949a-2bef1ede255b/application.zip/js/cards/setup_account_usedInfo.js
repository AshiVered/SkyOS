
define(['require','cards','l10n!','evt','./base','template!./setup_account_usedInfo.html'],function(require) {

let cards = require('cards'),
    mozL10n = require('l10n!'),
    evt = require('evt');

return [
  require('./base')(require('template!./setup_account_usedInfo.html')),
  {
    onArgs: function(args) {
      this.account = args.account;
      this.activity = args.activity;
      this.identity = this.account.identities[0];
      this.identity.modifyIdentity({
        signatureEnabled: true,
        signature: mozL10n.get('settings-default-signature-2')
      });
    },

    onNext: function() {
      cards.pushCard('setup_account_settingsInfo', 'animate', {
        account: this.account,
        activity: this.activity
      });
    },

    onCardVisible: function() {
      let menuOptions = [{
        name: 'Next',
        l10nId: 'setup-info-next',
        priority: 3,
        method: () => {
          this.onNext();
        }
      }];
      NavigationMap.setSoftKeyBar(menuOptions);

      evt.emit('userAddDone', {
        account: this.account,
        activity: !!this.activity
      });

      this.accountUsedInfoNode.focus();
    }
  }
];
});
