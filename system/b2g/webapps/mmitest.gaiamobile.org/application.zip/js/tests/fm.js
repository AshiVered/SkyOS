/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [fm.js] = ' + s + '\n');
    }
  }

  const MIN_FREQ = 87.5;
  const MAX_FREQ = 108;

  var FMTest = new TestItem(render);

  FMTest.updateUI = function() {
    debug('FMTest.updateUI');
    var freq = this.frequency;
    freq = parseFloat(freq.toFixed(1));
    this.centerText.innerHTML = freq + 'MHz.' + '<br>' +
      'Press Left and Right soft-key to change frequency.';

    this.freqP.hidden = false;
    this.freqM.hidden = false;
    this.passButton.disabled = '';
    this.failButton.disabled = '';
  };

  FMTest.adjustFreq = function(operatorStr) {
    if (operatorStr === 'ArrowLeft' &&
      this.frequency > MIN_FREQ) {
      this.frequency -= 0.1;
    } else if (operatorStr === 'ArrowRight' &&
      this.frequency < MAX_FREQ) {
      this.frequency += 0.1;
    }

    this.updateUI();
    this.fm.setFrequency(this.frequency);
    debug('FMTest: current frequency is ' + parseFloat(this.frequency.toFixed(1)));
  };

  FMTest.turnOn = function() {
    if (!this.fm.enabled) {
      this.centerText.innerHTML = 'FM init...';
      // Disable both button when FM is initializing.
      this.passButton.disabled = 'disabled';
      this.failButton.disabled = 'disabled';
      this.fm.enable(this.frequency);
      setTimeout(() => {
        this.passButton.disabled = '';
        this.failButton.disabled = '';
      }, 3000);
    }
  };

  FMTest.turnOff = function() {
    if (this.fm.enabled) {
      this.fm.disable();
    }

    this.freqP.hidden = true;
    this.freqM.hidden = true;
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = '';
    this.centerText.innerHTML = 'Please insert headset.';
  };

  FMTest.updateFMRadioState = function() {
    if (this.fm.antennaAvailable || this.acm.headphones) {
      this.turnOn();
    } else {
      this.turnOff();
    }
  };

  FMTest.onInit = function() {
    this.fm = navigator.mozFMRadio;
    this.acm = navigator.mozAudioChannelManager;

    if (this.fm && this.acm) {
      debug('FMTest onInit ...');
      this.frequency = 103.7;
      this.freqP = this.container.querySelector('.freq-increase');
      this.freqM = this.container.querySelector('.freq-decrease');
      this.centerText = this.container.querySelector('#centertext');
      this.freqP.hidden = true;
      this.freqM.hidden = true;
      this.passButton.disabled = 'disabled';
      this.failButton.disabled = '';

      // Init the headphone's volume value
      navigator.mozSettings.createLock().set({
        'audio.volume.content': 8
      });

      this.updateFMRadioState();
      this.fm.onenabled = this.updateUI.bind(this);
      this.acm.onheadphoneschange = this.updateFMRadioState.bind(this);
    }
  };

  FMTest.onDeinit = function() {
    if (this.fm.enabled) {
      this.fm.disable();
    }
  };

  FMTest.onHandleEvent = function(evt) {
    switch (evt.key) {
      case 'ArrowLeft':
      case 'ArrowRight':
        if (this.fm.enabled) {
          this.adjustFreq(evt.key);
        }
        break;
      default:
        break;
    }
    return false;
  };

  function render() {
    return `
        <div id="title">FM Radio</div>
        <div id="centertext">To be continued...</div>
        <button class="buttons freq-increase">freq +</button>
        <button class="buttons freq-decrease">freq -</button>`;
  }

  exports.Test = FMTest;
}(window));
