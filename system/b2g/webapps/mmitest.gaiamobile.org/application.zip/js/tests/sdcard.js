/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [sdcard.js] = ' + s + '\n');
    }
  }

  var SDTest = new TestItem(render);

  SDTest.updateInfo = function(state) {
    switch (state) {
      case 'available':
        this.passButton.disabled = '';
        this.centerText.textContent = 'SD card test OK';
        break;

      case 'shared':
        this.centerText.textContent = 'SD card is in use';
        break;

      case 'unavailable':
        this.centerText.textContent = 'no SD card insert.';
        break;
    }
  };

  SDTest.onInit = function() {
    this.centerText = this.container.querySelector('#centertext');
    this.centerText.textContent = 'Detecting SD card...';
    this.passButton.disabled = 'disabled';

    this.storage = navigator.getDeviceStorages('sdcard');
    if (!this.storage || this.storage.length < 2 || 'undefined' === this.storage[this.storage.length - 1]) {
      this.centerText.textContent = 'No SD card';
      return;
    }
    this.storage[this.storage.length - 1].addEventListener('change', this.onHandleEvent.bind(this));
    this.storage[this.storage.length - 1].available().onsuccess = function (e) {
      SDTest.updateInfo(e.target.result);
    };

    this.storage[this.storage.length - 1].available().onerror = function (e) {
      SDTest.updateInfo(e.target.result);
    };
  };

  SDTest.onDeinit = function() {
    if (this.storage && this.storage.length > 0) {
      this.storage[this.storage.length - 1].removeEventListener('change', this.onHandleEvent);
    }
  };

  SDTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    switch (evt.type) {
      case 'change':
        debug('hendle stroage state change: ' + evt.reason);
        switch (evt.reason) {
          case 'available':
          case 'unavailable':
          case 'shared':
            this.updateInfo(evt.reason);
            break;
        }
        break;
      default:
        break;
    }

    return false;
  };

  function render() {
    return `
        <div id="title">MEMORYCARD</div>
        <div id="centertext"></div>`;
  }

  exports.Test = SDTest;
}(window));
