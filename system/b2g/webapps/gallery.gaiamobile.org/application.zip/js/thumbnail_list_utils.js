'use strict';
/*
 * This file provide some functions to help update the thumbnail list
 *
 */

function lockSelectedPhotos() {
  let IMGS = thumbnails.querySelectorAll('.selected.thumbnail-list-img');
  if (IMGS.length < 1)
    return;
  let lockItemsLength = 0;
  let n = 0;
  let containLargeImages = false;
  Array.forEach(IMGS, (IMG) => {
    if (!IMG.fileData.metadata.locked && !IMG.fileData.metadata.largeSize) {
      updateMetadata(IMG.dataset.filename, { locked: true }, () => {
        n++;
        lockItemsLength++;
        IMG.lockStatusNode.reset(true);
        IMG.fileData.metadata.locked = true;
        if (n === IMGS.length) {
          SoftkeyManager.setLock(true);
          if (containLargeImages) {
            Message.show('kai-some-photos-not-lock');
          } else {
            Message.show('kai-multiple-images-locked', lockItemsLength);
          };
          setTimeout(() => { setView(LAYOUT_MODE.list); }, 500);
        };
      });
    } else {
      if (IMG.fileData.metadata.largeSize) {
        containLargeImages = true;
      };
      n++;
    };
  });
};

function unLockSelectedPhotos() {
  let IMGS = thumbnails.querySelectorAll('.selected.thumbnail-list-img');
  if (IMGS.length < 1)
    return;
  let unlockItemsLength = 0;
  let n = 0;
  Array.forEach(IMGS, (IMG) => {
    if (IMG.fileData.metadata.locked) {
      updateMetadata(IMG.dataset.filename, { locked: false }, () => {
        n++;
        unlockItemsLength++;
        IMG.lockStatusNode.reset(false);
        IMG.fileData.metadata.locked = false;
        if (n === IMGS.length) {
          SoftkeyManager.setLock(false);
          Message.show('kai-multiple-images-unlocked', unlockItemsLength);
          setTimeout(() => { setView(LAYOUT_MODE.list); }, 500);
        }
      });
    } else {
      n++;
    }
  });
}

function shareItems() {
  if (currentView === LAYOUT_MODE.select) { // share selected items
    let IMGS = thumbnails.querySelectorAll('.selected.thumbnail-list-img');
    let largeImageNames = [];
    let shareImageNames = [];
    if (IMGS.length < 1) {
      return;
    };
    Array.forEach(IMGS, function (IMG) {
      if (IMG.fileData.metadata.largeSize) {
        largeImageNames.push(IMG.fileData.name);
      } else {
        shareImageNames.push(IMG.fileData.name);
      };
    });
    let blobs = shareImageNames.map(function(name) {
      return selectedFileNamesToBlobs[name];
    });
    if (largeImageNames.length > 0) {
      Message.show('kai-some-photos-not-share');
    };
    share(blobs);
  } else { // share current items
    let fileinfo = FilesStore.getFileInfo(FilesStore.currentFileKey);
    photodb.getFile(fileinfo.name, function(blob) {
      share([blob]);
    });
  }
}

function resetMultiSelect () {
  thumbnails.setAttribute('mode', 'multi-select');
  Array.forEach(thumbnails.querySelectorAll('.thumbnail-list-img'),
    function (item) {
      item.dataset.selected = false;
    });
}

// multiple select -- select all
function selectAllPhotos() {
  var selectedNum = 0;
  var IMGS =thumbnails.querySelectorAll('.thumbnail-list-img');
  selectedFileNames = [];
  selectedFileNamesToBlobs = {};
  selectedLock = 0;
  selectrdInvalid = 0;
  if (isSelectAll) {
    Gallery.isTriggerAll = true;
    Array.forEach(IMGS,
      function (IMG) {
        IMG.classList.add('selected');
        IMG.dataset.selected = true;
        selectedFileNames.push(IMG.fileData.name);
        photodb.getFile(IMG.fileData.name, function(file) {
          selectedFileNamesToBlobs[ IMG.fileData.name ] = file;
        });
        if (IMG.fileData.metadata.locked) {
          selectedLock ++;
        };
        if (IMG.parentNode.classList.contains("largeSize")) {
          selectrdInvalid ++;
        };
      });
    selectedNum = IMGS.length;
    SoftkeyManager.setSkMenu();
    SoftkeyManager.updateSkText('kai-deselect-all');
  }
  else {
    Gallery.isTriggerAll = false;
    Array.forEach(IMGS,
      function(IMG) {
        IMG.classList.remove('selected');
        IMG.dataset.selected = false;
      });
    SoftkeyManager.setSkMenu();
    SoftkeyManager.updateSkText('kai-select-all');
  }
  updateMultipleCount(selectedNum);
  isSelectAll = !isSelectAll;
  Gallery.setSelectSubView(!isSelectAll?"all":"");
}

function resetSelection() {
  if (!isPhone) {
    // Clear preview screen on large device.
    clearFrames();
  }
  selectedFileNames = [];
  selectedFileNamesToBlobs = {};
  updateMultipleCount(0);
  resetMultiSelect();
}

function cleanSelectStates() {
  selectedLock = 0;
  selectrdInvalid = 0;
  isSelectAll = true;
  Gallery.isTriggerAll = false;
}

function updateMultipleCount(count) {
  navigator.mozL10n.setAttributes(
    $('multiple-select-count'),
    'kai-selected-items-count',
    { n: count }
  );
}

// multiple select -- delete selected photos
function deleteSelectedPhotos() {
  Gallery.deleteFiles = [];
  let IMGS = thumbnails.querySelectorAll('.selected.thumbnail-list-img');
  if (IMGS.length < 1) {
    return;
  };
  for (let i = 0; i < IMGS.length; i++) {
    let fileData = IMGS[i].fileData;
    if (fileData.metadata.locked) {
      containLocked = true;
    } else {
      Gallery.deleteFiles.push(IMGS[i]);
    };
  };
  //Show delete confirm Dialog
  var dialogConfig = {
    title: { id: 'kai-confirmation', args: {} },
    body: { id: IMGS.length > 1
      ? 'kai-delete-selected-images' : 'kai-delete-selected-image', args: {} },
    cancel: {
      l10nId: 'cancel',
      callback: function() {},
    },
    confirm: {
      l10nId:'delete',
      callback: function() {
        Gallery.deleteSelected = true;
        window.addEventListener('keydown', keydownHandler, true);
        document.getElementById('mask-background').classList.remove('hidden');
        SoftkeyManager.softkey.hide();
        setView(LAYOUT_MODE.list);
        NavigationMap.inProgress = true;
        listProgressBar.value = 0;
        listProgressBar.classList.remove('hidden');
        let storage = navigator.getDeviceStorage('pictures');
        for (let i = 0; i < Gallery.deleteFiles.length; i++) {
          let fileData = Gallery.deleteFiles[i].fileData;
          deleteSeletedFiles(storage, fileData);
        };
      },
    },
  };
  confirmDialog(dialogConfig);
}

function deleteSeletedFiles(storage, fileData) {
  let name = fileData.name;
  let metadata = fileData.metadata;
  let deleteRequest = storage.delete(name);
  deleteRequest.onsuccess = () => {
    Gallery.deleteSuccessFiles.push(fileData);
    let successCount =  Gallery.deleteSuccessFiles.length;
    let errorCount = Gallery.deleteErrorFiles.length;
    let deletedCount = successCount + errorCount;
    if (deletedCount !== Gallery.deleteFiles.length) {
      return;
    };
    for (let i = 0; i < successCount; i++) {
      let fileData = Gallery.deleteSuccessFiles[i];
      let deleteImage = fileData.thumbnailContainer;
      let deleteImgFileKey = Gallery.numberFilesKeyCounter(deleteImage);
      let fileInfo = FilesStore.getFileInfo(deleteImgFileKey);
      thumbnailList.removeItem(fileInfo);
      FilesStore.deteleFileInfo(deleteImgFileKey);
      listProgressBar.value =
        parseInt(100 * i / successCount);
    };
    deleteDone(successCount);
  };
  deleteRequest.onerror = (e) => {
    Gallery.deleteErrorFiles.push(fileData);
    console.error('Failed to delete', name,
      'from DeviceStorage:', e.target.error);
  };
  if (metadata.preview && metadata.preview.filename) {
    storage.delete(metadata.preview.filename);
  };
}

function deleteDone(deleteFilesCount) {
  if (containLocked) {
    Message.show('kai-some-photos-not-delete');
    containLocked = false;
  } else {
    Message.show('kai-deleted-n-photos', deleteFilesCount);
  };
  listProgressBar.classList.add('hidden');
  NavigationMap.inProgress = false;
  document.getElementById('mask-background').classList.add('hidden');
  if (FilesStore.getLength()) {
    let thumbnailImageDiv = thumbnails.querySelectorAll('.thumbnail-list-img');
    NavigationMap.calculateTopLeftIndex(Gallery.currentFocusIndex);
    NavigationMap.refreshBgImage(Gallery.thumbnailRefreshIndex,
      thumbnailImageDiv);
  } else {
    if (Gallery.creatingThumbnails) {
      Overlay.show('scanning');
    } else {
      Overlay.show('emptygallery');
    }
  };
  SoftkeyManager.softkey.show();
  needNav();
  Gallery.deleteErrorFiles = [];
  Gallery.deleteFiles = [];
  Gallery.deleteSuccessFiles = [];
  Gallery.deleteSelected = false;
  window.removeEventListener('keydown', keydownHandler, true);
}

function keydownHandler(e) {
  switch (e.key) {
    case 'BrowserBack':
    case 'Backspace':
      SoftkeyManager.backKeyHandler(e);
      break;
    default:
      e.preventDefault();
      e.stopPropagation();
      break;
  }
}

// check if the current display/selected image is locked
function chkIsCurrentLocked() {
  let fileinfo = FilesStore.getFileInfo(FilesStore.currentFileKey);
  if(fileinfo && fileinfo.metadata) {
    return typeof fileinfo.metadata.locked === 'undefined'?false : fileinfo.metadata.locked;
  }
  return false;
}

function chkIsCurrentLarge() {
  let fileinfo = FilesStore.getFileInfo(FilesStore.currentFileKey);
  if (fileinfo && fileinfo.metadata &&
      fileinfo.metadata.largeSize) {
    return true;
  }
  return false;
}

function updateMetadata(fileName, metadata, callback) {
  photodb.updateMetadata(fileName, metadata, callback);
}

function updateLockStatusOfCurrentFile() {
  let fileInfo = FilesStore.getFileInfo(FilesStore.currentFileKey);
  var fileName = fileInfo.name;
  var thumbnailContainer = fileInfo.thumbnailContainer;
  var lock = !chkIsCurrentLocked();
  photodb.updateMetadata(fileName, {locked: lock}, function () {
      if (currentView === LAYOUT_MODE.fullscreen)
        currentFrame.container.lockStatusNode.reset(lock);
      else
        thumbnailContainer.lockStatusNode.reset(lock);
      fileInfo.metadata.locked = lock;
      SoftkeyManager.setLock(lock);
      Message.show(lock?'kai-single-image-locked':'kai-single-image-unlocked');
    }
  );
}

function deleteSingleItem() {
  let fileinfo = FilesStore.getFileInfo(FilesStore.currentFileKey);
  var msg = 'delete-photo?';

  // show error infomation if current file is locked and return
  if (fileinfo.metadata.locked) {
    var dialogConfig = {
      title: {id: 'kai-error', args: {}},
      body: {id: 'kai-error-delete-locked-image', args: {}},
      accept: {
        l10nId:'ok',
        callback: function(){
        },
      },
    };
    confirmDialog(dialogConfig);
    return;
  }

  //Show delete confirmation Dialog
  var dialogConfig = {
    title: {id: 'kai-confirmation', args: {}},
    body: {id: currentView === LAYOUT_MODE.fullscreen ? 'kai-delete-this-image' :'kai-delete-selected-image', args: {}},
    backcallback: function(){
    },
    cancel: {
      l10nId:'cancel',
      callback: function(){
      },
    },
    confirm: {
      l10nId:'delete',
      callback: function(){
        if (currentView === LAYOUT_MODE.fullscreen) {
          window.performance.mark('gallery-delete-start');
        }
        window.addEventListener('filedeleted', singleDeleteDone);
        deleteFile(fileinfo.name, fileinfo.metadata);
        Message.show('kai-single-image-deleted');
      },
    },
  };
  confirmDialog(dialogConfig);

  function singleDeleteDone() {
    window.removeEventListener('filedeleted', singleDeleteDone);
    needNav();
  }
}

// update info dialog
function displayFileInfo(data, filename) {
  var name_label = 'name-label';
  var size_label =  'size-label';
  var image_type_label = 'image-type-label'
  var date_taken_label = 'date-taken-label';
  var resolution_label = 'resolution-label';

  var list_cont = {};
  list_cont[name_label] = data['info-name'];
  list_cont[size_label] = data['info-size'];
  list_cont[image_type_label] = data['info-type'];
  list_cont[date_taken_label] = data['info-date'];
  list_cont[resolution_label] = data['info-resolution'];

  var infoContainer = infoDialog.querySelector('#infoView');
  infoContainer.innerHTML = '';
  Object.keys(list_cont).forEach(function (key) {
    var nameItem = document.createElement('dt');
    nameItem.setAttribute('data-l10n-id',key);
    nameItem.textContent = lget(key);
    var valueItem = document.createElement('dd');
    valueItem.classList.add('value');
    valueItem.textContent = list_cont[key];
    infoContainer.appendChild(nameItem);
    infoContainer.appendChild(valueItem);
  });
}

/**
* create a div and inert into thumbnail to display lock icon
**/
function createLockDiv(imgNode, locked) {
  var lockStatusNode = document.createElement('div');
  lockStatusNode.classList.add('thumbnail-lock-status');
  lockStatusNode.classList.add('gaia-icon');
  lockStatusNode.classList.add('icon-lock');
  lockStatusNode.style.display = locked? 'block':'none';
  lockStatusNode.reset = function(show) {
    this.style.display = show? 'block':'none';
  }
  imgNode.lockStatusNode = lockStatusNode;
  imgNode.appendChild(lockStatusNode);
}

/**
* create a input element and insert into thumbnail
**/
function createMultipleSelectInput(imgNode) {
  var checkBoxContainerNode = document.createElement('div');
  checkBoxContainerNode.classList.add('check-icon');
  checkBoxContainerNode.classList.add('hidden');
  imgNode.checkBoxContainerNode = checkBoxContainerNode;
  imgNode.appendChild(checkBoxContainerNode);
}
