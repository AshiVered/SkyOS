/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [result_manager.js] = ' + s + '\n');
    }
  }

  const MMITEST_RESULT = 'mmitest_result';

  var ResultManager = {
    init: function(config) {
      this.loadConfig(config);

      window.addEventListener('updateResult', this.updateResult.bind(this));
    },

    loadConfig: function(obj) {
      this.config = obj[DEVICETYPE];
      this.createResultList(this.config);
    },

    createResultList: function(config) {
      asyncStorage.getItem(MMITEST_RESULT, (value) => {
        if (!value) {
          // Origin init result value when first open mmitest without factory reset
          let resultTemp = {'auto': {}, 'manu': {}};
          for (let i = 0, len = config.testItems.length; i < len; i++) {
            let name = config.testItems[i].htmlName;
            let manuEnable = config.testItems[i].manuTest[0].testFlag;
            let autoEnable = config.testItems[i].autoTest[0].testFlag;
            if ('true' === manuEnable) {
              resultTemp.manu[name] = 'NO TEST';
            }

            if ('true' === autoEnable) {
              resultTemp.auto[name] = 'NO TEST';
            }
          }
          this.result = resultTemp;
        } else {
          this.result = JSON.parse(value);
        }

        debug('test result:' + JSON.stringify(this.result));
      });
    },

    updateResult: function(event) {
      let name = event.detail.name;
      let mode = event.detail.mode;
      let value = event.detail.value;

      debug('Protect result ||mode: ' + mode + ' || name:' + name +
        ' || value:' + value);
      if (this.result[mode][name] !== value) {
        this.result[mode][name] = value;

        this.saveResult();
      }
    },

    saveResult: function() {
      asyncStorage.setItem(MMITEST_RESULT, JSON.stringify(this.result));
      debug('Update async storage result:' + JSON.stringify(this.result));
    }
  };

  exports.ResultManager = ResultManager;
}(window));
