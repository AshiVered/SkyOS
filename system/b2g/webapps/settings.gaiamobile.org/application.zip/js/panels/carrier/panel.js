define(['require','modules/settings_panel','carrier','shared/settings_listener'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');
  var CarrierSettings = require('carrier');
  const SettingsListener = require('shared/settings_listener');

  return function ctor_carrier() {
    var listElements = document.querySelectorAll('#carrier li');

    //FIHBDC add for BTS-3426 begins
    var GEOLOCATION_KEY = 'geolocation.enabled';
    var dataConnectionSelect = null;
    var dataConnection = null;
    var closeGeoloacationDialog = false;
    var geoloacationDialog = null;

    function handleDataConnection(evt) {
      const enabled = (evt.target.value === 'true' || false);
      showDataConfirmDialog(enabled);
    }

    function changeDataConnectionSettings(value) {
      const req = SettingsListener.getSettingsLock().set({ 'ril.data.enabled': value });
      req.onsuccess = function () {
        showToast('changessaved');
      };
    }

    function showDataConfirmDialog(enabled) {
      var titleId = null;
      var bodyId = null;
      var confirmName = null;
      var confirml10nId = null;

      if(enabled){
        titleId = 'use-mobile-data-title';
        bodyId = 'use-mobile-data-content';
        confirmName = 'Turn On';
        confirml10nId = 'turnOn';
      }else{
        titleId = 'dataConnection-off';
        bodyId = 'dataConnection-off-content';
        confirmName = 'Ok';
        confirml10nId = 'ok';
      }

      let dialogConfig = {
        title: { id: titleId, args: {} },
        body: { id: bodyId, args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback: function () {
            dataConnectionSelect.value = enabled ? 'false' : 'true';
            dataConnection.focus();
          }
        },
        confirm: {
          name: confirmName,
          l10nId: confirml10nId,
          priority: 3,
          callback: function () {
            changeDataConnectionSettings(enabled);
            dataConnectionSelect.value = enabled ? 'true' : 'false';
            dataConnection.focus();
            if(false == enabled){
              showGeolocationDialog();
            }
          }
          //dialog.destroy();
        },
        backcallback: function () {
          dataConnectionSelect.value = enabled ? 'false' : 'true';
          dataConnection.focus();
          //dialog.destroy();
        }
      }
      var dialog = new ConfirmDialogHelper(dialogConfig);
      dialog.show(document.getElementById('app-confirmation-dialog'));
    }

    function updateDataConnectionState(enabled) {
      dataConnectionSelect.value = enabled;
    }

    function showGeolocationDialog() {
      let dialogConfig = {
        title: { id: 'turn-off-location', args: {} },
        body: { id: 'turn-off-location-content', args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback: function () {
            //dataConnection.focus();
          }
        },
        confirm: {
          name: 'Ok',
          l10nId: 'ok',
          priority: 3,
          callback: function () {
          turnOffGeoloaction();
          //dataConnection.focus();
          }
        },
        backcallback: function () {
          //dataConnection.focus();
        }
      };

      var lock = window.navigator.mozSettings.createLock();
      lock.get(GEOLOCATION_KEY).then((result) => {
        var geoEnabled = result[GEOLOCATION_KEY];
        if(geoEnabled == true){
          geoloacationDialog = new ConfirmDialogHelper(dialogConfig);
          if(closeGeoloacationDialog == false){
            geoloacationDialog.show(document.getElementById('app-confirmation-dialog'));
          }
        }
      });
    }

    function updateDataConnectionState(enabled) {
      dataConnectionSelect.value = enabled;
    }

    function turnOffGeoloaction(){
      var lock = window.navigator.mozSettings.createLock();
      var option = {};
      option[GEOLOCATION_KEY] = false;
      var req = lock.set(option);

      req.onsuccess = () => {
        showToast('changessaved');
        localStorage.positionmessageEnabled = false;
        SettingsService.navigate('root');
      };
    }
    //FIHBDC add for BTS-3426 end

    return SettingsPanel({
      onInit: function() {
        this.params = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: [{
            name: 'Select',
            l10nId: 'select',
            priority: 2,
            method: function() {}
          }]
        };
        var carrierSettings = CarrierSettings();
        carrierSettings.init();
        //FIHBDC add for BTS-3426 begins
        dataConnection = document.querySelector('#liItem-dataConnection');
        dataConnectionSelect = document.querySelector('select.dataConnection-select');
        //FIHBDC add for BTS-3426 end
      },

      onBeforeShow: function() {
        //FIHBDC add for BTS-3426 begins
        closeGeoloacationDialog = false;
        //FIHBDC add for BTS-3426 end
        SettingsSoftkey.init(this.params);
        SettingsSoftkey.show();
        ListFocusHelper.addEventListener(listElements);
        initUIBySettings(['data.settings.ui', 'data.roaming.settings.ui']);
        addListenerForCustomization(['data.settings.ui', 'data.roaming.settings.ui']);
        //FIHBDC add for BTS-3426 begins
        SettingsListener.observe('ril.data.enabled', false, updateDataConnectionState);
        dataConnectionSelect.addEventListener('change', handleDataConnection);
        //FIHBDC add for BTS-3426 end
      },

      onBeforeHide: function(){
        //FIHBDC add for BTS-3426 begins
        closeGeoloacationDialog = true;
        if(geoloacationDialog){
          geoloacationDialog.close();
        }
        //FIHBDC add for BTS-3426 end
        removeListenerForCustomization(['data.settings.ui', 'data.roaming.settings.ui']);
        ListFocusHelper.removeEventListener(listElements);
        //FIHBDC add for BTS-3426 begins
        dataConnectionSelect.removeEventListener('change', handleDataConnection);
        SettingsListener.unobserve('ril.data.enabled', updateDataConnectionState);
        //FIHBDC add for BTS-3426 end
      }
    });
  };
});
