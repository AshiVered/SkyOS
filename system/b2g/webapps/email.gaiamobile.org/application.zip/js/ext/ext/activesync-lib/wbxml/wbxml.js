(function(t, e) {
    if ("object" == typeof exports) {
        module.exports = e(), this.Blob = require("./blob").Blob;
        var n = require("stringencoding");
        this.TextEncoder = n.TextEncoder, this.TextDecoder = n.TextDecoder;
    } else "function" == typeof define && define.amd ? define(e) : t.WBXML = e();
})(this, function() {
    function t(t, e, n) {
        function i() {
            var t = this instanceof i ? this : Object.create(i.prototype), e = Error(), r = 1;
            if (t.stack = e.stack.substring(e.stack.indexOf("\n") + 1), t.message = arguments[0] || e.message, 
            n) {
                r += n.length;
                for (var s = 0; s < n.length; s++) t[n[s]] = arguments[s + 1];
            }
            var o = /@(.+):(.+)/.exec(t.stack);
            return t.fileName = arguments[r] || o && o[1] || "", t.lineNumber = arguments[r + 1] || o && o[2] || 0, 
            t;
        }
        return i.prototype = Object.create((e || Error).prototype), i.prototype.name = t, 
        i.prototype.constructor = i, i;
    }
    function e(t, e) {
        this.strings = [], this.offsets = {};
        for (var n = 0, i = 0; i < t.length; i++) 0 === t[i] && (this.offsets[n] = this.strings.length, 
        this.strings.push(e.decode(t.subarray(n, i))), n = i + 1);
    }
    function n(t) {
        t.__nsnames__ = {}, t.__tagnames__ = {}, t.__attrdata__ = {};
        for (var e in t) {
            var n = t[e];
            if (!e.match(/^__/)) {
                if (n.Tags) {
                    var i, r;
                    for (i in n.Tags) {
                        r = n.Tags[i], t.__nsnames__[r >> 8] = e;
                        break;
                    }
                    for (i in n.Tags) r = n.Tags[i], t.__tagnames__[r] = i;
                }
                if (n.Attrs) for (var s in n.Attrs) {
                    var o = n.Attrs[s];
                    "name" in o || (o.name = s), t.__attrdata__[o.value] = o, n.Attrs[s] = o.value;
                }
            }
        }
    }
    function i(t, e, n) {
        if (this.ownerDocument = t, this.type = e, this._attrs = {}, "string" == typeof n) {
            var i = n.split(":");
            1 === i.length ? this.localTagName = i[0] : (this.namespaceName = i[0], this.localTagName = i[1]);
        } else this.tag = n, Object.defineProperties(this, {
            namespace: {
                get: function() {
                    return this.tag >> 8;
                }
            },
            localTag: {
                get: function() {
                    return 255 & this.tag;
                }
            },
            namespaceName: {
                get: function() {
                    return this.ownerDocument._codepages.__nsnames__[this.namespace];
                }
            },
            localTagName: {
                get: function() {
                    return this.ownerDocument._codepages.__tagnames__[this.tag];
                }
            }
        });
    }
    function r(t) {
        this.ownerDocument = t;
    }
    function s(t, e) {
        this.ownerDocument = t, this.textContent = e;
    }
    function o(t, e, n, i) {
        this.ownerDocument = t, this.subtype = e, this.index = n, this.value = i;
    }
    function a(t) {
        this.ownerDocument = t;
    }
    function u(t, e) {
        this.ownerDocument = t, this.data = e;
    }
    function f(t, e) {
        this._data = t instanceof l ? t.bytes : t, this._codepages = e, this.rewind();
    }
    function l(t, e, n, i, r) {
        this._blobs = "blob" === r ? [] : null, this.dataType = r || "arraybuffer", this._rawbuf = new ArrayBuffer(1024), 
        this._buffer = new Uint8Array(this._rawbuf), this._pos = 0, this._codepage = 0, 
        this._tagStack = [], this._rootTagValue = null;
        var s = t.split(".").map(function(t) {
            return parseInt(t);
        }), o = s[0], a = s[1], u = (o - 1 << 4) + a, f = n;
        if ("string" == typeof n && (f = p[n], void 0 === f)) throw new Error("unknown charset " + n);
        var l = this._encoder = new TextEncoder(n);
        if (this._write(u), this._write(e), this._write(f), i) {
            var c = i.map(function(t) {
                return l.encode(t);
            }), h = c.reduce(function(t, e) {
                return t + e.length + 1;
            }, 0);
            this._write_mb_uint32(h);
            for (var g = 0; g < c.length; g++) {
                var _ = c[g];
                this._write_bytes(_), this._write(0);
            }
        } else this._write(0);
    }
    function c() {
        this.listeners = [], this.onerror = function(t) {
            throw t;
        };
    }
    var h = {}, g = {
        SWITCH_PAGE: 0,
        END: 1,
        ENTITY: 2,
        STR_I: 3,
        LITERAL: 4,
        EXT_I_0: 64,
        EXT_I_1: 65,
        EXT_I_2: 66,
        PI: 67,
        LITERAL_C: 68,
        EXT_T_0: 128,
        EXT_T_1: 129,
        EXT_T_2: 130,
        STR_T: 131,
        LITERAL_A: 132,
        EXT_0: 192,
        EXT_1: 193,
        EXT_2: 194,
        OPAQUE: 195,
        LITERAL_AC: 196
    }, _ = {
        message: "THIS IS AN INTERNAL CONTROL FLOW HACK THAT YOU SHOULD NOT SEE"
    }, d = t("WBXML.ParseError");
    h.ParseError = d, e.prototype = {
        get: function(t) {
            if (t in this.offsets) return this.strings[this.offsets[t]];
            if (0 > t) throw new d("offset must be >= 0");
            for (var e = 0, n = 0; n < this.strings.length; n++) {
                if (t < e + this.strings[n].length + 1) return this.strings[n].slice(t - e);
                e += this.strings[n].length + 1;
            }
            throw new d("invalid offset");
        }
    }, h.CompileCodepages = n;
    var w = {
        3: "US-ASCII",
        4: "ISO-8859-1",
        5: "ISO-8859-2",
        6: "ISO-8859-3",
        7: "ISO-8859-4",
        8: "ISO-8859-5",
        9: "ISO-8859-6",
        10: "ISO-8859-7",
        11: "ISO-8859-8",
        12: "ISO-8859-9",
        13: "ISO-8859-10",
        106: "UTF-8"
    }, p = {};
    for (var m in w) {
        var b = w[m];
        p[b] = m;
    }
    return h.Element = i, i.prototype = {
        get tagName() {
            var t = this.namespaceName;
            return t = t ? t + ":" : "", t + this.localTagName;
        },
        getAttributes: function() {
            var t = [];
            for (var e in this._attrs) {
                var n = this._attrs[e], i = e.split(":");
                t.push({
                    name: e,
                    namespace: i[0],
                    localName: i[1],
                    value: this._getAttribute(n)
                });
            }
            return t;
        },
        getAttribute: function(t) {
            return "number" == typeof t ? t = this.ownerDocument._codepages.__attrdata__[t].name : t in this._attrs || null === this.namespace || -1 !== t.indexOf(":") || (t = this.namespaceName + ":" + t), 
            this._getAttribute(this._attrs[t]);
        },
        _getAttribute: function(t) {
            for (var e = "", n = [], i = 0; i < t.length; i++) {
                var r = t[i];
                r instanceof o ? (e && (n.push(e), e = ""), n.push(r)) : e += "number" == typeof r ? this.ownerDocument._codepages.__attrdata__[r].data || "" : r;
            }
            return e && n.push(e), 1 === n.length ? n[0] : n;
        },
        _addAttribute: function(t) {
            if ("string" == typeof t) {
                if (t in this._attrs) throw new d("attribute " + t + " is repeated");
                return this._attrs[t] = [];
            }
            var e = t >> 8, n = 255 & t, i = this.ownerDocument._codepages.__attrdata__[n].name, r = this.ownerDocument._codepages.__nsnames__[e], s = r + ":" + i;
            if (s in this._attrs) throw new d("attribute " + s + " is repeated");
            return this._attrs[s] = [ t ];
        }
    }, h.EndTag = r, r.prototype = {
        get type() {
            return "ETAG";
        }
    }, h.Text = s, s.prototype = {
        get type() {
            return "TEXT";
        }
    }, h.Extension = o, o.prototype = {
        get type() {
            return "EXT";
        }
    }, h.ProcessingInstruction = a, a.prototype = {
        get type() {
            return "PI";
        },
        get target() {
            return "string" == typeof this.targetID ? this.targetID : this.ownerDocument._codepages.__attrdata__[this.targetID].name;
        },
        _setTarget: function(t) {
            return this.targetID = t, this._data = "string" == typeof t ? [] : [ t ];
        },
        _getAttribute: i.prototype._getAttribute,
        get data() {
            return this._getAttribute(this._data);
        }
    }, h.Opaque = u, u.prototype = {
        get type() {
            return "OPAQUE";
        }
    }, h.Reader = f, f.prototype = {
        _get_uint8: function() {
            if (this._index === this._data.length) throw _;
            return this._data[this._index++];
        },
        _get_mb_uint32: function() {
            var t, e = 0;
            do t = this._get_uint8(), e = 128 * e + (127 & t); while (128 & t);
            return e;
        },
        _get_slice: function(t) {
            var e = this._index;
            return this._index += t, this._data.subarray(e, this._index);
        },
        _get_c_string: function() {
            for (var t = this._index; this._get_uint8(); ) ;
            return this._data.subarray(t, this._index - 1);
        },
        rewind: function() {
            this._index = 0;
            var t = this._get_uint8();
            this.version = ((240 & t) + 1).toString() + "." + (15 & t).toString(), this.pid = this._get_mb_uint32(), 
            this.charset = w[this._get_mb_uint32()] || "unknown", this._decoder = new TextDecoder(this.charset);
            var n = this._get_mb_uint32();
            this.strings = new e(this._get_slice(n), this._decoder), this.document = this._getDocument();
        },
        _getDocument: function() {
            var t, e, n = {
                BODY: 0,
                ATTRIBUTES: 1,
                ATTRIBUTE_PI: 2
            }, f = n.BODY, l = 0, c = 0, h = !1, w = [], p = function(i) {
                f === n.BODY ? t ? t.textContent += i : t = new s(this, i) : e.push(i);
            }.bind(this);
            try {
                for (;;) {
                    var m = this._get_uint8();
                    if (m === g.SWITCH_PAGE) {
                        if (l = this._get_uint8(), !(l in this._codepages.__nsnames__)) throw new d("unknown codepage " + l);
                    } else if (m === g.END) if (f === n.BODY && c-- > 0) t && (w.push(t), t = null), 
                    w.push(new r(this)); else {
                        if (f !== n.ATTRIBUTES && f !== n.ATTRIBUTE_PI) throw new d("unexpected END token");
                        f = n.BODY, w.push(t), t = null, e = null;
                    } else if (m === g.ENTITY) {
                        if (f === n.BODY && 0 === c) throw new d("unexpected ENTITY token");
                        var b = this._get_mb_uint32();
                        p("&#" + b + ";");
                    } else if (m === g.STR_I) {
                        if (f === n.BODY && 0 === c) throw new d("unexpected STR_I token");
                        p(this._decoder.decode(this._get_c_string()));
                    } else if (m === g.PI) {
                        if (f !== n.BODY) throw new d("unexpected PI token");
                        f = n.ATTRIBUTE_PI, t && w.push(t), t = new a(this);
                    } else if (m === g.STR_T) {
                        if (f === n.BODY && 0 === c) throw new d("unexpected STR_T token");
                        var v = this._get_mb_uint32();
                        p(this.strings.get(v));
                    } else if (m === g.OPAQUE) {
                        if (f !== n.BODY) throw new d("unexpected OPAQUE token");
                        var T = this._get_mb_uint32(), E = this._get_slice(T);
                        t && (w.push(t), t = null), w.push(new u(this, E));
                    } else if ((64 & m || 128 & m) && 3 > (63 & m)) {
                        var y, I, A = 192 & m, k = 63 & m;
                        A === g.EXT_I_0 ? (y = "string", I = this._decoder.decode(this._get_c_string())) : A === g.EXT_T_0 ? (y = "integer", 
                        I = this._get_mb_uint32()) : (y = "byte", I = null);
                        var S = new o(this, y, k, I);
                        f === n.BODY ? (t && (w.push(t), t = null), w.push(S)) : e.push(S);
                    } else if (f === n.BODY) {
                        if (0 === c) {
                            if (h) throw new d("multiple root nodes found");
                            h = !0;
                        }
                        var x = (l << 8) + (63 & m);
                        if ((63 & m) === g.LITERAL) {
                            var v = this._get_mb_uint32();
                            x = this.strings.get(v);
                        }
                        t && w.push(t), t = new i(this, 64 & m ? "STAG" : "TAG", x), 64 & m && c++, 128 & m ? f = n.ATTRIBUTES : (f = n.BODY, 
                        w.push(t), t = null);
                    } else {
                        var D = (l << 8) + m;
                        if (128 & m) e.push(D); else {
                            if (m === g.LITERAL) {
                                var v = this._get_mb_uint32();
                                D = this.strings.get(v);
                            }
                            if (f === n.ATTRIBUTE_PI) {
                                if (e) throw new d("unexpected attribute in PI");
                                e = t._setTarget(D);
                            } else e = t._addAttribute(D);
                        }
                    }
                }
            } catch (b) {
                if (b !== _) throw b;
            }
            return w;
        },
        dump: function(t, e) {
            var n = "";
            void 0 === t && (t = 2);
            var i = function(e) {
                return new Array(e * t + 1).join(" ");
            }, r = [];
            e && (n += "Version: " + this.version + "\n", n += "Public ID: " + this.pid + "\n", 
            n += "Charset: " + this.charset + "\n", n += 'String table:\n  "' + this.strings.strings.join('"\n  "') + '"\n\n');
            for (var s = this.document, o = s.length, a = 0; o > a; a++) {
                var u = s[a];
                if ("TAG" === u.type || "STAG" === u.type) {
                    n += i(r.length) + "<" + u.tagName;
                    for (var f = u.getAttributes(), l = 0; l < f.length; l++) {
                        var c = f[l];
                        n += " " + c.name + '="' + c.value + '"';
                    }
                    "STAG" === u.type ? (r.push(u.tagName), n += ">\n") : n += "/>\n";
                } else if ("ETAG" === u.type) {
                    var h = r.pop();
                    n += i(r.length) + "</" + h + ">\n";
                } else if ("TEXT" === u.type) n += i(r.length) + u.textContent + "\n"; else if ("PI" === u.type) n += i(r.length) + "<?" + u.target, 
                u.data && (n += " " + u.data), n += "?>\n"; else {
                    if ("OPAQUE" !== u.type) throw new Error('Unknown node type "' + u.type + '"');
                    n += i(r.length) + "<![CDATA[" + u.data + "]]>\n";
                }
            }
            return n;
        }
    }, h.Writer = l, l.Attribute = function(t, e) {
        if (this.isValue = "number" == typeof t && 128 & t, this.isValue && void 0 !== e) throw new Error("Can't specify a value for attribute value constants");
        this.name = t, this.value = e;
    }, l.StringTableRef = function(t) {
        this.index = t;
    }, l.Entity = function(t) {
        this.code = t;
    }, l.Extension = function(t, e, n) {
        var i = {
            string: {
                value: g.EXT_I_0,
                validator: function(t) {
                    return "string" == typeof t;
                }
            },
            integer: {
                value: g.EXT_T_0,
                validator: function(t) {
                    return "number" == typeof t;
                }
            },
            "byte": {
                value: g.EXT_0,
                validator: function(t) {
                    return null === t || void 0 === t;
                }
            }
        }, r = i[t];
        if (!r) throw new Error("Invalid WBXML Extension type");
        if (!r.validator(n)) throw new Error("Data for WBXML Extension does not match type");
        if (0 !== e && 1 !== e && 2 !== e) throw new Error("Invalid WBXML Extension index");
        this.subtype = r.value, this.index = e, this.data = n;
    }, l.a = function(t, e) {
        return new l.Attribute(t, e);
    }, l.str_t = function(t) {
        return new l.StringTableRef(t);
    }, l.ent = function(t) {
        return new l.Entity(t);
    }, l.ext = function(t, e, n) {
        return new l.Extension(t, e, n);
    }, l.prototype = {
        _write: function(t) {
            if (this._pos === this._buffer.length - 1) {
                this._rawbuf = new ArrayBuffer(2 * this._rawbuf.byteLength);
                for (var e = new Uint8Array(this._rawbuf), n = 0; n < this._buffer.length; n++) e[n] = this._buffer[n];
                this._buffer = e;
            }
            this._buffer[this._pos++] = t;
        },
        _write_mb_uint32: function(t) {
            var e = [];
            for (e.push(t % 128); t >= 128; ) t >>= 7, e.push(128 + t % 128);
            for (var n = e.length - 1; n >= 0; n--) this._write(e[n]);
        },
        _write_bytes: function(t) {
            for (var e = 0; e < t.length; e++) this._write(t[e]);
        },
        _write_str: function(t) {
            this._write_bytes(this._encoder.encode(t));
        },
        _setCodepage: function(t) {
            this._codepage !== t && (this._write(g.SWITCH_PAGE), this._write(t), this._codepage = t);
        },
        _writeTag: function(t, e, n) {
            if (void 0 === t) throw new Error("unknown tag");
            var i = 0;
            if (e && (i += 64), n.length && (i += 128), t instanceof l.StringTableRef ? (this._write(g.LITERAL + i), 
            this._write_mb_uint32(t.index)) : (this._setCodepage(t >> 8), this._write((255 & t) + i), 
            this._rootTagValue || (this._rootTagValue = t)), n.length) {
                for (var r = 0; r < n.length; r++) {
                    var s = n[r];
                    this._writeAttr(s);
                }
                this._write(g.END);
            }
        },
        _writeAttr: function(t) {
            if (!(t instanceof l.Attribute)) throw new Error("Expected an Attribute object");
            if (t.isValue) throw new Error("Can't use attribute value constants here");
            t.name instanceof l.StringTableRef ? (this._write(g.LITERAL), this._write(t.name.index)) : (this._setCodepage(t.name >> 8), 
            this._write(255 & t.name)), this._writeText(t.value, !0);
        },
        _writeText: function(t, e) {
            if (Array.isArray(t)) for (var n = 0; n < t.length; n++) {
                var i = t[n];
                this._writeText(i, e);
            } else if (t instanceof l.StringTableRef) this._write(g.STR_T), this._write_mb_uint32(t.index); else if (t instanceof l.Entity) this._write(g.ENTITY), 
            this._write_mb_uint32(t.code); else if (t instanceof l.Extension) this._write(t.subtype + t.index), 
            t.subtype === g.EXT_I_0 ? (this._write_str(t.data), this._write(0)) : t.subtype === g.EXT_T_0 && this._write_mb_uint32(t.data); else if (t instanceof l.Attribute) {
                if (!t.isValue) throw new Error("Unexpected Attribute object");
                if (!e) throw new Error("Can't use attribute value constants outside of attributes");
                this._setCodepage(t.name >> 8), this._write(255 & t.name);
            } else null !== t && void 0 !== t && (this._write(g.STR_I), this._write_str(t.toString()), 
            this._write(0));
        },
        tag: function(t) {
            var e = arguments.length > 1 ? arguments[arguments.length - 1] : null;
            if (null === e || e instanceof l.Attribute) {
                var n = Array.prototype.slice.call(arguments, 1);
                return this._writeTag(t, !1, n), this;
            }
            var i = Array.prototype.slice.call(arguments, 0, -1);
            return this.stag.apply(this, i).text(e).etag();
        },
        stag: function(t) {
            var e = Array.prototype.slice.call(arguments, 1);
            return this._writeTag(t, !0, e), this._tagStack.push(t), this;
        },
        etag: function(t) {
            if (0 === this._tagStack.length) throw new Error("Spurious etag() call!");
            var e = this._tagStack.pop();
            if (void 0 !== t && t !== e) throw new Error("Closed the wrong tag");
            return this._write(g.END), this;
        },
        text: function(t) {
            return this._writeText(t), this;
        },
        pi: function(t, e) {
            return this._write(g.PI), this._writeAttr(l.a(t, e)), this._write(g.END), this;
        },
        ext: function(t, e, n) {
            return this.text(l.ext(t, e, n));
        },
        opaque: function(t) {
            if (this._write(g.OPAQUE), t instanceof Blob) {
                if (!this._blobs) throw new Error("Writer not opened in blob mode");
                this._write_mb_uint32(t.size), this._blobs.push(this.bytes), this._blobs.push(t), 
                this._rawbuf = new ArrayBuffer(1024), this._buffer = new Uint8Array(this._rawbuf), 
                this._pos = 0;
            } else if ("string" == typeof t) this._write_mb_uint32(t.length), this._write_str(t); else {
                this._write_mb_uint32(t.length);
                for (var e = 0; e < t.length; e++) this._write(t[e]);
            }
            return this;
        },
        get buffer() {
            return this._rawbuf.slice(0, this._pos);
        },
        get bytes() {
            return new Uint8Array(this._rawbuf, 0, this._pos);
        },
        get blob() {
            if (!this._blobs) throw new Error("No blobs!");
            var t = this._blobs;
            this._pos && (t = t.concat([ this.bytes ]));
            var e = new Blob(t);
            return e;
        },
        get rootTag() {
            return this._rootTagValue;
        }
    }, h.EventParser = c, c.prototype = {
        addEventListener: function(t, e) {
            this.listeners.push({
                path: t,
                callback: e
            });
        },
        _pathMatches: function(t, e) {
            return t.length === e.length && t.every(function(t, n) {
                return "*" === e[n] ? !0 : Array.isArray(e[n]) ? -1 !== e[n].indexOf(t) : t === e[n];
            });
        },
        run: function(t) {
            for (var e, n, i = [], r = [], s = 0, o = t.document, a = o.length, u = this.listeners, f = 0; a > f; f++) {
                var l = o[f];
                if ("TAG" === l.type) {
                    for (i.push(l.tag), e = 0; e < u.length; e++) if (n = u[e], this._pathMatches(i, n.path)) {
                        l.children = [];
                        try {
                            n.callback(l);
                        } catch (c) {
                            this.onerror && this.onerror(c);
                        }
                    }
                    i.pop();
                } else if ("STAG" === l.type) for (i.push(l.tag), e = 0; e < u.length; e++) n = u[e], 
                this._pathMatches(i, n.path) && s++; else if ("ETAG" === l.type) {
                    for (e = 0; e < u.length; e++) if (n = u[e], this._pathMatches(i, n.path)) {
                        s--;
                        try {
                            n.callback(r[r.length - 1]);
                        } catch (c) {
                            this.onerror && this.onerror(c);
                        }
                    }
                    i.pop();
                }
                s && ("STAG" === l.type ? (l.type = "TAG", l.children = [], r.length && r[r.length - 1].children.push(l), 
                r.push(l)) : "ETAG" === l.type ? r.pop() : (l.children = [], r[r.length - 1].children.push(l)));
            }
        }
    }, h;
});