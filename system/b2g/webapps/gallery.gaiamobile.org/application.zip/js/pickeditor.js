'use strict';
var pickEditor = {
  canvas: null,
  zoomBaseBlob: null,
  previousBlob: null,
  blob: null,
  container: null,
  callback: null,
  preview: null,
  cw: 0, // container width
  ch: 0, //container height
  previousZoomTimes: 0,
  zoomTimes: 0,
  cropMode: false,
  progressBar: null,
  config: {
    zoomRatio: 1,
    zoomLeftRatio: 0.5,
    zoomTopRatio: 0.5,
    cropAspect: true,
    previewX: 0,
    previewY: 0,
    previewW: 0,
    previewH: 0,
    cropPreviewW: 0,
    cropPreviewH: 0,
    cropPreviewX: 0,
    cropPreviewY: 0,
    status: '',
    cropType: 0,
    cropLeftRatio: 0.5,
    cropTopRatio: 0.5,
    rotateAngle: 0,
    rotateCenterX: 0,
    rotateCenterY: 0,
    displayDest: {}
  },

  cropCanvas: null,
  metadata: null,

  get rotateRealAngle() {
    return this.config.rotateAngle % 360;
  },

  set rotateRealAngle(value) {
    this.config.rotateAngle = value;
  },

  init: function(blob,container,cw,ch) {
    this.blob = blob;
    this.zoomBaseBlob = this.blob;
    this.previousBlob = this.blob;
    this.container = container;
    this.cw = cw;
    this.ch = ch;
    this.progressBar = document.querySelector('progress#crop-progress');
    this.createImage();
  },

  createImage: function() {
    var canvasNode = document.createElement('canvas');
    canvasNode.width = this.cw;
    canvasNode.height = this.ch;
    canvasNode.id = 'crop-preview-canvas'; // for stylesheet
    canvasNode.setAttribute('role', 'img');
    this.container.appendChild(canvasNode);
    this.cropCanvas = document.createElement('canvas');
    this.cropCanvas.classList.add('hidden');
    this.cropCanvas.width = this.cw;
    this.cropCanvas.height = this.ch;
    this.cropCanvas.id = 'crop-border-canvas';
    this.container.appendChild(this.cropCanvas);
    this.canvas = $("crop-preview-canvas");
    var _self = this;
    var maxsize = CONFIG_MAX_EDIT_PIXEL_SIZE || CONFIG_MAX_IMAGE_PIXEL_SIZE;
    LazyLoader.load(['shared/js/media/image_size.js', 'shared/js/blobview.js', 'shared/js/media/jpeg_metadata_parser.js'], function() {
      getImageSize(_self.blob, function success(metadata) {
        var imagesize = metadata.width * metadata.height;
        _self.metadata = metadata;
        if (imagesize > maxsize) {
          cropResizeRotate(_self.blob, null, CONFIG_MAX_IMAGE_PIXEL_SIZE || null, null, null, function(error, rotatedBlob) {
            Spinner.hide();
            if (error) {
              console.error('Error while rotating image:', error);
              rotatedBlob = file;
            }
            _self.drawPick(null, null, rotatedBlob);
          });
        } else {
          _self.drawPick();
        }
      }, function error() {
        _self.drawPick();
      });
      _self.addListener();
    });
  },

  addListener: function() {
    window.addEventListener('keyup',this);
  },
  removeListener: function() {
    window.removeEventListener('keyup',this);
  },
  resetCropRatio: function() {
    this.config.cropLeftRatio = 0.5;
    this.config.cropTopRatio = 0.5;
  },

  drawPick: function(data,callback, blob) {
    var self = this;
    self.config.zoomRatio = 1; //zoom ratio
    var url = URL.createObjectURL(blob || this.blob);
    if (lowMemory) {
      let scale = (window.innerWidth * window.devicePixelRatio
        * window.innerHeight * window.devicePixelRatio) /
        (self.metadata.width * self.metadata.height);
      let sampleSize = Downsample.areaNoMoreThan(scale);
      url = url + sampleSize;
    }
    var ctx=this.canvas.getContext("2d",{ willReadFrequently: true });
    if(data && data.clearRect) {
      ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
      ctx.fillStyle = '#1f1f1f';
      ctx.fillRect(0,0,this.cw,this.ch);
    }
    this.preview = new Image();
    this.preview.src = url;
    this.preview.onload = function() {
      var previewWidth = self.preview.width;
      var previewHeight = self.preview.height;
      // calculate the preview's zoom ratio
      if(previewWidth > self.cw || previewHeight > self.ch) {
        self.config.zoomRatio = self.cw/previewWidth < self.ch/previewHeight?self.cw/previewWidth:self.ch/previewHeight;
      }
      // calculate the preview's position and width/height
      var displayWidth = previewWidth * self.config.zoomRatio;
      var displayHeight = previewHeight * self.config.zoomRatio;
      var displayX = (self.cw - displayWidth)/2;
      var displayY = (self.ch - displayHeight)/2;
      //rotate
      if(data && data.action === 'rotate') {
        self.config.rotateAngle += data.angle;
        ctx.translate(displayX+displayWidth/2,displayY+displayHeight/2);
        ctx.rotate(data.angle*Math.PI/180);
        ctx.translate(-displayX-displayWidth/2,-displayY-displayHeight/2);
        self.config.rotateCenterX = displayX+displayWidth/2;
        self.config.rotateCenterY = displayY+displayHeight/2;
      }
      self.config.previewX = self.config.previewY = 0;
      self.config.previewW = previewWidth;
      self.config.previewH = previewHeight;
      self.config.displayDest = {
        x: self.cw/2 - displayWidth/2,
        y: self.ch/2 - displayHeight/2
      };
      if(!(data && data.action === 'crop' && !data.clearRect)){
        ctx.drawImage(self.preview,0,0,previewWidth,previewHeight,displayX,displayY,displayWidth,displayHeight);
      }
      //crop
      if(data && data.action === 'crop') {
        self.cropMode = true;
        self.config.cropType = data.type;
        self.drawCropBorder(ctx,displayX,displayY,displayWidth,displayHeight);
      }
      if(callback)
        callback();
    };
  },

  updateCropControls: function(x,y,w,h) {
    var nx , ny , nw , nh ;
    nx = ny = nw = nh = 0;
    [nx,ny,nw,nh] = [x,y,w,h];
    this.config.previewX = 0;
    this.config.previewY = 0;
    this.config.cropPreviewX = 0;
    this.config.cropPreviewY = 0;
    switch(this.config.cropType) {
      case 0:
        this.config.cropAspect = true;
        return [x,y,w,h];
        break;
      case 1: //2:3
        this.config.cropAspect = false;
        if(h/3 > w/2) {
          h = 3*w/2;
          y = (nh-h)*this.config.cropTopRatio + y;
          this.config.previewY = (nh-h)*this.config.cropTopRatio;
          this.config.cropPreviewY = this.config.previewY;
        }else {
          w = 2*h/3;
          x = (nw - w)*this.config.cropLeftRatio + x;
          this.config.previewX = (nw - w)*this.config.cropLeftRatio;
          this.config.cropPreviewX = this.config.previewX;
        }
        return [x,y,w,h];
        break;
      case 2: //3:2
        this.config.cropAspect = false;
        if(h/2 > w/3) {
          h = 2*w/3;
          y = (nh-h)*this.config.cropTopRatio + y;
          this.config.previewY = (nh-h)*this.config.cropTopRatio;
          this.config.cropPreviewY = this.config.previewY;
        }else {
          w = 3*h/2;
          x = (nw - w)*this.config.cropLeftRatio + x;
          this.config.previewX = (nw - w)*this.config.cropLeftRatio;
          this.config.cropPreviewX = this.config.previewX;
        }
        return [x,y,w,h];
        break;
      case 3: //1:1
        this.config.cropAspect = false;
        if(h > w) {
          h = w;
          y = (nh-h)*this.config.cropTopRatio + y;
          this.config.previewY = (nh-h)*this.config.cropTopRatio;
          this.config.cropPreviewX = 0;
          this.config.cropPreviewY = this.config.previewY;
        }else {
          w = h;
          x = (nw - w)*this.config.cropLeftRatio + x;
          this.config.previewX = (nw - w)*this.config.cropLeftRatio;
          this.config.cropPreviewY = 0;
          this.config.cropPreviewX = this.config.previewX;
        }
        return [x,y,w,h];
        break;
    }
  },

  drawCropBorder: function(ctx,x,y,w,h) {
    // create a cover canvas
    this.cropCanvas.classList.remove('hidden');
    var cropCtx = this.cropCanvas.getContext('2d',{ willReadFrequently: true });
    [x,y,w,h] = this.updateCropControls(x,y,w,h);
    this.config.cropPreviewW = w;
    this.config.cropPreviewH = h;
    cropCtx.clearRect(0,0,this.cw,this.ch);
    cropCtx.fillStyle="#000";
    cropCtx.globalAlpha=0.4;
    cropCtx.fillRect(0,0,this.cw,this.ch);
    cropCtx.clearRect(x,y,w,h);
    cropCtx.globalAlpha=1;
    cropCtx.strokeStyle = 'rgba(255,255,255,.75)';
    cropCtx.lineWidth = 1;
    cropCtx.strokeRect(x, y, w+1, h+1);
    var centerX = x+w/2;
    var centerY = y+h/2;

    cropCtx.lineWidth = 4;
    cropCtx.beginPath();
    // top
    cropCtx.moveTo(centerX - 23, y - 1);
    cropCtx.lineTo(centerX + 23, y - 1);
    //right
    cropCtx.moveTo(x+w + 1, centerY - 23);
    cropCtx.lineTo(x+w + 1, centerY + 23);
    //bottom
    cropCtx.moveTo(centerX - 23, y+h + 1);
    cropCtx.lineTo(centerX + 23, y+h + 1);
    //left
    cropCtx.moveTo(x - 1, centerY - 23);
    cropCtx.lineTo(x - 1, centerY + 23);
    // draw corner borders
    if(this.config.cropAspect) {
      //right top
      cropCtx.moveTo(x+w - 23, y - 1);
      cropCtx.lineTo(x+w + 1, y - 1);
      cropCtx.lineTo(x+w + 1, y + 23);
      // right bottom
      cropCtx.moveTo(x+w + 1, y+h - 23);
      cropCtx.lineTo(x+w + 1, y+h + 1);
      cropCtx.lineTo(x+w - 23, y+h + 1);
      // left bottom
      cropCtx.moveTo(x + 23, y+h + 1);
      cropCtx.lineTo(x - 1, y+h + 1);
      cropCtx.lineTo(x - 1, y+h - 23);
      // left top
     cropCtx.moveTo(x - 1, y + 23);
     cropCtx.lineTo(x - 1, y - 1);
     cropCtx.lineTo(x + 23, y - 1);
    }
    cropCtx.stroke();
  },
  enterCrop: function() {
    pickEditor.config.status = 'moveCrop';
    this.crop(0,true);
  },
  zoomIn: function() { //reset blob
    if(this.zoomTimes<9) {
      this.zoomTimes ++ ;
      this.zoomCanvas();
    }
    Pick.updateUI();
  },
  zoomOut: function() {
    if(this.zoomTimes>0) {
      this.zoomTimes --;
      this.zoomCanvas();
    }
    Pick.updateUI();
  },
  // back from zoom view
  zoomBack: function() {
    this.zoomTimes = this.previousZoomTimes;
    this.drawPick();
  },
  zoomDone: function() {
    var self = this;
    this.updateBlob('zoom',function() {
    });
  },
  rotate: function(isClockWise) {
    var self = this;
    this.drawPick({
      action: 'rotate',
      clearRect: true,
      angle: isClockWise?90:-90
    });
  },
  rotateBack: function() {
    var centerX,centerY;
    var ctx=this.canvas.getContext("2d",{ willReadFrequently: true });
    if([-90,-270,90,270].contains(this.rotateRealAngle)) {
      ctx.translate(this.config.rotateCenterX,this.config.rotateCenterY);
      ctx.rotate(-this.rotateRealAngle*Math.PI/180);
      ctx.translate(-this.config.rotateCenterX,-this.config.rotateCenterY);
    }else {
      ctx.translate(this.config.rotateCenterX,this.config.rotateCenterY);
      ctx.rotate(-this.rotateRealAngle*Math.PI/180);
      ctx.translate(-this.config.rotateCenterX,-this.config.rotateCenterY);
    }

    this.rotateRealAngle = 0;
    this.drawPick({
      clearRect: true
    });
  },
  rotateDone: function() {
    var self = this;
    this.updateBlob('rotate',function() {
      self.zoomBaseBlob = self.blob;
      self.zoomBaseBlob = self.blob;
      self.zoomTimes = self.previousZoomTimes = 0;
      self.rotateBack();
    });
  },
  handleEvent: function(dir) {
    switch(dir) {
      case 0://ArrowLeft
      if(Gallery.subView.startsWith(CROP_SUBVIEW.zoom)) {
        if(pickEditor.config.zoomLeftRatio>=0.05)
          pickEditor.config.zoomLeftRatio -= 0.05;
        else
          pickEditor.config.zoomLeftRatio = 0;
        pickEditor.zoomCanvas();
      }else if (CROP_SUBVIEW.cropRect === Gallery.subView) {
        if(pickEditor.config.cropLeftRatio >= 0.05)
          pickEditor.config.cropLeftRatio -= 0.05;
        else
          pickEditor.config.cropLeftRatio = 0;
         pickEditor.crop(pickEditor.config.cropType,false);
      }
      break;
      case 1://ArrowRight
      if(Gallery.subView.startsWith(CROP_SUBVIEW.zoom)) {
        if(pickEditor.config.zoomLeftRatio<=0.95)
          pickEditor.config.zoomLeftRatio += 0.05;
        else
          pickEditor.config.zoomLeftRatio = 1;
        pickEditor.zoomCanvas();
      }else if (CROP_SUBVIEW.cropRect === Gallery.subView) {
        if(pickEditor.config.cropLeftRatio<=0.95)
          pickEditor.config.cropLeftRatio += 0.05;
        else
          pickEditor.config.cropLeftRatio = 1;
        pickEditor.crop(pickEditor.config.cropType,false);
      }
        break;
      case 2://ArrowUp
      if(Gallery.subView.startsWith(CROP_SUBVIEW.zoom)) {
        if(pickEditor.config.zoomTopRatio>=0.05)
          pickEditor.config.zoomTopRatio -= 0.05;
        else
          pickEditor.config.zoomTopRatio = 0;
        pickEditor.zoomCanvas();
      }else if (CROP_SUBVIEW.cropRect === Gallery.subView) {
        if(pickEditor.config.cropTopRatio>=0.05)
          pickEditor.config.cropTopRatio -= 0.05;
        else
          pickEditor.config.cropTopRatio = 0;
        pickEditor.crop(pickEditor.config.cropType,false);
      }
        break;
      case 3://ArrowDown
      if(Gallery.subView.startsWith(CROP_SUBVIEW.zoom)) {
        if(pickEditor.config.zoomTopRatio<=0.95)
          pickEditor.config.zoomTopRatio += 0.05;
        else
          pickEditor.config.zoomTopRatio = 1;
        pickEditor.zoomCanvas();
      }else if (CROP_SUBVIEW.cropRect === Gallery.subView) {
        if(pickEditor.config.cropTopRatio<=0.95)
          pickEditor.config.cropTopRatio += 0.05;
        else
          pickEditor.config.cropTopRatio = 1;
        pickEditor.crop(pickEditor.config.cropType,false);
      }
      break;
    }
  },
  //reset blob
  zoomCanvas: function(data) {
    var self = this;
    var zoomRatio = 1; //zoom ratio
    var canvas=$("crop-preview-canvas");
    var ctx=canvas.getContext("2d",{ willReadFrequently: true });
    var url = URL.createObjectURL(this.zoomBaseBlob);
    this.preview = new Image();
    this.preview.src = url;
    this.preview.onload = function() {
      var previewWidth = self.preview.width;
      var previewHeight =  self.preview.height;
      // calculate the preview's zoom ratio
      if(previewWidth > self.cw || previewHeight > self.ch) {
        zoomRatio = self.cw/previewWidth < self.ch/previewHeight?self.cw/previewWidth:self.ch/previewHeight;
      }
      // calculate the preview's position and width/height
      var displayWidth = previewWidth * zoomRatio;
      var displayHeight = previewHeight * zoomRatio;
      var displayX = (self.cw - displayWidth)/2;
      var displayY = (self.ch - displayHeight)/2;
      if(self.zoomTimes>0) {
        var cropW = previewWidth * (1- (self.zoomTimes+1)/16);
        var cropH = previewHeight * (1- (self.zoomTimes+1)/16);
      }else{
        var cropW = previewWidth ;
        var cropH = previewHeight ;
      }
      var cropX = (previewWidth - cropW)*self.config.zoomLeftRatio;
      var cropY = (previewHeight - cropH)*self.config.zoomTopRatio;
      self.config.previewX = cropX;
      self.config.previewY = cropY;
      self.config.previewW = cropW;
      self.config.previewH = cropH;
      self.config.displayDest = {
        x: self.cw/2 - displayWidth/2,
        y: self.ch/2 - displayHeight/2
      };
      ctx.drawImage(self.preview,cropX,cropY,cropW,cropH,displayX,displayY,displayWidth,displayHeight);
    };
  },
  cropDone: function() {
    var self = this;
    if(self.cropMode)
    self.updateBlob('crop',function(){
      self.clearCropCanvas();
      self.zoomBaseBlob = self.blob;
      self.zoomTimes = self.previousZoomTimes = 0;
      self.drawPick({
        clearRect: true
      });
    });
  },
  // reset the image blob
  updateBlob: function(action,callback) {
    var self = this;
    if(action === 'zoom')
      var url = URL.createObjectURL(this.zoomBaseBlob);
    else
      var url = URL.createObjectURL(this.blob);
    var progressCoefficient = 8;
    this.progressBar.value = 0;
    this.preview = new Image();
    this.preview.src = url;
    NavigationMap.inProgress = true;
    SoftkeyManager.softkey.hide();
    this.preview.onload = function() {
      var updateCanvas = document.createElement('canvas');
      var updateCtx = updateCanvas.getContext("2d",{ willReadFrequently: true });
      if(action === 'zoom') {
        updateCanvas.width = self.preview.width;
        updateCanvas.height = self.preview.height;
      }else if(action === 'rotate') {
        progressCoefficient = 6;
        if([-90,-270,90,270].contains(self.rotateRealAngle)) {
          updateCanvas.width = self.preview.height;
          updateCanvas.height = self.preview.width;
          updateCtx.translate(updateCanvas.width/2,updateCanvas.height/2);
          updateCtx.rotate(self.config.rotateAngle*Math.PI/180);
          updateCtx.translate(-updateCanvas.height/2,-updateCanvas.width/2);
        }else{
          updateCanvas.width = self.preview.width;
          updateCanvas.height = self.preview.height;
          updateCtx.translate(updateCanvas.width/2,updateCanvas.height/2);
          updateCtx.rotate(self.config.rotateAngle*Math.PI/180);
          updateCtx.translate(-updateCanvas.width/2,-updateCanvas.height/2);
        }

      }else { // crop
        progressCoefficient = 15;
        var displayW = self.config.previewW*self.config.zoomRatio;
        var displayH = self.config.previewH*self.config.zoomRatio;
        var cutPreviewX = parseInt(self.config.cropPreviewX / self.config.zoomRatio);
        var cutPreviewY = parseInt(self.config.cropPreviewY / self.config.zoomRatio);
        var cutPreviewW = parseInt(self.preview.width*self.config.cropPreviewW/displayW);
        var cutPreviewH = parseInt(self.preview.height*self.config.cropPreviewH/displayH);

        updateCanvas.width = cutPreviewW;
        updateCanvas.height = cutPreviewH;
      }
      var drawBeginTime = self.getMicroTime();
      if(action === 'rotate' && [-90,-270,90,270].contains(self.rotateRealAngle))
        updateCtx.drawImage(self.preview,0,0,self.preview.width,self.preview.height,0,0,self.preview.width,self.preview.height);
        else
          if(action === 'crop') {
            updateCtx.drawImage(self.preview,cutPreviewX,cutPreviewY,cutPreviewW,cutPreviewH,0,0,cutPreviewW,cutPreviewH);
          }
          else
            updateCtx.drawImage(self.preview,self.config.previewX,self.config.previewY,self.config.previewW,self.config.previewH,0,0,updateCanvas.width,updateCanvas.height);
      var drawTime = self.getMicroTime() - drawBeginTime;
      self.progressBar.classList.remove('hidden');
      self.progressEmulator(drawTime*1000*progressCoefficient);
      updateCanvas.toBlob(function(blob) {
        self.progressBar.value = 100;
        setTimeout(function(){self.progressBar.classList.add('hidden');},100);
        NavigationMap.inProgress = false;
        SoftkeyManager.softkey.show();
        self.blob = blob;
        if(callback)
          callback();
      });
    };
  },
  progressEmulator: function(totalTime) {
    var self = this;
    if(self.progressBar.value < 95) {
      var deltaValue = parseFloat( 100 / (totalTime / 10));
      self.progressBar.value += deltaValue;
      setTimeout(function(){
        self.progressEmulator(totalTime);
      },10);
    }
  },
  getMicroTime: function() {
    var d = new Date();
    return d.valueOf()/1000;
  },
  // draw crop selector
  cropSelector: function(ctx,x,y,w,h) {
    ctx.strokeStyle = 'rgba(255,0,0,1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x,y);
    ctx.lineTo(x+w,y);
    ctx.lineTo(x+w+1,y+h);
    ctx.lineTo(x,y+h);
    ctx.lineTo(x,y);
    ctx.stroke();
  },
  clearCropCanvas: function() {
    var cropCtx = this.cropCanvas.getContext("2d",{ willReadFrequently: true });
    cropCtx.clearRect(0,0,this.cw,this.ch);
    this.cropMode = false;
  },
  destroy: function() {
    this.container.removeChild(this.canvas);
    this.container.removeChild(this.cropCanvas);
    this.canvas = this.cropCanvas = null;
    this.previousZoomTimes = 0;
    this.zoomTimes = 0;
  },

  crop: function(type,clearRect) {
    this.drawPick({
      action: 'crop',
      type: type,
      clearRect: clearRect
    });
  },
};
