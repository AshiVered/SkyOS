/**
 * Created by gaoguang on 9/7/16.
 */

'use strict';
$('menuItem-LCDTest').addEventListener('click', function() {
  lcd_test.init();
});


var lcd_test = {
  init:function _init(){
    _self = this;

    $('menuItem-lcdblack').addEventListener('click', function(){
      
    });
  },

};