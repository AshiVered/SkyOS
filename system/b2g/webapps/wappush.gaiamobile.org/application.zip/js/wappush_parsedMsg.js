
(function(exports){'use strict';function ParsedMessage(obj){if(obj){for(let key in obj){this[key]=obj[key];}}}
ParsedMessage.prototype.constructor=ParsedMessage;ParsedMessage.prototype.fromMessage=function(message){let obj=new ParsedMessage();obj.provisioningDoc=message.content;obj.authInfo=message.authInfo;return obj;};ParsedMessage.prototype.toJSON=function(){let obj={type:this.type,sender:this.sender,serviceId:this.serviceId,timestamp:this.timestamp};if(this.href){obj.href=this.href;}
if(this.id){obj.id=this.id;}
if(this.created){obj.created=this.created;}
if(this.expires){obj.expires=this.expires;}
if(this.text){obj.text=this.text;}
if(this.action){obj.action=this.action;}
if(this.provisioning){obj.provisioning=this.provisioning;}
return obj;};ParsedMessage.prototype.save=function(){let json_message=this.toJSON();return DataBase.put(json_message).then((status)=>{if(status==='updated'){this.timestamp=json_message.timestamp;}
return Promise.resolve(status);},this);};ParsedMessage.prototype.isExpired=function(){return(this.expires&&(this.expires<Date.now()));};ParsedMessage.prototype.from=function(message,timestamp){let parser=new DOMParser();let doc=parser.parseFromString(message.content,'text/xml');let obj=new ParsedMessage();obj.type=message.contentType;obj.sender=message.sender;obj.serviceId=message.serviceId;obj.timestamp=timestamp.toString();switch(message.contentType){case Constants.SI:let indicationNode=doc.querySelector('indication');if(indicationNode.hasAttribute('href')){obj.href=indicationNode.getAttribute('href');}
obj.text=indicationNode.textContent;if(indicationNode.hasAttribute('si-id')){obj.id=indicationNode.getAttribute('si-id');}else if(obj.href){obj.id=obj.href;}
if(indicationNode.hasAttribute('created')){let date=new Date(indicationNode.getAttribute('created'));obj.created=date.getTime();}
if(indicationNode.hasAttribute('si-expires')){let expiresDate=new Date(indicationNode.getAttribute('si-expires'));obj.expires=expiresDate.getTime();}
if(indicationNode.hasAttribute('action')){obj.action=indicationNode.getAttribute('action');}else{obj.action='signal-medium';}
if(obj.action==='delete'&&!obj.id){return null;}
break;case Constants.SL:let slNode=doc.querySelector('sl');obj.href=slNode.getAttribute('href');if(slNode.hasAttribute('action')){obj.action=slNode.getAttribute('action');}else{obj.action='execute-low';}
break;case Constants.OMA:obj.provisioning=this.fromMessage(message);if(!obj.provisioning.authInfo){return null;}
let authInfo=obj.provisioning.authInfo;if(authInfo.checked&&!authInfo.pass){return null;}
obj.text='cp-message-received';break;default:obj=null;break;}
return obj;};ParsedMessage.prototype.load=function(timestamp){return DataBase.retrieve(timestamp).then(function(message){return message?new ParsedMessage(message):null;});};exports.ParsedMessage=new ParsedMessage();})(window);