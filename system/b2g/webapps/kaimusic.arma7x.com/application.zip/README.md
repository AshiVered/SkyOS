# K-Music

## An audio player for KaiOS with playlist manager

## Licence

[MIT](https://opensource.org/licenses/MIT)

