define([ "../imapchew", "../../allback", "exports" ], function(e, t, n) {
    function r(e) {
        this.storage = e.storage, this.connection = e.connection, this.knownHeaders = e.knownHeaders || [], 
        this.knownUIDs = e.knownUIDs || [], this.newUIDs = e.newUIDs || [], this._progress = e.initialProgress || .25, 
        this._progressCost = (this.knownUIDs.length ? s : 0) + a * this.knownUIDs.length + (this.newUIDs.length ? c : 0) + u * this.newUIDs.length, 
        this.onprogress = null, this.oncomplete = null, this._beginSync();
    }
    var o = [ "BODYSTRUCTURE", "INTERNALDATE", "FLAGS", "BODY.PEEK[HEADER.FIELDS (FROM TO CC BCC SUBJECT REPLY-TO MESSAGE-ID REFERENCES)]" ], i = [ "FLAGS" ], s = 20, a = 1, c = 20, u = 5;
    r.prototype = {
        _updateProgress: function(e) {
            this._progress += e, this.onprogress && this.onprogress(.25 + .75 * (this._progress / this._progressCost));
        },
        _beginSync: function() {
            var e = t.latch();
            this.newUIDs.length && this._handleNewUids(e.defer("new")), this.knownUIDs.length && this._handleKnownUids(e.defer("known")), 
            e.then(function() {
                this.oncomplete && this.oncomplete(this.newUIDs.length, this.knownUIDs.length);
            }.bind(this));
        },
        _handleNewUids: function(n) {
            var r = [], i = this;
            this.connection.listMessages(this.newUIDs, o, {
                byUid: !0
            }, function(o, s) {
                if (o) return console.warn("New UIDs fetch error, ideally harmless:", o), n(), void 0;
                var a = t.latch();
                s.forEach(function(t) {
                    var n = t.flags.indexOf("\\Recent");
                    -1 !== n && t.flags.splice(n, 1);
                    try {
                        var o = e.chewHeaderAndBodyStructure(t, i.storage.folderId, i.storage._issueNewHeaderId());
                        o.header.bytesToDownloadForBodyDisplay = e.calculateBytesToDownloadForImapBodyDisplay(o.bodyInfo), 
                        r.push(o), i.storage.addMessageHeader(o.header, o.bodyInfo, a.defer()), i.storage.addMessageBody(o.header, o.bodyInfo, a.defer());
                    } catch (s) {
                        console.warn("message problem, skipping message", s, "\n", s.stack);
                    }
                }.bind(this)), a.then(n);
            }.bind(this));
        },
        _handleKnownUids: function(e) {
            var n = this;
            this.connection.listMessages(n.knownUIDs, i, {
                byUid: !0
            }, function(r, o) {
                if (r) return console.warn("Known UIDs fetch error, ideally harmless:", r), e(), 
                void 0;
                var i = t.latch();
                o.forEach(function(e, t) {
                    console.log("FETCHED", t, "known id", n.knownHeaders[t].id, "known srvid", n.knownHeaders[t].srvid, "actual id", e.uid);
                    var r = e.flags.indexOf("\\Recent");
                    if (-1 !== r && e.flags.splice(r, 1), n.knownHeaders[t].srvid !== e.uid && (t = n.knownUIDs.indexOf(e.uid), 
                    -1 === t)) return console.warn("Server fetch reports unexpected message:", e.uid), 
                    void 0;
                    var o = n.knownHeaders[t], s = o.flags.slice();
                    s.sort(), e.flags.sort(), -1 === o.flags.indexOf("\\Seen") && -1 !== e.flags.indexOf("\\Seen") ? n.storage.folderMeta.unreadCount-- : -1 !== o.flags.indexOf("\\Seen") && -1 === e.flags.indexOf("\\Seen") && n.storage.folderMeta.unreadCount++, 
                    o.flags.toString() !== e.flags.toString() ? (console.warn('  FLAGS: "' + o.flags.toString() + '" VS "' + e.flags.toString() + '"'), 
                    o.flags = e.flags, n.storage.updateMessageHeader(o.date, o.id, !0, o, null, i.defer())) : n.storage.unchangedMessageHeader(o);
                }), n._updateProgress(s + a * n.knownUIDs.length), i.then(e);
            }.bind(this));
        }
    }, n.Sync = r;
});