(function(e, t) {
    "object" == typeof exports && (define = function(e, t) {
        e = e.map.forEach(function(e) {
            return require(e);
        }), module.exports = t(e);
    }, define.amd = {}), "function" == typeof define && define.amd ? define([ "wbxml", "./codepages/Common", "./codepages/AirSync", "./codepages/Contacts", "./codepages/Email", "./codepages/Calendar", "./codepages/Move", "./codepages/ItemEstimate", "./codepages/FolderHierarchy", "./codepages/MeetingResponse", "./codepages/Tasks", "./codepages/ResolveRecipients", "./codepages/ValidateCert", "./codepages/Contacts2", "./codepages/Ping", "./codepages/Provision", "./codepages/Search", "./codepages/GAL", "./codepages/AirSyncBase", "./codepages/Settings", "./codepages/DocumentLibrary", "./codepages/ItemOperations", "./codepages/ComposeMail", "./codepages/Email2", "./codepages/Notes", "./codepages/RightsManagement" ], t) : e.ActiveSyncCodepages = t(WBXML, ASCPCommon, ASCPAirSync, ASCPContacts, ASCPEmail, ASCPCalendar, ASCPMove, ASCPItemEstimate, ASCPHierarchy, ASCPMeetingResponse, ASCPTasks, ASCPResolveRecipients, ASCPValidateCert, ASCPContacts2, ASCPPing, ASCPProvision, ASCPSearch, ASCPGAL, ASCPAirSyncBase, ASCPSettings, ASCPDocumentLibrary, ASCPItemOperations, ASCPComposeMail, ASCPEmail2, ASCPNotes, ASCPRightsManagement);
})(this, function(e, t, n, r, i, o, s, a, u, c, l, d, f, h, m, p, g, v, y, _, w, b, S, A, T, C) {
    var E = {
        Common: t,
        AirSync: n,
        Contacts: r,
        Email: i,
        Calendar: o,
        Move: s,
        ItemEstimate: a,
        FolderHierarchy: u,
        MeetingResponse: c,
        Tasks: l,
        ResolveRecipients: d,
        ValidateCert: f,
        Contacts2: h,
        Ping: m,
        Provision: p,
        Search: g,
        GAL: v,
        AirSyncBase: y,
        Settings: _,
        DocumentLibrary: w,
        ItemOperations: b,
        ComposeMail: S,
        Email2: A,
        Notes: T,
        RightsManagement: C
    };
    return e.CompileCodepages(E), E;
});