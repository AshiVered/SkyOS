
/* global SettingsListener */
define('panels/screen_lock_passcode/screen_lock_passcode',['require','modules/settings_service','modules/settings_utils'],function (require) {
  

  var SettingsService = require('modules/settings_service');
  var SettingsUtils = require('modules/settings_utils');
  var _self = null;

  var ScreenLockPasscode = function ctor_screenlock_passcode() {
    return {
      _panel: null,

      /**
       * create  : when the user turns on passcode settings
       * edit    : when the user presses edit passcode button
       * confirm : when the user turns off passcode settings
       * new     : when the user is editing passcode
       *                and has entered old passcode successfully
       */
      _MODE: 'create',

      _settings: {
        passcode: '0000'
      },

      _checkingLength: {
        'create': 8,
        'new': 8,
        'edit': 4,
        'confirm': 4,
        'confirmLock': 4
      },

      _leftApp: false,

      _passcodeBuffer: '',

      _errorMsgTimeoutId: null,

      _getAllElements: function sld_getAllElements() {
        this.passcodePanel = this._panel;
        this.header = this._panel.querySelector('gaia-header');
        this.passcodeDigits = this._panel.querySelectorAll('.passcode-digit');
        this.passcodeContainer =
          this._panel.querySelector('.passcode-container');
        this.passcodeError =
          this._panel.querySelector('.passcode-error');
        this.posscodeInput = document.getElementById('passcode-pseudo-input');
        this.posscodeConfirmInput = document.getElementById('passcode-pseudo-confirm-input');

        // Add support to RTL
        if(window.document.dir === 'rtl') {
          var temp_passcodeDigits = this.passcodeDigits;
          this.passcodeDigits = new Array();

          var backward = 4;
          for (var i = 0; i < 8; i++) {
            backward--;
            this.passcodeDigits[i] = temp_passcodeDigits[backward];

            if(backward === 0) {
              backward += 8;
            }
          }
        }
      },

      init: function sld_onInit() {
        this._getAllElements();
        // If the pseudo-input loses focus, then allow the user to restore focus
        // by touching the container around the pseudo-input.
        this.passcodeContainer.addEventListener('click', function(evt) {
          this.passcodeContainer.focus();
          evt.preventDefault();
        }.bind(this));

        this._fetchSettings();
      },

      onInit: function sld_onInit(panel) {
        this._panel = panel;
        this.init();
      },

      onBeforeShow: function sld_onBeforeShow(panel, mode) {
        if (!this._leftApp) {
          this._showDialogInMode(mode);
        }
        this._leftApp = false;
        this._setupSKs();
      },

      onBeforeHide: function sld_onBeforeHide() {
      },

      onShow: function sld_onShow() {
        _self = this;
        document.addEventListener('keydown', this.handleEvent);
        this.passcodeContainer.focus();
        this._updatePassCodeUI();
      },

      onHide: function sld_onBeforeHide() {
        this._leftApp = document.hidden;

        if (!this._leftApp) {
          this._passcodeBuffer = '';
          this._updatePassCodeUI();
        }
        document.removeEventListener('keydown', this.handleEvent);
        if (this._errorMsgTimeoutId !== null)
          window.clearTimeout(this._errorMsgTimeoutId);
      },

      _showDialogInMode: function sld_showDialogInMode(mode) {
        this._hideErrorMessage();
        this._MODE = mode;
        this.passcodePanel.dataset.mode = mode;
        this._updatePassCodeUI();
        SettingsUtils.runHeaderFontFit(this.header);
      },

      handleEvent: function sld_handleEvent(evt) {
        // key code for key strokes from the keypad are 0 (numbers) and 8
        // (backspace). Filter out the events that are not from the keypad.
        var keyCode = _translateKey(evt.key);
        if (!(keyCode >= '0' && keyCode <= '9') && keyCode != 'Backspace') {
          return;
        }

        if (_self.passcodePanel.dataset.passcodeStatus === 'success' &&
          keyCode >= '0' && keyCode <= '9') {
          return;
        }

        evt.preventDefault();
        if (_self._passcodeBuffer === '' ||
          _self._passcodeBuffer.length === 8) {
          _self._hideErrorMessage();
        }

        if (evt.key === 'BrowserBack' || evt.key == 'Backspace') {
          if (_self._passcodeBuffer.length > 0) {
            _self._passcodeBuffer = _self._passcodeBuffer.substring(0,
              _self._passcodeBuffer.length - 1);
            if (_self.passcodePanel.dataset.passcodeStatus === 'success') {
              _self._resetPasscodeStatus();
            }
            _self._setupSKs();
            _self._updatePassCodeUI();
            evt.stopPropagation();
          }
        } else if (_self._passcodeBuffer.length < 8) {
          _self._passcodeBuffer += keyCode;
          _self._updatePassCodeUI();
          _self._enablePasscode();
        } else if (_self._passcodeBuffer.length === 8) {
          _self._passcodeBuffer = keyCode;
          _self._updatePassCodeUI();
          _self._setupSKs();
        }
      },

      _enablePasscode: function sld_enablePasscode() {
        var settings;
        var passcode;
        var lock;

        if (this._passcodeBuffer.length === this._checkingLength[this._MODE]) {
          switch (this._MODE) {
            case 'create':
            case 'new':
              passcode = this._passcodeBuffer.substring(0, 4);
              var passcodeToConfirm = this._passcodeBuffer.substring(4, 8);
              if (passcode != passcodeToConfirm) {
                this._showErrorMessage();
              } else {
                this._setupSKs();
                this._enableButton();
              }
              break;
            case 'confirm':
              if (this._checkPasscode()) {
                settings = navigator.mozSettings;
                lock = settings.createLock();
                lock.set({
                  'lockscreen.enabled': false,
                  'lockscreen.passcode-lock.enabled': false
                });
                this._backToScreenLock();
                showToast('screen-lock-off');
              } else {
                this._passcodeBuffer = '';
              }
              break;
            case 'confirmLock':
              if (this._checkPasscode()) {
                settings = navigator.mozSettings;
                lock = settings.createLock();
                lock.set({
                  'lockscreen.enabled': false,
                  'lockscreen.passcode-lock.enabled': false
                });
                this._backToScreenLock();
              } else {
                this._passcodeBuffer = '';
              }
              break;
            case 'edit':
              if (this._checkPasscode()) {
                this._passcodeBuffer = '';
                this._updatePassCodeUI();
                this._showDialogInMode('new');
              } else {
                this._passcodeBuffer = '';
              }
              break;
          }
        }
      },

      _fetchSettings: function sld_fetchSettings() {
        SettingsListener.observe('lockscreen.passcode-lock.code', '0000',
          function(passcode) {
            this._settings.passcode = passcode;
          }.bind(this));
      },

      _showErrorMessage: function sld_showErrorMessage(autoClear) {
        this.passcodePanel.dataset.passcodeStatus = 'error';
        this.passcodeError.setAttribute('aria-live', 'assertive');
        this.passcodeError.textContent = this.passcodeError.textContent;

        if (this._errorMsgTimeoutId !== null)
          window.clearTimeout(this._errorMsgTimeoutId);
        if (autoClear) {
          this._errorMsgTimeoutId = window.setTimeout(function() {
            this._hideErrorMessage();
            this._updatePassCodeUI();
            this.posscodeConfirmInput.classList.remove('highlight');
          }.bind(this), 2000);
        }
      },

      _hideErrorMessage: function sld_hideErrorMessage() {
        this.passcodePanel.dataset.passcodeStatus = '';
      },

      _resetPasscodeStatus: function sld_resetPasscodeStatus() {
        this.passcodePanel.dataset.passcodeStatus = '';
      },

      _enableButton: function sld_enableButton() {
        this.passcodePanel.dataset.passcodeStatus = 'success';
      },

      _updatePassCodeUI: function sld_updatePassCodeUI() {
        this.posscodeInput.classList.add('highlight');
        this.posscodeConfirmInput.classList.remove('highlight');
        for (var i = 0; i < 8; i++) {
          if (i < this._passcodeBuffer.length) {
            if (i < 3) {
              this.posscodeInput.classList.add('highlight');
              this.posscodeConfirmInput.classList.remove('highlight');
            } else {
              this.posscodeConfirmInput.classList.add('highlight');
              this.posscodeInput.classList.remove('highlight');
            }
            this.passcodeDigits[i].dataset.dot = true;
          } else {
            delete this.passcodeDigits[i].dataset.dot;
          }
        }

        let selectorRules = null;
        if (['edit', 'confirm', 'confirmLock'].indexOf(this._MODE) > -1) {
          selectorRules = 'gaia-header [data-mode*=' + this._MODE + ']';
          let headerElement =
            this.passcodePanel.querySelector(selectorRules);
          headerElement.setAttribute('aria-live', 'assertive');
          headerElement.textContent = headerElement.textContent;
        } else {
          selectorRules = 'label[data-mode=' + this._MODE + ']';
          let createInput = this.posscodeInput.querySelector(selectorRules);
          if (createInput) {
            if (this.posscodeInput.classList.contains('highlight')) {
              createInput.setAttribute('aria-live', 'assertive');
              createInput.textContent = createInput.textContent;
            } else {
              createInput.removeAttribute('aria-live');
            }
          }

          let confirmInput =
            this.posscodeConfirmInput.querySelector(selectorRules);
          if (confirmInput) {
            if (this.posscodeConfirmInput.classList.contains('highlight')) {
              confirmInput.setAttribute('aria-live', 'assertive');
              confirmInput.textContent = confirmInput.textContent;
            } else {
              confirmInput.removeAttribute('aria-live');
            }
          }
        }
      },

      _checkPasscode: function sld_checkPasscode() {
        if (this._settings.passcode != this._passcodeBuffer) {
          this._showErrorMessage(true);
          return false;
        } else {
          this._hideErrorMessage();
          return true;
        }
      },

      _backToScreenLock: function sld_backToScreenLock() {
        this._passcodeBuffer = '';
        this.passcodeContainer.blur();
        SettingsService.navigate('screenLock');
      },

      _setupSKs: function sld_setupSKs() {
        var params = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: [{
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            method: function() {
              _self._backToScreenLock();
            }
          }]
        };
        if (this._checkingLength[this._MODE] === this._passcodeBuffer.length) {
          switch (this._MODE) {
            case 'create': {
              var item = {
                name: 'Create',
                l10nId: 'create',
                priority: 3,
                method: function () {
                  _self.setPasscode();
                  showToast('passcode-created');
                }
              };
              params.items.push(item);
            }
              break;
            case 'new': {
              var item = {
                name: 'Change',
                l10nId: 'change',
                priority: 3,
                method: function() {
                  _self.setPasscode();
                  showToast('passcode-changed');
                }
              };
              params.items.push(item);
            }
              break;
          }
        }
        ;

        SettingsSoftkey.init(params);
        SettingsSoftkey.show();
      },

      setPasscode: function sld_setPasscode() {
        if (this.passcodePanel.dataset.passcodeStatus !== 'success') {
          this._showErrorMessage();
          this.passcodeInput.focus();
          return;
        }
        var passcode = this._passcodeBuffer.substring(0, 4);
        var lock = navigator.mozSettings.createLock();
        lock.set({
          'lockscreen.passcode-lock.code': passcode
        });
        lock.set({
          'lockscreen.passcode-lock.enabled': true
        });
        lock.set({
          'lockscreen.enabled': true
        });
        this._backToScreenLock();
      }
    };
  };

  return ScreenLockPasscode;
});

define('panels/screen_lock_passcode/panel',['require','modules/settings_panel','panels/screen_lock_passcode/screen_lock_passcode'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');
  var ScreenLockPasscode =
    require('panels/screen_lock_passcode/screen_lock_passcode');

  return function ctor_screenlockPasscode() {
    var screenLockPasscode = ScreenLockPasscode();

    return SettingsPanel({
      onInit: function(panel) {
        screenLockPasscode.onInit(panel);
      },
      onBeforeShow: function(panel, mode) {
        screenLockPasscode.onBeforeShow(panel, mode);
      },
      onBeforeHide: function() {
        screenLockPasscode.onBeforeHide();
      },
      onShow: function() {
        screenLockPasscode.onShow();
      },
      onHide: function() {
        screenLockPasscode.onHide();
      }
    });
  };
});
