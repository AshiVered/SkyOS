/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [factory_reset.js] = ' + s + '\n');
    }
  }

  var FactoryResetTest = new TestItem(render);
  function factoryReset() {
    let power = navigator.mozPower;
    if (!power) {
      debug('Cannot get mozPower');
      return;
    }

    if (!power.factoryReset) {
      debug('Cannot invoke mozPower.factoryReset()');
      return;
    }

    power.factoryReset();
  }

  FactoryResetTest.onInit = function() {
    this.passButton.style.display = 'none';
    this.failButton.style.visibility = 'hidden';
  };

  FactoryResetTest.onDeinit = function() {
  };

  FactoryResetTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    if (evt.key === 'ArrowUp') {
      factoryReset();
    }
    return false;
  };

  function render() {
    return `
        <div id="title">Factory Reset</div>
        <div id="centertext">
            <div id="factory_reset_tip1">This will eraser all data from your phone internal storage</div>
            <div id="factory_reset_tip2">Do you want factory reset?</div>
        </div>
        <button id="factory_reset" class="buttons">Reset</button>`;
  }

  exports.Test = FactoryResetTest;
}(window));
